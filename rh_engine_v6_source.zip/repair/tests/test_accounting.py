"""Regression tests for buy/sell accounting defects.

These tests verify that the REPAIRED engine correctly computes:
- Acquired token quantity as delta (post - pre), not total balance
- Sell proceeds as delta (post - pre), not total balance
- Entry price from actual acquisition cost / actual acquired qty
- PnL from actual entry price, not corrupted entry price

Tests use mocks — no real transactions, no wallet access.
"""
import pytest
from unittest.mock import MagicMock, patch, PropertyMock
from decimal import Decimal


# ── Test: Buy functions must use balance delta, not total ──

class TestBuyAccounting:
    """Defect A-D: buy() functions used total wallet balance as acquired qty."""

    def test_pons_buy_uses_delta_not_total(self):
        """If wallet held 1000 tokens before and 2000 after,
        acquired = 1000, NOT 2000."""
        pre_balance = 1000 * 10**18   # 1000 tokens pre-existing
        post_balance = 2000 * 10**18  # 2000 tokens after buy
        expected_acquired = 1000.0     # delta = 1000

        # The buy function should return (1000.0, entry_price)
        # where entry_price = cost / 1000, NOT cost / 2000
        cost_eth = 0.05
        expected_entry = cost_eth * 2466 / expected_acquired  # $123.30 / 1000

        # This test will be wired to the actual repaired function
        # For now, verify the math
        wrong_entry = cost_eth * 2466 / 2000.0  # OLD BUG: $61.65
        assert expected_entry != wrong_entry
        assert expected_entry == pytest.approx(cost_eth * 2466 / 1000.0)

    def test_buy_with_zero_prior_balance(self):
        """First buy on a token — delta == total. Both should agree."""
        pre_balance = 0
        post_balance = 5000 * 10**18
        delta = (post_balance - pre_balance) / 10**18
        assert delta == 5000.0

    def test_buy_with_dust_prior_balance(self):
        """Wallet has 50 dust tokens. Buy 10000. Delta = 10000, not 10050."""
        pre = 50 * 10**18
        post = 10050 * 10**18
        delta = (post - pre) / 10**18
        assert delta == 10000.0
        # Entry price should use 10000, not 10050
        cost_usd = 100.0
        correct_entry = cost_usd / delta
        wrong_entry = cost_usd / (post / 10**18)
        assert correct_entry == pytest.approx(0.01)
        assert wrong_entry == pytest.approx(100.0 / 10050.0)
        assert correct_entry != wrong_entry


class TestSellAccounting:
    """Defect E-J: sell() functions used total quote balance as proceeds."""

    def test_pons_sell_uses_delta_not_total(self):
        """If wallet had 0.5 ETH before sell and 0.55 ETH after,
        proceeds = 0.05 ETH, NOT 0.55 ETH."""
        pre_eth = 0.5
        post_eth = 0.55
        actual_proceeds = post_eth - pre_eth  # 0.05 ETH
        wrong_proceeds = post_eth             # 0.55 ETH (OLD BUG)
        assert actual_proceeds == pytest.approx(0.05)
        assert wrong_proceeds == pytest.approx(0.55)
        assert actual_proceeds != wrong_proceeds

    def test_sell_spy_uses_delta(self):
        """SPY sell: proceeds = post_spy - pre_spy, not total spy balance."""
        pre_spy = 0.20
        post_spy = 0.23
        proceeds = post_spy - pre_spy  # 0.03 SPY
        assert proceeds == pytest.approx(0.03)

    def test_sell_usdg_uses_delta(self):
        """USDG sell: proceeds = post_usdg - pre_usdg, not total."""
        pre_usdg = 60.0
        post_usdg = 65.5
        proceeds = post_usdg - pre_usdg  # 5.5 USDG
        assert proceeds == pytest.approx(5.5)


class TestPnLCalculation:
    """PnL must use actual entry price from correct acquisition accounting."""

    def test_pnl_with_correct_entry(self):
        """With correct delta-based entry, PnL should be accurate."""
        actual_acquired = 1000.0
        cost_usd = 100.0
        entry_price = cost_usd / actual_acquired  # $0.10
        current_price = 0.12  # $0.12
        pnl = (current_price - entry_price) / entry_price * 100
        assert pnl == pytest.approx(20.0)

    def test_pnl_with_corrupted_entry_shows_wrong_value(self):
        """With total-balance entry, PnL is wrong (demonstrates the bug)."""
        total_balance = 2000.0  # had 1000 before, bought 1000
        cost_usd = 100.0
        wrong_entry = cost_usd / total_balance  # $0.05 (should be $0.10)
        current_price = 0.12
        wrong_pnl = (current_price - wrong_entry) / wrong_entry * 100
        # Bug makes PnL appear as +140% when it's actually +20%
        assert wrong_pnl == pytest.approx(140.0)
        assert wrong_pnl != pytest.approx(20.0)  # WRONG!


class TestZeroMinOutFallback:
    """Defect: sell retry with amountOutMinimum=0 must be removed."""

    def test_sell_never_uses_zero_min_out(self):
        """No sell path should ever set min_out to 0 as a fallback."""
        # Read the repaired source and check no '(0, ' pattern exists
        # in sell function retry loops
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()

        # Find all sell functions and check for zero-min-out pattern
        # Pattern: (0, 'EMERGENCY min_out=0')
        emergency_zero = re.findall(r"\(0,\s*['\"]EMERGENCY", source)
        assert len(emergency_zero) == 0, \
            f"Found {len(emergency_zero)} zero-min-out fallbacks — should be 0"


class TestMomentumVerification:
    """Defect: [100, 100, 19] should NOT pass as stable momentum."""

    def test_large_drop_from_first_to_last_reading_fails(self):
        """If last reading is >30% below the highest reading, reject."""
        readings = [100.0, 100.0, 19.0]
        highest = max(readings)
        last = readings[-1]
        drop_pct = (highest - last) / highest * 100  # 81% drop
        # With the fix, this should be rejected (>30% drop)
        assert drop_pct > 30.0, "This should be caught as a massive drop"

    def test_stable_momentum_passes(self):
        """[50, 52, 48] — slight fluctuation, should pass."""
        readings = [50.0, 52.0, 48.0]
        highest = max(readings)
        last = readings[-1]
        drop_pct = (highest - last) / highest * 100  # 7.7% drop
        assert drop_pct < 30.0, "Slight fluctuation should pass"

    def test_rising_momentum_passes(self):
        """[20, 25, 30] — rising, should pass."""
        readings = [20.0, 25.0, 30.0]
        highest = max(readings)
        last = readings[-1]
        drop_pct = (highest - last) / highest * 100  # 0% drop
        assert drop_pct == 0.0


class TestEntryPredicateReapplication:
    """Defect: entry conditions must be re-checked right before buy."""

    def test_stale_momentum_should_block_entry(self):
        """If momentum drops below MIN_5M_ENTRY between verify and buy, reject."""
        MIN_5M_ENTRY = 19.0
        # At verification time: 25% (passes)
        verified_c5 = 25.0
        # By buy time (10s later): 8% (should block)
        current_c5 = 8.0
        assert current_c5 < MIN_5M_ENTRY, "Stale momentum should block entry"

    def test_stale_bs_ratio_should_block_entry(self):
        """If B/S drops below MIN_BS_ENTRY between verify and buy, reject."""
        MIN_BS_ENTRY = 1.02
        verified_bs = 1.5
        current_bs = 0.8  # sellers now winning
        assert current_bs < MIN_BS_ENTRY


class TestCooldownFiltering:
    """Defect: cooldown should filter BEFORE ranking, not after."""

    def test_cooldown_token_should_not_block_other_candidates(self):
        """If top candidate is on cooldown, 2nd candidate should be tried."""
        import time
        cooldowns = {'0xaaa': time.time()}  # token A on cooldown
        candidates = [
            {'addr': '0xaaa', 'score': 100},  # blocked
            {'addr': '0xbbb', 'score': 80},   # should be tried
        ]
        # Filter out cooldown tokens before ranking
        eligible = [c for c in candidates if c['addr'] not in cooldowns]
        assert len(eligible) == 1
        assert eligible[0]['addr'] == '0xbbb'


class TestGasReservation:
    """Defect: SPY/USDG routes must also reserve ETH for gas."""

    def test_spy_buy_must_check_eth_gas_reserve(self):
        """When buying with SPY, wallet must still have enough ETH for sells."""
        GAS_RESERVE = 0.003
        eth_balance = 0.001  # only 0.001 ETH — not enough
        assert eth_balance < GAS_RESERVE, "Should reject — insufficient ETH for gas"

    def test_usdg_buy_must_check_eth_gas_reserve(self):
        """Same for USDG route."""
        GAS_RESERVE = 0.003
        eth_balance = 0.002
        assert eth_balance < GAS_RESERVE


class TestHoneypotDetection:
    """Defect: V4 inconclusive sell sim must NOT be treated as SAFE."""

    def test_unknown_revert_must_not_pass_as_safe(self):
        """A sell simulation that reverts with an unknown error code
        must return INCONCLUSIVE (block entry), not SAFE."""
        known_honeypot_patterns = ['sell not allowed', '6570f956', '90bfb865']
        unknown_error = "InsufficientOutputAmount"
        # This should NOT match any known pattern
        assert not any(p in unknown_error for p in known_honeypot_patterns)
        # Therefore it should be treated as INCONCLUSIVE, blocking entry


class TestPIDEnforcement:
    """Defect: newcomer must REFUSE to start, not kill incumbent."""

    def test_refuse_if_incumbent_alive(self):
        """If an existing engine PID is running, new engine must exit."""
        import os
        our_pid = os.getpid()
        # Simulate: incumbent is alive (our own PID always passes os.kill(pid, 0))
        try:
            os.kill(our_pid, 0)
            incumbent_alive = True
        except ProcessLookupError:
            incumbent_alive = False
        assert incumbent_alive, "Incumbent should be detected as alive"
        # New engine should sys.exit(1), not kill the incumbent


# ══════════════════════════════════════════════════════════════════════
# NEW: Provisional Configuration & Exit Rule Tests
# ══════════════════════════════════════════════════════════════════════

class TestProvisionalConfig:
    """Verify the centralized PROVISIONAL config is present and consistent."""

    def test_config_constants_present_in_source(self):
        """All required config constants must exist in the repaired source."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()

        required = [
            'MIN_5M_ENTRY', 'MAX_5M_ENTRY', 'MIN_BS_ENTRY',
            'MIN_LIQ', 'HARD_SL', 'HARD_TP', 'TRAIL_UNIFIED',
            'MOMENTUM_DEATH', 'SELLER_DOM_EXIT', 'SLOWING_DROP_PCT',
            'POSITION_SIZE_PCT', 'LIQ_CAP_PCT', 'MAX_ACTIVE_POSITIONS',
            'MAX_RT_COST_EXPECTED', 'MAX_RT_COST_BOUNDED', 'EXEC_SLIPPAGE_ALLOW',
            'EXIT_COOLDOWN_SEC', 'MAX_SESSION_LOSSES',
            'MAX_BUY_REVERTS', 'WARMUP_TICKS', 'DAILY_DRAWDOWN_LIMIT',
        ]
        for name in required:
            pattern = rf'^{name}\s*='
            assert re.search(pattern, source, re.MULTILINE), \
                f"Missing config constant: {name}"

    def test_warmup_ticks_is_zero(self):
        """Provisional policy: no artificial warmup exemption."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        m = re.search(r'^WARMUP_TICKS\s*=\s*(\d+)', source, re.MULTILINE)
        assert m, "WARMUP_TICKS not found"
        assert int(m.group(1)) == 0, f"WARMUP_TICKS should be 0, got {m.group(1)}"

    def test_max_active_positions_is_one(self):
        """Explicit: only one position at a time."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        m = re.search(r'^MAX_ACTIVE_POSITIONS\s*=\s*(\d+)', source, re.MULTILINE)
        assert m, "MAX_ACTIVE_POSITIONS not found"
        assert int(m.group(1)) == 1

    def test_provisional_label_present(self):
        """Config must be labeled PROVISIONAL, not 'optimal'."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert 'PROVISIONAL' in source
        # Must NOT claim to be historically optimal
        assert 'historically optimal' not in source.lower()


class TestUnifiedExitRules:
    """Exit logic must implement all 6 unified exits with correct precedence."""

    def test_hard_stop_fires_at_minus_3pct(self):
        """Position at -3.5% should trigger hard stop."""
        entry = 0.10
        current = 0.0965  # -3.5%
        pnl = (current - entry) / entry * 100
        HARD_SL = 3.0
        assert pnl <= -HARD_SL

    def test_hard_stop_does_not_fire_at_minus_2pct(self):
        """Position at -2% should NOT trigger hard stop."""
        entry = 0.10
        current = 0.098  # -2%
        pnl = (current - entry) / entry * 100
        HARD_SL = 3.0
        assert pnl > -HARD_SL

    def test_take_profit_fires_at_plus_25pct(self):
        """Position at +26% should trigger TP."""
        entry = 0.10
        current = 0.126  # +26%
        pnl = (current - entry) / entry * 100
        HARD_TP = 25.0
        assert pnl >= HARD_TP

    def test_unified_trailing_stop_fires(self):
        """6% drop from peak should trigger trailing stop."""
        peak = 0.20
        current = 0.187  # 6.5% below peak
        drop = (peak - current) / peak * 100
        TRAIL_UNIFIED = 6.0
        assert drop >= TRAIL_UNIFIED

    def test_unified_trailing_stop_holds(self):
        """4% drop from peak should NOT trigger trailing stop."""
        peak = 0.20
        current = 0.192  # 4% below peak
        drop = (peak - current) / peak * 100
        TRAIL_UNIFIED = 6.0
        assert drop < TRAIL_UNIFIED

    def test_slowing_exit_fires(self):
        """30%+ drop in 5m momentum from previous reading → exit."""
        prev_c5 = 40.0
        curr_c5 = 25.0  # 37.5% drop
        drop = (prev_c5 - curr_c5) / prev_c5 * 100
        assert drop >= 30.0

    def test_momentum_death_exit(self):
        """5m% below +5% → momentum dead → exit."""
        c5 = 3.0
        MOMENTUM_DEATH = 5.0
        assert c5 < MOMENTUM_DEATH

    def test_seller_dominance_exit(self):
        """B/S ratio below 0.7 → exit."""
        bs_ratio = 0.55
        SELLER_DOM_EXIT = 0.7
        assert bs_ratio < SELLER_DOM_EXIT

    def test_trailing_stop_source_present(self):
        """Trailing stop must be ACTIVE in the source (was disabled before)."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        # Must find active trailing stop logic using TRAIL_UNIFIED
        assert 'TRAIL_UNIFIED' in source
        # Must NOT find 'DISABLED' in the trailing stop section
        trail_section = re.search(r'EXIT 3.*?EXIT 4', source, re.DOTALL)
        assert trail_section, "Trailing stop EXIT 3 section not found"
        assert 'DISABLED' not in trail_section.group(0), \
            "Trailing stop should be ACTIVE, not DISABLED"


class TestPolicyBDisabled:
    """Policy B runner DISABLED per Shaheer directive — full exit at +25%."""

    def test_tp_always_exits_100pct(self):
        """At +25%, engine exits 100% of position (no partial sell)."""
        pnl = 27.0
        HARD_TP = 25.0
        # With Policy B disabled, TP always does full exit
        action = 'full_exit' if pnl >= HARD_TP else 'hold'
        assert action == 'full_exit'

    def test_no_partial_sell_in_exit_logic(self):
        """The exit logic must NOT contain partial sell branching."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        # The TP exit section should say "selling 100%", not "selling 50%"
        assert 'selling 100%' in source
        # Partial sell infrastructure removed from active exit logic
        assert '_partial_exit' not in source

    def test_trail_uses_unified_only(self):
        """Trailing stop uses TRAIL_UNIFIED (6%) — no Policy B branching."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        # The trailing stop section should reference TRAIL_UNIFIED directly
        assert 'TRAIL_UNIFIED' in source
        # Policy B trail branching removed from active exit
        assert '_partial_sold' not in source


class TestCooldown:
    """Cooldown: 60s after completed position exit."""

    def test_cooldown_is_60s(self):
        """Cooldown must be 60s (not 180s — that was Policy C, now disabled)."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        m = re.search(r"^EXIT_COOLDOWN_SEC\s*=\s*(\d+)", source, re.MULTILINE)
        assert m, "EXIT_COOLDOWN_SEC not found"
        assert int(m.group(1)) == 60

    def test_no_policy_c_cooldown(self):
        """Policy C 180s cooldown should not be active."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        # EXIT_COOLDOWN_SEC_C should not be in active code
        assert 'EXIT_COOLDOWN_SEC_C' not in source


class TestDailyCircuitBreaker:
    """Daily drawdown limit must pause new entries."""

    def test_3pct_drawdown_triggers_pause(self):
        """If equity drops 3%+ from day start, entries paused."""
        day_start = 200.0
        current = 193.0  # -3.5%
        drawdown = (day_start - current) / day_start * 100
        DAILY_DRAWDOWN_LIMIT = 3.0
        assert drawdown >= DAILY_DRAWDOWN_LIMIT

    def test_2pct_drawdown_allows_entry(self):
        """2% drop should NOT pause entries."""
        day_start = 200.0
        current = 196.0  # -2%
        drawdown = (day_start - current) / day_start * 100
        DAILY_DRAWDOWN_LIMIT = 3.0
        assert drawdown < DAILY_DRAWDOWN_LIMIT

    def test_circuit_breaker_in_source(self):
        """_check_daily_drawdown() must exist in source."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert '_check_daily_drawdown' in source
        assert 'DAILY_DRAWDOWN_LIMIT' in source


class TestRoundTripCostCheck:
    """Round-trip cost must be checked before buying."""

    def test_high_rt_cost_rejects(self):
        """2.4% slippage × 2 = 4.8% RT cost → reject (> 1.5%)."""
        slip_pct = 2.4
        est_rt = slip_pct * 2
        MAX_RT_COST_EXPECTED = 1.5
        assert est_rt > MAX_RT_COST_EXPECTED

    def test_low_rt_cost_passes(self):
        """0.5% slippage × 2 = 1.0% RT cost → pass (< 1.5%)."""
        slip_pct = 0.5
        est_rt = slip_pct * 2
        MAX_RT_COST_EXPECTED = 1.5
        assert est_rt < MAX_RT_COST_EXPECTED

    def test_rt_cost_check_in_source(self):
        """Round-trip cost check must exist before buy in enter()."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert 'est_rt_cost' in source
        assert 'MAX_RT_COST_EXPECTED' in source


class TestSlippageRejectsZeroPrice:
    """check_slippage must reject when market_price <= 0."""

    def test_zero_price_rejected(self):
        """market_price=0 must return (False, 100.0), not (True, 0.0)."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        # The old code: return True, 0.0  (the bug)
        # The fix: return False, 100.0
        # Check the actual fix is in place
        match = re.search(r'if market_price <= 0:.*?return (False|True)', source, re.DOTALL)
        assert match, "market_price<=0 check not found"
        assert match.group(1) == 'False', \
            f"market_price<=0 should return False (REJECT), got {match.group(1)}"


class TestStatePersistence:
    """State persistence must save at ALL exit mutation points."""

    def test_save_state_after_all_exit_cooldown_mutations(self):
        """Every EXIT_COOLDOWN assignment must have _save_state() nearby."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            lines = f.readlines()

        # Find all lines that ASSIGN EXIT_COOLDOWN[...] = time.time()
        # (not reads like `elapsed = time.time() - EXIT_COOLDOWN[al]`)
        mutations = []
        for i, line in enumerate(lines):
            if re.search(r'EXIT_COOLDOWN\[.*\]\s*=\s*time\.time\(\)', line):
                mutations.append(i)

        assert len(mutations) >= 5, f"Expected ≥5 EXIT_COOLDOWN mutations, found {len(mutations)}"

        # For each mutation, check that _save_state() appears within 15 lines
        # (may be past an if/else block but still in the same exit path)
        missing = []
        for line_idx in mutations:
            found_save = False
            for j in range(line_idx + 1, min(line_idx + 16, len(lines))):
                if '_save_state()' in lines[j]:
                    found_save = True
                    break
            if not found_save:
                missing.append(line_idx + 1)  # 1-indexed

        assert len(missing) == 0, \
            f"Missing _save_state() after EXIT_COOLDOWN mutations at lines: {missing}"


class TestAllSlippageRoutes:
    """Slippage must be checked for ALL routes, not just ETH/Pons."""

    def test_spy_route_slippage_check_in_source(self):
        """SPY route must have slippage check."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert 'SPY route' in source and 'slippage' in source.lower()

    def test_v4_other_route_slippage_check_in_source(self):
        """V4-other route must have slippage check."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        # Must find slippage check for V4-other route
        assert 'v4_deploy_eth_equiv' in source or ('V4' in source and 'slippage too high' in source)


class TestSellFloor:
    """Sell minimum output must use fresh-quote-based calculation, not broad floor."""

    def test_no_50pct_floor_in_sell_functions(self):
        """Sell functions must NOT use a crude 50% floor of reference price."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        # Old pattern: expected_eth * 0.50 or expected_* * 0.50
        assert '* 0.50' not in source, "Found crude 50% floor in sell function"
        assert '* 0.5 ' not in source or '* 0.5 #' not in source.split('min_out')[0]

    def test_no_zero_minout_fallback(self):
        """No sell path should use amountOutMinimum=0 (already tested, re-verified)."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        # Pattern: (0, 'EMERGENCY' or (0, 'no
        emergency_zero = re.findall(r"\(0,\s*['\"]EMERGENCY", source)
        assert len(emergency_zero) == 0

    def test_sell_uses_exec_slippage_allow(self):
        """All sell functions must reference EXEC_SLIPPAGE_ALLOW for minOut."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        # Must find EXEC_SLIPPAGE_ALLOW in sell-related code
        # Count occurrences in sell functions (should appear in all 4)
        import re
        matches = re.findall(r'EXEC_SLIPPAGE_ALLOW', source)
        # Config definition + at least 4 sell functions × 2 uses each
        assert len(matches) >= 9, f"Expected ≥9 EXEC_SLIPPAGE_ALLOW refs, found {len(matches)}"

    def test_no_quote_refuses_to_sign(self):
        """Missing executable quote must NOT authorize signing or broadcasting a sale.
        When no valid quote is available, sell functions must return 0.0 (refuse to sign)
        — NOT (1, 'no-quote minimum') which would authorize an unprotected swap."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        # Old pattern MUST NOT exist: (1, 'no-quote minimum') authorized an unprotected swap
        assert 'no-quote minimum' not in source, \
            "Found 'no-quote minimum' — this old pattern authorized unprotected swaps"
        # New pattern MUST exist: 'refusing to sign' and return 0.0
        assert 'refusing to sign' in source, \
            "No-quote path must log 'refusing to sign'"
        # Must find the refuse-to-sign pattern in ALL sell functions (pons, v3, v3_spy, v4)
        # Each should have: 'no executable quote — refusing to sign'
        refuse_count = len(re.findall(r'no executable quote.*refusing to sign', source))
        assert refuse_count >= 3, \
            f"Expected ≥3 sell functions with refuse-to-sign, found {refuse_count}"
        # The old (1, ...) pattern that authorized swaps without protection must be gone
        assert "(1, 'no-quote" not in source

    def test_sell_minout_math(self):
        """0.5% execution slippage: minOut = quote * (1 - 0.005), not quote * 0.50."""
        expected_eth_wei = 10**18  # 1 ETH expected
        EXEC_SLIPPAGE_ALLOW = 0.5
        # Correct: 99.5% of expected
        correct_min = int(expected_eth_wei * (1.0 - EXEC_SLIPPAGE_ALLOW / 100))
        assert correct_min == 995000000000000000  # 0.995 ETH
        # Wrong (old): 50% of expected
        wrong_min = int(expected_eth_wei * 0.50)
        assert wrong_min == 500000000000000000  # 0.5 ETH
        assert correct_min > wrong_min  # The fix is more protective


class TestNoRetryWidening:
    """Sell functions must NOT automatically widen slippage on retry.
    Old pattern: first attempt at 0.5%, auto-retry at 1.0%.
    New pattern: single attempt at EXEC_SLIPPAGE_ALLOW, caller retries next tick."""

    def test_no_1pct_retry_in_source(self):
        """No sell function should contain a 1.0% retry widening pattern."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        # Old pattern: retry_min calculated at 2x slippage
        assert 'retry_min' not in source, "retry_min variable should not exist — no auto-widening"
        # Old pattern: 'quote-1.0% retry' attempt label
        assert 'quote-1.0% retry' not in source, "1.0% retry attempt label should not exist"
        # Old pattern: EXEC_SLIPPAGE_ALLOW * 2 in sell functions
        # (get_rt_cost_model legitimately uses it for bounded RT cost — both legs)
        # Check each sell function body individually
        for fn_name in ['def sell(', 'def v3_sell(', 'def v3_sell_spy(', 'def v4_sell(']:
            fn_match = re.search(re.escape(fn_name), source)
            if fn_match:
                fn_start = fn_match.start()
                next_def = source.find('\ndef ', fn_start + 1)
                fn_body = source[fn_start:next_def] if next_def > 0 else source[fn_start:]
                assert 'EXEC_SLIPPAGE_ALLOW * 2' not in fn_body, \
                    f"{fn_name.strip()} must not widen slippage on retry"

    def test_single_attempt_per_sell(self):
        """Each sell function should have exactly one attempt entry in its attempts list."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        # Each attempts = [...] should have exactly one tuple
        attempts_defs = re.findall(r'attempts\s*=\s*\[([^\]]+)\]', source)
        for defn in attempts_defs:
            # Count tuple entries: each (min_out, ...) pair
            tuples = re.findall(r'\(', defn)
            assert len(tuples) == 1, f"Expected 1 attempt entry, found {len(tuples)} in: {defn[:80]}"


class TestRoundTripCostBounded:
    """RT cost check must use both expected (1.5%) and bounded (2.5%) limits."""

    def test_bounded_check_in_source(self):
        """Must check against MAX_RT_COST_BOUNDED (2.5%) including exec tolerance."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert 'MAX_RT_COST_BOUNDED' in source
        assert 'est_rt_bounded' in source

    def test_bounded_includes_exec_slippage(self):
        """Bounded RT = impact + 2× execution slippage allowance."""
        slip_pct = 0.5
        EXEC_SLIPPAGE_ALLOW = 0.5
        est_rt_cost = slip_pct * 2  # 1.0% impact
        est_rt_bounded = est_rt_cost + EXEC_SLIPPAGE_ALLOW * 2  # 1.0% + 1.0% = 2.0%
        MAX_RT_COST_BOUNDED = 2.5
        assert est_rt_bounded <= MAX_RT_COST_BOUNDED  # 2.0% < 2.5% → passes

    def test_high_slippage_fails_bounded(self):
        """1.2% slippage → bounded = 3.4% > 2.5% → reject."""
        slip_pct = 1.2
        EXEC_SLIPPAGE_ALLOW = 0.5
        est_rt_cost = slip_pct * 2  # 2.4%
        est_rt_bounded = est_rt_cost + EXEC_SLIPPAGE_ALLOW * 2  # 2.4% + 1.0% = 3.4%
        MAX_RT_COST_BOUNDED = 2.5
        assert est_rt_bounded > MAX_RT_COST_BOUNDED


class TestSizingCeiling:
    """Position sizing: up to 100% of deployable capital (ceiling, not fixed %)."""

    def test_position_size_pct_is_100(self):
        """POSITION_SIZE_PCT must be 100 (full capital ceiling)."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        m = re.search(r'^POSITION_SIZE_PCT\s*=\s*([\d.]+)', source, re.MULTILINE)
        assert m, "POSITION_SIZE_PCT not found"
        assert float(m.group(1)) == 100.0

    def test_liq_cap_is_100(self):
        """LIQ_CAP_PCT must be 100 (no fixed liquidity cap)."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        m = re.search(r'^LIQ_CAP_PCT\s*=\s*([\d.]+)', source, re.MULTILINE)
        assert m, "LIQ_CAP_PCT not found"
        assert float(m.group(1)) == 100.0


class TestAtomicState:
    """State persistence must use atomic writes and durable directory."""

    def test_state_dir_not_tmp(self):
        """State files must NOT be in /tmp."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        # _STATE_FILE and _BLACKLIST_FILE must not point to /tmp/
        import re
        state_match = re.search(r"_STATE_FILE\s*=\s*['\"]([^'\"]+)['\"]", source)
        # With the new code, _STATE_FILE is built dynamically, not a string literal
        # Check that '/tmp/' is not in any state file path
        assert "'/tmp/rh_engine_state.json'" not in source
        assert "'/tmp/rh_blacklist.json'" not in source

    def test_atomic_write_used(self):
        """_save_state must use atomic write (temp file + rename)."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert 'os.replace(' in source or 'os.rename(' in source
        assert 'mkstemp' in source or 'NamedTemporaryFile' in source


class TestOSLock:
    """Single-instance enforcement must use OS file lock, not just PID check."""

    def test_uses_flock(self):
        """Must use fcntl.flock for exclusive ownership."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert 'fcntl.flock' in source
        assert 'LOCK_EX' in source
        assert 'LOCK_NB' in source

    def test_no_pid_kill(self):
        """Must NOT kill incumbent process."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        # Should not contain os.kill in the single-instance function
        # (os.kill(pid, 0) for checking was removed, now using flock)
        assert 'os.kill(old_pid' not in source


# ══════════════════════════════════════════════════════════════════════
# NEW: Amendment 2 — Deep Structural Fix Tests
# ══════════════════════════════════════════════════════════════════════

class TestDoSellSentinel:
    """_do_sell must return TradeOutcome (structured result replacing -1 sentinel)."""

    def test_trade_outcome_class_exists(self):
        """TradeOutcome class must exist with UNRESOLVED status for tokens-gone-proceeds-unknown."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert 'class TradeOutcome' in source
        assert "UNRESOLVED = 'unresolved'" in source
        assert "RESOLVED = 'resolved'" in source
        assert "FAILED = 'failed'" in source
        assert 'is_unresolved' in source
        assert 'is_resolved' in source

    def test_do_sell_returns_trade_outcome(self):
        """_do_sell must return TradeOutcome, not numeric -1 or raw ETH float."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        do_sell_match = re.search(r'def _do_sell\(.*?\n(?=def |\nif __name__)', source, re.DOTALL)
        assert do_sell_match, "_do_sell not found"
        do_sell_body = do_sell_match.group(0)
        assert 'TradeOutcome' in do_sell_body, "_do_sell must return TradeOutcome"
        assert 'Returns TradeOutcome' in do_sell_body or 'TradeOutcome(' in do_sell_body

    def test_no_fabricated_success(self):
        """_do_sell must NOT return fabricated 0.001 ETH or use dust as proceeds."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        # The old bug: "return e if e > 0 else 0.001" inside _do_sell
        # Extract _do_sell body
        do_sell_match = re.search(r'def _do_sell\(.*?\n(?=def |\nif __name__)', source, re.DOTALL)
        assert do_sell_match, "_do_sell not found"
        do_sell_body = do_sell_match.group(0)
        assert 'else 0.001' not in do_sell_body, \
            "_do_sell must not fabricate 0.001 ETH on failed sells"
        # Old 100-token dust threshold treated as proceed certification
        assert 'proceed certification' not in source.lower()

    def test_all_callers_handle_trade_outcome(self):
        """Every call site for _do_sell must handle TradeOutcome (is_unresolved/is_resolved)."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        # Find all places that call _do_sell (variable = _do_sell(...))
        do_sell_calls = re.findall(r'\w+\s*=\s*_do_sell\(', source)
        # Must check .is_unresolved at each call site
        unresolved_checks = re.findall(r'\.is_unresolved', source)
        resolved_checks = re.findall(r'\.is_resolved', source)
        # At least 3 callers: fast exit, latched exit, main exit (+ bad-fill sell-back)
        assert len(do_sell_calls) >= 3, f"Expected ≥3 _do_sell calls, found {len(do_sell_calls)}"
        assert len(unresolved_checks) >= 3, f"Expected ≥3 is_unresolved checks, found {len(unresolved_checks)}"
        assert len(resolved_checks) >= 3, f"Expected ≥3 is_resolved checks, found {len(resolved_checks)}"
        # Old numeric sentinel must NOT appear in caller code (only in docstrings/comments)
        # No caller should use `== -1` to check _do_sell result
        main_fn = re.search(r'def main\(.*?\n(?=def |\nif __name__)', source, re.DOTALL)
        if main_fn:
            main_body = main_fn.group(0)
            assert 'e == -1' not in main_body, "main() must not use old e == -1 sentinel check"
            assert 'e > 0' not in main_body or 'e > 0' in main_body.split('_do_sell')[0], \
                "main() must not use old e > 0 for sell result check"


class TestExitPathNoBlock:
    """price_monitor.stop() must NOT block before _do_sell — it joins a worker
    thread for up to 10s which delays protective sell submission."""

    def test_no_stop_before_sell(self):
        """price_monitor.stop() must NOT appear between should_sell() and _do_sell()."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        # The fix: mark_selling() replaces stop() before _do_sell
        # stop() joins the worker thread, blocking up to 10s
        # In the fast exit path, there should be mark_selling() before _do_sell, NOT stop()
        # Find the fast exit section
        fast_exit = re.search(r'FAST EXIT.*?_do_sell', source, re.DOTALL)
        assert fast_exit, "Fast exit section with _do_sell not found"
        section = fast_exit.group(0)
        assert 'mark_selling()' in section, "mark_selling() must precede _do_sell in fast exit"
        assert 'price_monitor.stop()' not in section, \
            "price_monitor.stop() must NOT precede _do_sell — it blocks for up to 10s"

    def test_main_exit_no_stop_before_sell(self):
        """Main exit path also must not stop() before selling."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        # Find the main exit section (EXIT 1 through _do_sell)
        # Look for the exit logic before the main _do_sell call
        main_exits = re.findall(r'EXIT \d.*?_do_sell', source, re.DOTALL)
        # At least one exit path should exist
        assert len(main_exits) >= 1
        # None should have price_monitor.stop() between exit decision and _do_sell
        for section in main_exits:
            if 'mark_selling()' in section:
                assert 'price_monitor.stop()' not in section, \
                    "price_monitor.stop() must not precede _do_sell in any exit path"


class TestCooldownAllExits:
    """Cooldown must apply after ALL exits — winning AND losing."""

    def test_cooldown_applied_universally(self):
        """Every exit path (fast exit, main exit, latched exit) must set EXIT_COOLDOWN."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        # Count EXIT_COOLDOWN[...] = time.time() assignments
        cooldown_sets = re.findall(r'EXIT_COOLDOWN\[.*\]\s*=\s*time\.time\(\)', source)
        # Must be ≥5: fast exit sentinel, fast exit success, latched exit,
        # main exit sentinel, main exit success (and possibly more for sell failure)
        assert len(cooldown_sets) >= 5, \
            f"Expected ≥5 EXIT_COOLDOWN assignments (all exit paths), found {len(cooldown_sets)}"

    def test_no_cooldown_pop_for_winners(self):
        """Old code popped cooldown for winners — must be gone."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert 'EXIT_COOLDOWN.pop(' not in source, \
            "EXIT_COOLDOWN.pop() found — cooldown must NOT be removed for winners"


class TestShadowMode:
    """Shadow mode must be read-only: no signing, no broadcasting."""

    def test_shadow_function_exists(self):
        """shadow() function must exist in source."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert 'def shadow(' in source

    def test_shadow_cli_arg(self):
        """--shadow CLI argument must invoke shadow mode."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert "'--shadow'" in source or '"--shadow"' in source

    def test_shadow_no_send_raw(self):
        """shadow() must NOT call send_raw_transaction — read-only."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        # Extract shadow function body (from def shadow( to end or next def at module level)
        shadow_match = re.search(r'def shadow\(.*?\):.*?(?=\nif __name__|$)', source, re.DOTALL)
        assert shadow_match, "shadow() function not found"
        shadow_body = shadow_match.group(0)
        # Skip the docstring — it may reference send_raw_transaction in prose
        # Split on the closing triple-quote of the docstring
        parts = shadow_body.split('"""', 2)
        # parts[0] = 'def shadow(...):\n    ', parts[1] = docstring, parts[2] = actual body
        actual_body = parts[2] if len(parts) > 2 else shadow_body
        assert 'send_raw_transaction' not in actual_body, \
            "shadow() must not call send_raw_transaction — it's read-only"
        assert 'sign_transaction' not in actual_body, \
            "shadow() must not call sign_transaction — it's read-only"

    def test_shadow_logs_to_jsonl(self):
        """Shadow mode must log observations to shadow_log.jsonl."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert 'shadow_log.jsonl' in source


class TestDrawdownIncludesAllQuotes:
    """_check_daily_drawdown must include ETH + SPY + USDG equity."""

    def test_usdg_bal_function_exists(self):
        """usdg_bal() must exist for USDG balance lookups."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert 'def usdg_bal()' in source

    def test_drawdown_references_usdg(self):
        """_check_daily_drawdown must include USDG in equity calculation
        (either directly or via _portfolio_equity helper)."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        # Find the _check_daily_drawdown function body
        dd_match = re.search(r'def _check_daily_drawdown.*?(?=\ndef |\nclass )', source, re.DOTALL)
        assert dd_match, "_check_daily_drawdown not found"
        dd_body = dd_match.group(0)
        # Either direct usdg_bal call or delegated to _portfolio_equity
        uses_usdg = 'usdg_bal' in dd_body or '_portfolio_equity' in dd_body
        assert uses_usdg, \
            "_check_daily_drawdown must include USDG in equity calculation"
        uses_spy = 'spy_bal' in dd_body or '_portfolio_equity' in dd_body
        assert uses_spy, \
            "_check_daily_drawdown must include SPY in equity calculation"
        # If using _portfolio_equity, verify it includes USDG and SPY
        if '_portfolio_equity' in dd_body:
            eq_match = re.search(r'def _portfolio_equity.*?(?=\ndef |\nclass )', source, re.DOTALL)
            assert eq_match, "_portfolio_equity must exist"
            eq_body = eq_match.group(0)
            assert 'usdg_bal' in eq_body, "_portfolio_equity must include USDG"
            assert 'spy_bal_usd' in eq_body, "_portfolio_equity must include SPY"

    def test_drawdown_uses_utc_day(self):
        """Drawdown baseline must reset on UTC day rollover."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        dd_match = re.search(r'def _check_daily_drawdown.*?(?=\ndef |\nclass )', source, re.DOTALL)
        assert dd_match
        dd_body = dd_match.group(0)
        assert 'utcnow' in dd_body or 'utc' in dd_body.lower(), \
            "_check_daily_drawdown must use UTC for day boundary"


class TestStableLockPath:
    """Lock file must be in stable directory, not source-relative or /tmp."""

    def test_lock_in_state_dir(self):
        """_LOCK_FILE must be in _STATE_DIR (/var/lib/rh-engine/...)."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        # _LOCK_FILE should reference _STATE_DIR
        assert '_STATE_DIR' in source
        # Lock should be in /var/lib/rh-engine/ path
        assert '/var/lib/rh-engine' in source

    def test_state_dir_uses_chain_id_and_wallet(self):
        """State directory must include chain ID and FULL wallet address for uniqueness."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        # Must find CID and wallet in the state dir construction
        assert 'CID' in source
        # The _STATE_DIR assignment uses os.path.join('/var/lib/rh-engine', f'{CID}-...')
        state_dir_match = re.search(r"_STATE_DIR\s*=\s*os\.path\.join\(['\"]*/var/lib/rh-engine", source)
        assert state_dir_match, "_STATE_DIR must point to /var/lib/rh-engine/"
        # Must use FULL wallet address, NOT truncated W[:10]
        state_dir_line = source[state_dir_match.start():source.index('\n', state_dir_match.start())]
        assert 'W[:10]' not in state_dir_line, "_STATE_DIR must use FULL wallet address, not W[:10]"
        assert 'W.lower()' in state_dir_line or 'W}' in state_dir_line, \
            "_STATE_DIR must use full wallet address"


class TestStatusShowsUSDG:
    """--status output must include USDG balance."""

    def test_status_prints_usdg(self):
        """Status output must print USDG line."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        # Find the --status block
        status_match = re.search(r"'--status'.*?(?=elif|else)", source, re.DOTALL)
        assert status_match, "--status block not found"
        status_body = status_match.group(0)
        assert 'usdg_bal' in status_body or 'USDG' in status_body, \
            "--status must display USDG balance"


class TestSlippageQuoteUnits:
    """check_slippage must use actual quote-token amounts for V4 routes,
    not ETH-equivalent amounts that produce wrong raw units."""

    def test_check_slippage_accepts_quote_deploy(self):
        """check_slippage must accept quote_deploy + quote_dec parameters."""
        import re, inspect
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        sig = re.search(r'def check_slippage\((.*?)\)', source)
        assert sig, "check_slippage not found"
        params = sig.group(1)
        assert 'quote_deploy' in params, "check_slippage must accept quote_deploy parameter"
        assert 'quote_dec' in params, "check_slippage must accept quote_dec parameter"

    def test_v4_path_uses_typed_quote_amount(self):
        """V4 slippage path must compute test_amt from quote_deploy when provided."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        # Find check_slippage function body specifically
        cs_match = re.search(r'def check_slippage\(.*?\n(?=def )', source, re.DOTALL)
        assert cs_match, "check_slippage function not found"
        cs_body = cs_match.group(0)
        assert 'quote_deploy' in cs_body, \
            "V4 slippage must reference quote_deploy for typed quote-token amounts"

    def test_no_smaller_quote_extrapolation(self):
        """V4 quoter must NOT scale up from reduced-size quotes.
        AMM slippage is nonlinear — extrapolation underestimates impact."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        cs_match = re.search(r'def check_slippage\(.*?\n(?=def )', source, re.DOTALL)
        assert cs_match
        cs_body = cs_match.group(0)
        # Must NOT scale tokens_out_raw by test_amt/reduced ratio (the old extrapolation bug)
        assert 'test_amt / reduced' not in cs_body, \
            "Must not scale reduced quote output to full size"
        # If reduced quote succeeds but full fails, should reject (pool too thin)
        assert 'pool too thin' in cs_body.lower() or 'return False, 100.0' in cs_body, \
            "Reduced-quote success + full-quote failure must reject"

    def test_enter_passes_quote_deploy_for_v4_other(self):
        """enter() must pass quote_deploy to check_slippage for V4-other routes."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        enter_fn = re.search(r'def enter\(\):.*?(?=\ndef )', source, re.DOTALL)
        assert enter_fn
        enter_body = enter_fn.group(0)
        assert 'quote_deploy=' in enter_body, \
            "enter() must pass quote_deploy to check_slippage for typed amounts"

    def test_enter_passes_quote_deploy_for_spy(self):
        """enter() must pass quote_deploy to check_slippage for SPY routes."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        enter_fn = re.search(r'def enter\(\):.*?(?=\ndef )', source, re.DOTALL)
        assert enter_fn
        enter_body = enter_fn.group(0)
        # Should have at least 2 quote_deploy= references (SPY + V4-other)
        count = enter_body.count('quote_deploy=')
        assert count >= 2, f"Expected ≥2 quote_deploy= calls in enter(), found {count}"


# ══════════════════════════════════════════════════════════════════════
# AMENDMENT 3: Managed-quantity sell, executable-quote PnL, full wallet state dir
# ══════════════════════════════════════════════════════════════════════

class TestManagedQuantitySell:
    """Sell functions must accept managed_raw parameter to sell exact acquired quantity."""

    def test_sell_functions_accept_managed_raw(self):
        """All 4 sell functions + _do_sell must accept managed_raw parameter."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        for fn in ['def sell(', 'def v3_sell(', 'def v3_sell_spy(', 'def v4_sell(', 'def _do_sell(']:
            fn_match = re.search(re.escape(fn) + r'.*?\)', source)
            assert fn_match, f"{fn} not found"
            sig = fn_match.group(0)
            assert 'managed_raw' in sig, f"{fn} must accept managed_raw parameter, got: {sig}"

    def test_do_sell_passes_managed_raw_to_underlying(self):
        """_do_sell must pass managed_raw to all underlying sell function calls."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        do_sell_match = re.search(r'def _do_sell\(.*?\n(?=def |\nif __name__)', source, re.DOTALL)
        assert do_sell_match
        body = do_sell_match.group(0)
        # Each sell call in _do_sell should pass managed_raw
        for fn in ['sell(', 'v3_sell(', 'v3_sell_spy(', 'v4_sell(']:
            if fn in body:
                # Find the call and check managed_raw is passed
                call_match = re.search(re.escape(fn) + r'.*?\)', body)
                assert call_match, f"Could not find {fn} call in _do_sell"
                assert 'managed_raw' in call_match.group(0), \
                    f"_do_sell must pass managed_raw to {fn}"

    def test_sell_uses_managed_raw_not_full_balance(self):
        """When managed_raw is provided and valid, sell must use it instead of full balance."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        # Each sell function body should contain the managed_raw override logic
        for fn_name in ['def sell(', 'def v3_sell(', 'def v3_sell_spy(', 'def v4_sell(']:
            fn_match = re.search(re.escape(fn_name), source)
            assert fn_match
            fn_start = fn_match.start()
            next_def = source.find('\ndef ', fn_start + 1)
            fn_body = source[fn_start:next_def] if next_def > 0 else source[fn_start:]
            assert 'managed_raw' in fn_body, f"{fn_name} must reference managed_raw"
            # Should have conditional: if managed_raw > 0 ... r = managed_raw
            assert 'r = managed_raw' in fn_body, \
                f"{fn_name} must set r = managed_raw when managed quantity is provided"

    def test_main_exit_passes_managed_raw(self):
        """Main exit block must pass managed_raw and cost_basis_usd to _do_sell."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        main_fn = re.search(r'def main\(.*?\n(?=def |\nif __name__)', source, re.DOTALL)
        assert main_fn
        main_body = main_fn.group(0)
        # Find all _do_sell call blocks (multi-line, grab surrounding context)
        # Use a broader pattern to capture the full multi-line call
        do_sell_positions = [m.start() for m in re.finditer(r'_do_sell\(', main_body)]
        count = 0
        for pos in do_sell_positions:
            # Grab a generous window after the call start
            call_block = main_body[pos:pos+300]
            assert 'managed_raw' in call_block, \
                f"_do_sell call in main() must pass managed_raw: {call_block[:80]}"
            assert 'cost_basis_usd' in call_block, \
                f"_do_sell call in main() must pass cost_basis_usd: {call_block[:80]}"
            count += 1
        assert count >= 2, f"Expected ≥2 _do_sell calls in main() with managed_raw, found {count}"


class TestExecutableQuotePnL:
    """PnL decisions must use executable quotes, not chart prices."""

    def test_get_sell_quote_function_exists(self):
        """get_sell_quote function must exist for actual quoter-based PnL."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert 'def get_sell_quote(' in source
        assert 'class SellQuote' in source

    def test_main_loop_uses_executable_pnl(self):
        """Main loop PnL calculation must use get_sell_quote, not just chart price."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        main_fn = re.search(r'def main\(.*?\n(?=def |\nif __name__)', source, re.DOTALL)
        assert main_fn
        main_body = main_fn.group(0)
        assert 'get_sell_quote(' in main_body, "Main loop must call get_sell_quote for executable PnL"
        assert '_last_exec_pnl' in main_body, "Main loop must cache executable PnL as stale fallback"
        assert 'chart_pnl' in main_body or 'chart' in main_body.lower(), \
            "Main loop must label chart price PnL separately from executable PnL"

    def test_get_rt_cost_model_function_exists(self):
        """get_rt_cost_model must exist for actual buy→sell round-trip simulation."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert 'def get_rt_cost_model(' in source

    def test_trailing_stop_uses_executable_peak(self):
        """Trailing stop must track executable-value peak, not chart-price peak."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        main_fn = re.search(r'def main\(.*?\n(?=def |\nif __name__)', source, re.DOTALL)
        assert main_fn
        main_body = main_fn.group(0)
        assert 'exec_peak_usd' in main_body, "Trailing stop must track exec_peak_usd"


class TestLossTimestampExpiry:
    """SESSION_LOSSES must expire via _LOSS_TIMESTAMPS 24h window."""

    def test_loss_timestamps_used(self):
        """Loss counting must write timestamps for 24h expiry."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert '_LOSS_TIMESTAMPS' in source
        assert '86400' in source, "24h (86400 seconds) expiry must be present"

    def test_loss_timestamps_in_state(self):
        """Loss timestamps must be persisted in state file."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        # _save_state should include loss_timestamps
        save_match = re.search(r'def _save_state.*?\n(?=def |\n\w)', source, re.DOTALL)
        if save_match:
            assert 'loss_timestamps' in save_match.group(0) or '_LOSS_TIMESTAMPS' in save_match.group(0)
        # _load_state should restore them
        load_match = re.search(r'def _load_state.*?\n(?=def |\n\w)', source, re.DOTALL)
        if load_match:
            assert 'loss_timestamps' in load_match.group(0) or '_LOSS_TIMESTAMPS' in load_match.group(0)

    def test_main_exit_writes_loss_timestamp(self):
        """Main exit path must write to _LOSS_TIMESTAMPS on losing exit."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        main_fn = re.search(r'def main\(.*?\n(?=def |\nif __name__)', source, re.DOTALL)
        assert main_fn
        main_body = main_fn.group(0)
        assert '_LOSS_TIMESTAMPS' in main_body, "Main exit must write loss timestamps"


class TestDrawdownStatePersisted:
    """Daily drawdown state (UTC day, equity baseline, pause flag) must survive restart."""

    def test_save_state_includes_drawdown(self):
        """_save_state must persist day_start_equity and entry_paused."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        save_fn = re.search(r'def _save_state\(\).*?\n(?=def |\n\w)', source, re.DOTALL)
        assert save_fn
        body = save_fn.group(0)
        assert 'day_start_equity' in body, "_save_state must persist day_start_equity"
        assert 'entry_paused' in body, "_save_state must persist entry_paused"

    def test_load_state_restores_drawdown(self):
        """_load_state must restore day_start_equity and entry_paused."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        load_fn = re.search(r'def _load_state\(\).*?\n(?=def |\n\w)', source, re.DOTALL)
        assert load_fn
        body = load_fn.group(0)
        assert 'day_start_equity' in body, "_load_state must restore day_start_equity"
        assert '_entry_paused' in body, "_load_state must restore _entry_paused"

    def test_state_dir_migration_from_truncated(self):
        """Migration logic must exist for old truncated W[:10] state directories."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert '_OLD_STATE_DIR' in source, "Migration from truncated state dir must exist"
        assert 'copytree' in source, "Migration must copy old state dir to new"


class TestShadowDuration:
    """Shadow mode must accept duration parameter and exit after timeout."""

    def test_shadow_accepts_duration(self):
        """shadow() must accept duration_s parameter."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        shadow_match = re.search(r'def shadow\((.*?)\)', source)
        assert shadow_match, "shadow() function not found"
        assert 'duration_s' in shadow_match.group(1), "shadow() must accept duration_s parameter"

    def test_shadow_has_time_limit(self):
        """Shadow loop must check elapsed time to exit after duration."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        shadow_match = re.search(r'def shadow\(.*?\):.*?(?=\n# ═══|$)', source, re.DOTALL)
        assert shadow_match
        body = shadow_match.group(0)
        assert 'shadow_start' in body, "Shadow must track start time"
        assert 'duration_s' in body, "Shadow must check duration_s"

    def test_shadow_cli_passes_duration(self):
        """--shadow CLI must pass optional duration argument."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert 'duration_s=' in source, "CLI must pass duration_s to shadow()"


class TestDeniedRPCMethods:
    """Wallet-changing RPC methods must be explicitly denied."""

    def test_denied_rpc_list_exists(self):
        """A deny list for wallet-changing RPCs must exist."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert '_DENIED_RPC_METHODS' in source, "Denied RPC methods list must exist"
        assert 'eth_sendRawTransaction' in source, "Must deny eth_sendRawTransaction"
        assert 'eth_sendTransaction' in source, "Must deny eth_sendTransaction"
        assert 'eth_sign' in source, "Must deny eth_sign"


# ══════════════════════════════════════════════════════════════════════
# AMENDMENT 4 — Behavioral acceptance tests (required by docking station prompt)
# ══════════════════════════════════════════════════════════════════════

class TestTxCoordinator:
    """Transaction coordinator must manage nonces, generation IDs, and operation lifecycle."""

    def test_tx_coordinator_class_exists(self):
        """TxCoordinator class must exist with nonce management."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert 'class TxCoordinator' in source
        assert 'acquire_nonce' in source
        assert 'new_generation' in source
        assert 'register_op' in source
        assert 'confirm_op' in source

    def test_tx_op_class_exists(self):
        """TxOp class must track operation lifecycle."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert 'class TxOp' in source
        assert "PENDING = 'pending'" in source
        assert "CONFIRMED = 'confirmed'" in source
        assert "REVERTED = 'reverted'" in source

    def test_generation_rejects_stale_callbacks(self):
        """TxCoordinator.is_valid_generation must reject old-generation callbacks."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert 'is_valid_generation' in source

    def test_coordinator_serialization(self):
        """TxCoordinator must support to_dict/load_from_dict for persistence."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert 'to_dict' in source
        assert 'load_from_dict' in source

    def test_coordinator_instantiated(self):
        """TxCoordinator must be instantiated as _tx_coord at module level."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert '_tx_coord = TxCoordinator(w3, W, acct)' in source, \
            "TxCoordinator must be instantiated with w3, W, acct"

    def test_acquire_nonce_helper(self):
        """_acquire_nonce() helper must exist, register durable ops, and delegate to _tx_coord."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert 'def _acquire_nonce(' in source
        assert '_tx_coord.acquire_nonce()' in source
        assert '_tx_coord.register_op(' in source, \
            "_acquire_nonce must register a durable TxOp before returning nonce"

    def test_all_broadcast_sites_use_coordinator(self):
        """All 20 send_raw_transaction sites must use _acquire_nonce(), not inline get_transaction_count.
        Simulation sites (eth_call/estimate_gas) may still use get_transaction_count."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        # Find all functions that call send_raw_transaction
        broadcast_fns = ['def approve(', 'def sell(', 'def buy(',
                         'def _unwrap_all_weth(', 'def v3_buy(', 'def v3_sell(',
                         'def v3_buy_spy(', 'def v3_sell_spy(',
                         'def _ensure_permit2_approval(', 'def v4_buy(', 'def v4_sell(']
        for fn_sig in broadcast_fns:
            fn_start = source.find(fn_sig)
            assert fn_start >= 0, f"Function {fn_sig} not found"
            # Find function body (to next def at same indent)
            fn_end = source.find('\ndef ', fn_start + 1)
            if fn_end == -1:
                fn_end = len(source)
            fn_body = source[fn_start:fn_end]
            if 'send_raw_transaction' in fn_body:
                # This function broadcasts — must NOT have inline get_transaction_count
                # EXCEPT for simulation calls within the same function (buy() has pons_ok-style sim)
                assert 'get_transaction_count(W)' not in fn_body, \
                    f"Broadcast function {fn_sig.strip()} still uses inline get_transaction_count"

    def test_simulation_sites_preserved(self):
        """Simulation-only functions (pons_ok, honeypot_check, get_rt_cost_model,
        get_sell_quote) should retain get_transaction_count — they don't consume nonces."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        sim_fns = ['def pons_ok(', 'def honeypot_check(', 'def get_rt_cost_model(',
                   'def get_sell_quote(']
        for fn_sig in sim_fns:
            fn_start = source.find(fn_sig)
            if fn_start < 0:
                continue  # Some sim functions may not exist
            fn_end = source.find('\ndef ', fn_start + 1)
            if fn_end == -1:
                fn_end = len(source)
            fn_body = source[fn_start:fn_end]
            # These should NOT use _acquire_nonce (they don't broadcast)
            assert '_acquire_nonce()' not in fn_body, \
                f"Simulation function {fn_sig.strip()} should NOT use _acquire_nonce"


class TestPositionLedger:
    """Position ledger must track full lifecycle with managed quantities."""

    def test_ledger_class_exists(self):
        """PositionLedger class must exist."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert 'class PositionLedger' in source

    def test_ledger_tracks_managed_quantities(self):
        """Ledger must track managed_raw, sold_raw, residual_raw."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert 'managed_raw' in source
        assert 'sold_raw' in source
        assert 'residual_raw' in source

    def test_ledger_partial_completion(self):
        """Ledger must model partial sell completion explicitly."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert "PARTIAL = 'partial'" in source
        assert 'record_sell' in source

    def test_ledger_net_pnl(self):
        """Ledger must compute net PnL from proceeds - cost - gas."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert 'net_pnl_usd' in source

    def test_ledger_wired_into_enter(self):
        """enter() must create a PositionLedger on successful buy."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        enter_fn = re.search(r'def enter\(\):.*?\n(?=def |\nif __name__)', source, re.DOTALL)
        assert enter_fn
        body = enter_fn.group(0)
        assert '_pos_ledger = PositionLedger(' in body, \
            "enter() must create PositionLedger on successful acquisition"
        assert 'new_generation()' in body, \
            "enter() must call new_generation() for generation-based callback rejection"

    def test_ledger_wired_into_exit_handlers(self):
        """Main exit handlers must update _pos_ledger on sell outcome."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        main_fn = re.search(r'def main\(.*?\n(?=def |\nif __name__)', source, re.DOTALL)
        assert main_fn
        body = main_fn.group(0)
        assert '_pos_ledger' in body, \
            "Main loop must reference _pos_ledger"
        assert 'mark_unresolved' in body, \
            "UNRESOLVED handler must call ledger.mark_unresolved()"
        assert '_pos_ledger.record_sell' in body, \
            "Exit handlers must call ledger.record_sell()"

    def test_ledger_persisted_in_state(self):
        """_save_state must persist pos_ledger and tx_coordinator."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        save_fn = re.search(r'def _save_state\(\).*?\n(?=def |\n\w)', source, re.DOTALL)
        assert save_fn
        body = save_fn.group(0)
        assert 'pos_ledger' in body, "_save_state must persist pos_ledger"
        assert 'tx_coordinator' in body, "_save_state must persist tx_coordinator"

    def test_ledger_restored_on_load(self):
        """_load_state must restore pos_ledger and tx_coordinator from persisted state."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        load_fn = re.search(r'def _load_state\(\).*?\n(?=def |\n\w)', source, re.DOTALL)
        assert load_fn
        body = load_fn.group(0)
        assert 'PositionLedger.from_dict' in body, \
            "_load_state must restore PositionLedger from dict"
        assert 'load_from_dict' in body, \
            "_load_state must restore TxCoordinator from dict"


class TestQuoteFreshness:
    """Executable quotes must respect freshness bounds for decisions."""

    def test_quote_max_age_constant(self):
        """QUOTE_MAX_AGE_S must be defined and positive."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert 'QUOTE_MAX_AGE_S' in source

    def test_sl_requires_executable_pnl(self):
        """Hard SL exit must check have_decision_pnl — not fire on chart-only PnL."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        main_fn = re.search(r'def main\(.*?\n(?=def |\nif __name__)', source, re.DOTALL)
        assert main_fn
        main_body = main_fn.group(0)
        # SL exit must check have_decision_pnl
        sl_match = re.search(r'EXIT 1.*?HARD S.*?do_exit = True', main_body, re.DOTALL)
        assert sl_match
        sl_block = sl_match.group(0)
        assert 'have_decision_pnl' in sl_block, \
            "Hard SL must require have_decision_pnl — chart-only PnL must not trigger SL"

    def test_tp_requires_executable_pnl(self):
        """Hard TP exit must check have_decision_pnl — chart +25% with flat exec is not +25% net."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        main_fn = re.search(r'def main\(.*?\n(?=def |\nif __name__)', source, re.DOTALL)
        assert main_fn
        main_body = main_fn.group(0)
        tp_match = re.search(r'EXIT 2.*?TAKE PROFIT.*?do_exit = True', main_body, re.DOTALL)
        assert tp_match
        tp_block = tp_match.group(0)
        assert 'have_decision_pnl' in tp_block, \
            "Hard TP must require have_decision_pnl — chart +25% with flat exec is NOT +25% net"

    def test_trail_requires_executable_pnl(self):
        """Trailing stop must check have_decision_pnl — no chart-based trail decisions."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        main_fn = re.search(r'def main\(.*?\n(?=def |\nif __name__)', source, re.DOTALL)
        assert main_fn
        main_body = main_fn.group(0)
        trail_match = re.search(r'EXIT 3.*?TRAIL.*?do_exit = True', main_body, re.DOTALL)
        assert trail_match
        trail_block = trail_match.group(0)
        assert 'have_decision_pnl' in trail_block, \
            "Trail stop must require have_decision_pnl"

    def test_exec_peak_only_from_fresh_quotes(self):
        """Executable peak must only advance from fresh (not stale) quotes."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        main_fn = re.search(r'def main\(.*?\n(?=def |\nif __name__)', source, re.DOTALL)
        assert main_fn
        main_body = main_fn.group(0)
        # exec_peak_usd update must be gated on quote_fresh
        peak_update = re.search(r'exec_peak_usd.*?=.*?exec_value', main_body)
        assert peak_update
        # Find the surrounding context — must check quote_fresh
        start = max(0, peak_update.start() - 200)
        context = main_body[start:peak_update.end() + 50]
        assert 'quote_fresh' in context, \
            "exec_peak_usd must only advance from fresh quotes, not stale/chart"

    def test_stale_quote_labeled(self):
        """Stale quotes must be clearly labeled, not silently used for decisions."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert 'STALE' in source or 'stale' in source.lower()


class TestResolvedMeansReconciled:
    """RESOLVED must require receipt evidence + residual check, not just positive proceeds."""

    def test_do_sell_verifies_residual(self):
        """_do_sell must check residual balance before marking RESOLVED."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        do_sell_fn = re.search(r'def _do_sell\(.*?\n(?=def |\nif __name__)', source, re.DOTALL)
        assert do_sell_fn
        body = do_sell_fn.group(0)
        # Must check remaining tokens when result > 0
        assert 'remaining' in body or 'residual' in body, \
            "_do_sell must verify token residual on positive proceeds"

    def test_partial_completion_modeled(self):
        """Partial sells (proceeds but tokens remain) must be explicitly handled."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert 'is_partial' in source, "TradeOutcome must have is_partial property"
        assert 'partial' in source.lower()


class TestReadOnlyProvider:
    """Shadow mode must use a transport-level read-only provider."""

    def test_read_only_provider_class(self):
        """ReadOnlyProvider class must exist and block wallet-changing RPCs."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert 'class ReadOnlyProvider' in source
        assert 'make_request' in source
        assert '_READ_ONLY_ALLOWED' in source

    def test_read_only_blocks_send(self):
        """ReadOnlyProvider must raise PermissionError for send_raw_transaction."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert 'PermissionError' in source
        assert 'blocked RPC method' in source or 'shadow mode is read-only' in source

    def test_read_only_allows_eth_call(self):
        """ReadOnlyProvider must allow eth_call for quoter access."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert "'eth_call'" in source


class TestSellQuoteIntegration:
    """Every seller must consume a fresh SellQuote with raw input/output and identity."""

    def test_sell_quote_has_required_fields(self):
        """SellQuote must carry raw quantities, token/pool identity, block, timestamp."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert 'class SellQuote' in source
        for field in ['proceeds_raw', 'token_addr', 'token_raw', 'route',
                      'block', 'timestamp', 'gas_estimate']:
            assert field in source, f"SellQuote must have {field} field"

    def test_main_loop_stores_sell_quote(self):
        """Main loop must store fresh SellQuote on position for seller integration."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        main_fn = re.search(r'def main\(.*?\n(?=def |\nif __name__)', source, re.DOTALL)
        assert main_fn
        main_body = main_fn.group(0)
        assert '_last_sell_quote' in main_body, \
            "Main loop must store fresh SellQuote on position dict"


class TestPonsRouteRejection:
    """Pons entries must be rejected when no validated sell quote is available."""

    def test_pons_no_rt_model_rejects_entry(self):
        """When get_rt_cost_model returns not-ok for Pons, enter() must reject."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        enter_fn = re.search(r'def enter\(\):.*?\n(?=def |\nif __name__)', source, re.DOTALL)
        assert enter_fn
        body = enter_fn.group(0)
        # Must explicitly reject Pons route when rt_ok is False
        assert "route == 'pons'" in body or 'Pons route' in body, \
            "enter() must check and reject Pons route when no validated sell quote exists"
        assert 'unsupported route' in body.lower() or 'no validated sell quote' in body.lower(), \
            "Pons rejection must report unsupported route explicitly"

    def test_pons_sell_quote_returns_not_ok(self):
        """get_sell_quote for Pons must return ok=False (no executable quote)."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        gsq = re.search(r'def get_sell_quote\(.*?\n(?=def |\nif __name__)', source, re.DOTALL)
        assert gsq
        body = gsq.group(0)
        assert "ok=False" in body, "get_sell_quote must return ok=False for Pons route"


class TestBehavioralAcceptance:
    """Required behavioral acceptance tests from docking station prompt Section 5."""

    def test_chart_plus25_flat_exec_not_booked_as_profit(self):
        """Chart +25% with flat executable proceeds must not be booked as +25% net profit.
        Verified by: EXIT 2 (TP) requires have_decision_pnl from executable quote."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        main_fn = re.search(r'def main\(.*?\n(?=def |\nif __name__)', source, re.DOTALL)
        assert main_fn
        main_body = main_fn.group(0)
        # Chart PnL is labeled display only
        assert 'display only' in main_body.lower() or 'display/logging only' in main_body.lower()
        # TP exit requires have_decision_pnl (executable)
        tp_section = re.search(r'EXIT 2.*?do_exit = True', main_body, re.DOTALL)
        assert tp_section
        assert 'have_decision_pnl' in tp_section.group(0)

    def test_expired_quotes_cannot_become_estimates(self):
        """Expired quotes must not feed into execution estimates.
        Verified by: exec_peak only advances from fresh quotes, SL/TP/trail check freshness."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert 'QUOTE_MAX_AGE_S' in source
        assert 'quote_fresh' in source
        main_fn = re.search(r'def main\(.*?\n(?=def |\nif __name__)', source, re.DOTALL)
        assert main_fn
        body = main_fn.group(0)
        assert 'have_decision_pnl = False' in body, \
            "When quote is stale, have_decision_pnl must be False"

    def test_restart_preserves_unresolved_exit(self):
        """Restart must preserve unresolved exit intent, original basis, peak, daily pause.
        Verified by: _save_state/_load_state persist all required fields."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        save_fn = re.search(r'def _save_state\(\).*?\n(?=def |\n\w)', source, re.DOTALL)
        assert save_fn
        body = save_fn.group(0)
        for field in ['cooldowns', 'losses', 'buy_fails', 'loss_timestamps',
                      'day_start_equity', 'entry_paused']:
            assert field in body, f"_save_state must persist {field}"

    def test_positive_proceeds_with_residual_not_full_close(self):
        """Positive proceeds with remaining tokens must not close the full position.
        Verified by: _do_sell checks residual and reports partial."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        do_sell = re.search(r'def _do_sell\(.*?\n(?=def |\nif __name__)', source, re.DOTALL)
        assert do_sell
        body = do_sell.group(0)
        assert 'remaining' in body or 'residual' in body
        assert 'PARTIAL' in body or 'partial' in body.lower()

    def test_shadow_cannot_sign_or_transmit(self):
        """Shadow helpers must not be able to sign or transmit wallet-changing requests.
        Verified by: ReadOnlyProvider blocks at transport level."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert 'class ReadOnlyProvider' in source
        assert 'PermissionError' in source
        assert 'make_request' in source

    def test_missing_pons_quotes_cannot_authorize_entry(self):
        """Missing Pons quotes must not authorize entry.
        Verified by: enter() rejects Pons route when rt_ok is False."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        enter_fn = re.search(r'def enter\(\):.*?\n(?=def |\nif __name__)', source, re.DOTALL)
        assert enter_fn
        body = enter_fn.group(0)
        assert "route == 'pons'" in body, "enter() must explicitly check for Pons route"
        assert 'return None' in body  # Returns None to reject


class TestPartialCompletionAllCallers:
    """PARTIAL status must be handled by every exit caller — not just _do_sell.
    Amendment 5: main exit, fast exit, latched exit, bad-fill sell-back must all
    handle is_partial without releasing entry gate or counting as complete exit."""

    def test_main_exit_handles_partial(self):
        """Main exit block must have explicit is_partial handler between
        is_unresolved and is_resolved — recording partial proceeds and
        updating managed_raw to residual."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        main_fn = re.search(r'def main\(.*?\n(?=def |\nif __name__)', source, re.DOTALL)
        assert main_fn
        body = main_fn.group(0)
        # Must have explicit is_partial handler in the main outcome branching
        assert 'outcome.is_partial' in body, \
            "Main exit block must handle outcome.is_partial"
        # Partial handler must NOT release entry gate (no pos = None after partial)
        partial_idx = body.index('outcome.is_partial')
        # Find the next elif/else after partial handler
        next_branch = body.find('elif outcome.is_resolved', partial_idx)
        if next_branch == -1:
            next_branch = body.find('else:', partial_idx)
        partial_block = body[partial_idx:next_branch] if next_branch > 0 else body[partial_idx:partial_idx+500]
        assert 'pos = None' not in partial_block, \
            "PARTIAL must NOT clear pos (release entry gate)"
        assert '_partial_proceeds' in partial_block, \
            "PARTIAL must accumulate _partial_proceeds"
        assert 'managed_raw' in partial_block, \
            "PARTIAL must update managed_raw to residual"
        assert '_exit_latched' in partial_block, \
            "PARTIAL must keep exit latch active"

    def test_fast_exit_handles_partial(self):
        """Fast exit (price_monitor triggered) must handle is_partial."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        # Find fast exit section (before main exit block)
        assert 'outcome.is_partial' in source
        # Count occurrences — should appear in fast exit, latched exit, AND main exit
        count = source.count('.is_partial')
        assert count >= 4, \
            f"is_partial must appear in at least 4 places (property + 3 callers), found {count}"

    def test_latched_exit_handles_partial(self):
        """Latched exit (retry loop) must handle sr.is_partial."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert 'sr.is_partial' in source, \
            "Latched exit must handle sr.is_partial"

    def test_bad_fill_sellback_handles_partial(self):
        """Bad-fill sell-back in enter() must handle is_partial — returning position
        with reduced managed_raw and exit latch, NOT returning None."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        enter_fn = re.search(r'def enter\(\):.*?\n(?=def |\nif __name__)', source, re.DOTALL)
        assert enter_fn
        body = enter_fn.group(0)
        assert 'sell_result.is_partial' in body, \
            "Bad-fill sell-back must handle sell_result.is_partial"
        # Partial sell-back must return a position dict (not None)
        partial_idx = body.index('sell_result.is_partial')
        partial_block = body[partial_idx:partial_idx+1200]
        assert 'return {' in partial_block or "return {'" in partial_block, \
            "Partial sell-back must return a position dict with exit latch"
        assert '_exit_latched' in partial_block, \
            "Partial sell-back position must have _exit_latched = True"
        assert '_partial_proceeds' in partial_block, \
            "Partial sell-back must record _partial_proceeds"

    def test_partial_does_not_count_as_exit(self):
        """PARTIAL must NOT increment rot counter, NOT set _sold, NOT set cooldown."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        main_fn = re.search(r'def main\(.*?\n(?=def |\nif __name__)', source, re.DOTALL)
        assert main_fn
        body = main_fn.group(0)
        partial_idx = body.index('outcome.is_partial')
        next_branch = body.find('elif outcome.is_resolved', partial_idx)
        partial_block = body[partial_idx:next_branch] if next_branch > 0 else body[partial_idx:partial_idx+500]
        assert 'rot += 1' not in partial_block, \
            "PARTIAL must NOT increment rotation counter"
        assert "pos['_sold'] = True" not in partial_block, \
            "PARTIAL must NOT mark position as sold"

    def test_trade_outcome_partial_status(self):
        """TradeOutcome.PARTIAL must be a proper status constant, not an error-string hack."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        # Must have PARTIAL as a class constant
        assert "PARTIAL = 'partial'" in source, \
            "TradeOutcome must define PARTIAL = 'partial' constant"
        # is_partial must check status, not error string
        assert "self.status == self.PARTIAL" in source, \
            "is_partial must check status == PARTIAL, not error string"
        # Must NOT use error-string hack
        assert "'partial' in str(self.error)" not in source, \
            "Must not use error-string hack for partial detection"


# ═══════════════════════════════════════════════════════════════════
# MOCK PROVIDER HARNESS — end-to-end behavioral tests through real code
# ═══════════════════════════════════════════════════════════════════

class MockWeb3Provider:
    """Mock Web3 provider for end-to-end behavioral tests.
    Records all RPC calls and returns configurable responses.
    Used to test real engine classes without network access."""

    def __init__(self, allowed_methods=None, nonce=688):
        self.calls = []
        self.nonce = nonce
        self.allowed_methods = allowed_methods  # None = allow all

    def make_request(self, method, params):
        self.calls.append((method, params))
        if self.allowed_methods is not None and method not in self.allowed_methods:
            raise PermissionError(f'RPC method {method} not allowed in read-only mode')
        if method == 'eth_getTransactionCount':
            return {'result': hex(self.nonce)}
        if method == 'eth_call':
            return {'result': '0x'}
        if method == 'eth_blockNumber':
            return {'result': hex(999999)}
        if method == 'eth_chainId':
            return {'result': hex(4663)}
        if method == 'eth_gasPrice':
            return {'result': hex(1000000000)}
        return {'result': '0x'}


class TestMockProviderHarness:
    """Mock provider harness with dependency injection for behavioral tests."""

    def test_mock_provider_records_calls(self):
        """MockWeb3Provider must record all RPC calls."""
        prov = MockWeb3Provider()
        prov.make_request('eth_blockNumber', [])
        prov.make_request('eth_call', [{'to': '0x1234'}])
        assert len(prov.calls) == 2
        assert prov.calls[0][0] == 'eth_blockNumber'
        assert prov.calls[1][0] == 'eth_call'

    def test_mock_provider_blocks_in_readonly(self):
        """Read-only MockWeb3Provider must block non-allowed RPCs."""
        allowed = frozenset(['eth_call', 'eth_blockNumber'])
        prov = MockWeb3Provider(allowed_methods=allowed)
        prov.make_request('eth_call', [])  # OK
        with pytest.raises(PermissionError):
            prov.make_request('eth_sendRawTransaction', [b'0xdead'])

    def test_mock_provider_returns_nonce(self):
        """MockWeb3Provider must return configurable nonce."""
        prov = MockWeb3Provider(nonce=42)
        result = prov.make_request('eth_getTransactionCount', ['0xabc', 'latest'])
        assert result['result'] == hex(42)


class TestEndToEndBehavioral:
    """End-to-end behavioral tests that exercise real engine classes
    with injected mock dependencies. These test ACTUAL runtime behavior,
    not just structural properties."""

    def test_trade_outcome_lifecycle_resolved(self):
        """TradeOutcome RESOLVED path: construct → check properties → extract values."""
        import sys, importlib, types, time as _time
        # Import TradeOutcome from engine source directly
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        # Extract just the TradeOutcome class
        import re
        to_match = re.search(r'(class TradeOutcome:.*?)(?=\nclass |\n# ──)', source, re.DOTALL)
        assert to_match
        ns = {'time': _time}
        exec(to_match.group(1), ns)
        TO = ns['TradeOutcome']
        # Test RESOLVED lifecycle
        outcome = TO(TO.RESOLVED, proceeds_usd=15.50, proceeds_raw=1000000,
                     tx_hash='0xabc', managed_raw=5000, sold_raw=5000, residual_raw=0)
        assert outcome.is_resolved
        assert not outcome.is_unresolved
        assert not outcome.is_partial
        assert not outcome.is_failed
        assert outcome.proceeds_usd == 15.50
        assert outcome.residual_raw == 0

    def test_trade_outcome_lifecycle_partial(self):
        """TradeOutcome PARTIAL path: proceeds obtained but residual tokens remain."""
        import re, time as _time
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        to_match = re.search(r'(class TradeOutcome:.*?)(?=\nclass |\n# ──)', source, re.DOTALL)
        ns = {'time': _time}
        exec(to_match.group(1), ns)
        TO = ns['TradeOutcome']
        outcome = TO(TO.PARTIAL, proceeds_usd=8.00, sold_raw=3000,
                     residual_raw=2000, managed_raw=5000)
        assert outcome.is_partial
        assert not outcome.is_resolved
        assert outcome.proceeds_usd == 8.00
        assert outcome.residual_raw == 2000
        assert outcome.sold_raw == 3000

    def test_trade_outcome_lifecycle_unresolved(self):
        """TradeOutcome UNRESOLVED path: tokens gone, proceeds unknown."""
        import re, time as _time
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        to_match = re.search(r'(class TradeOutcome:.*?)(?=\nclass |\n# ──)', source, re.DOTALL)
        ns = {'time': _time}
        exec(to_match.group(1), ns)
        TO = ns['TradeOutcome']
        outcome = TO(TO.UNRESOLVED, token_addr='0xdead', managed_raw=5000)
        assert outcome.is_unresolved
        assert not outcome.is_resolved
        assert outcome.proceeds_usd is None

    def test_position_ledger_full_lifecycle(self):
        """PositionLedger: create → partial sell → final sell → fully resolved."""
        import re, time as _time
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        # Extract PositionLedger class
        pl_match = re.search(r'(class PositionLedger:.*?)(?=\n# ── Read-Only|\nclass )', source, re.DOTALL)
        assert pl_match
        ns = {'time': _time}
        exec(pl_match.group(1), ns)
        PL = ns['PositionLedger']
        # Create ledger for a new position
        ledger = PL(token_addr='0xtoken', symbol='TEST', route='v3_10000',
                    managed_raw=10000, cost_basis_usd=50.00, entry_price=0.005,
                    exec_peak_usd=50.00, residual_raw=10000)
        assert ledger.status == PL.ACTIVE
        assert ledger.managed_raw == 10000
        assert ledger.residual_raw == 10000
        # Partial sell — 6000 of 10000 tokens
        ledger.record_sell(sold_raw=6000, proceeds_usd=30.00, tx_hash='0xpartial1')
        assert ledger.status == PL.PARTIAL
        assert ledger.sold_raw == 6000
        assert ledger.residual_raw == 4000
        assert ledger.proceeds_usd == 30.00
        assert len(ledger.sell_tx_hashes) == 1
        # Final sell — remaining 4000 tokens
        ledger.record_sell(sold_raw=4000, proceeds_usd=20.00, tx_hash='0xfinal')
        assert ledger.status == PL.RESOLVED
        assert ledger.sold_raw == 10000
        assert ledger.residual_raw == 0
        assert ledger.proceeds_usd == 50.00
        assert ledger.is_fully_resolved()
        assert len(ledger.sell_tx_hashes) == 2
        # Net PnL: $50 proceeds - $50 cost = $0
        assert ledger.net_pnl_usd == 0.0

    def test_position_ledger_serialization_roundtrip(self):
        """PositionLedger must survive to_dict → from_dict roundtrip."""
        import re, time as _time
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        pl_match = re.search(r'(class PositionLedger:.*?)(?=\n# ── Read-Only|\nclass )', source, re.DOTALL)
        ns = {'time': _time}
        exec(pl_match.group(1), ns)
        PL = ns['PositionLedger']
        original = PL(token_addr='0xabc', symbol='ABC', route='v4_eth',
                      managed_raw=50000, cost_basis_usd=100.00, entry_price=0.002,
                      residual_raw=50000)
        original.record_sell(sold_raw=20000, proceeds_usd=40.00)
        d = original.to_dict()
        restored = PL.from_dict(d)
        assert restored.token_addr == '0xabc'
        assert restored.symbol == 'ABC'
        assert restored.managed_raw == 50000
        assert restored.sold_raw == 20000
        assert restored.residual_raw == 30000
        assert restored.proceeds_usd == 40.00
        assert restored.status == PL.PARTIAL

    def test_tx_coordinator_nonce_sequence(self):
        """TxCoordinator must issue monotonically increasing nonces."""
        import re, threading, collections, time as _time
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        # Extract TxOp + TxCoordinator classes
        txop_match = re.search(r'(class TxOp:.*?)(?=\nclass TxCoordinator)', source, re.DOTALL)
        coord_match = re.search(r'(class TxCoordinator:.*?)(?=\n# ── Position Ledger)', source, re.DOTALL)
        assert txop_match and coord_match
        ns = {'threading': threading, 'collections': collections, 'time': _time}
        exec(txop_match.group(1), ns)
        exec(coord_match.group(1), ns)
        TC = ns['TxCoordinator']
        # Create coordinator with mock w3
        mock_w3 = MagicMock()
        mock_w3.eth.get_transaction_count.return_value = 100
        coord = TC(mock_w3, '0xWallet', None)
        # Acquire 5 nonces — must be sequential
        nonces = [coord.acquire_nonce()[0] for _ in range(5)]
        assert nonces == [100, 101, 102, 103, 104]

    def test_tx_coordinator_generation_rejection(self):
        """TxCoordinator must reject callbacks from old generations."""
        import re, threading, collections, time as _time
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        txop_match = re.search(r'(class TxOp:.*?)(?=\nclass TxCoordinator)', source, re.DOTALL)
        coord_match = re.search(r'(class TxCoordinator:.*?)(?=\n# ── Position Ledger)', source, re.DOTALL)
        ns = {'threading': threading, 'collections': collections, 'time': _time}
        exec(txop_match.group(1), ns)
        exec(coord_match.group(1), ns)
        TC = ns['TxCoordinator']
        mock_w3 = MagicMock()
        mock_w3.eth.get_transaction_count.return_value = 200
        coord = TC(mock_w3, '0xW', None)
        # Gen 0 — acquire nonce
        _nonce, gen0 = coord.acquire_nonce()
        assert coord.is_valid_generation(gen0)
        # Advance to gen 1
        coord.new_generation()
        assert not coord.is_valid_generation(gen0)  # Old gen rejected
        assert coord.is_valid_generation(coord.generation)  # Current gen valid

    def test_read_only_provider_blocks_send_raw(self):
        """ReadOnlyProvider must block eth_sendRawTransaction at transport level."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        ro_match = re.search(
            r"(_READ_ONLY_ALLOWED = frozenset.*?class ReadOnlyProvider:.*?)(?=\n# |\ndef |\nclass )",
            source, re.DOTALL)
        assert ro_match
        ns = {}
        exec(ro_match.group(1), ns)
        RO = ns['ReadOnlyProvider']
        mock_base = MagicMock()
        mock_base.make_request.return_value = {'result': '0x1'}
        prov = RO(mock_base)
        # eth_call must pass through
        result = prov.make_request('eth_call', [{}])
        assert result == {'result': '0x1'}
        # eth_sendRawTransaction must be blocked
        with pytest.raises(PermissionError):
            prov.make_request('eth_sendRawTransaction', [b'0xdead'])
        # eth_sendTransaction must be blocked
        with pytest.raises(PermissionError):
            prov.make_request('eth_sendTransaction', [{}])

    def test_read_only_provider_allows_all_read_rpcs(self):
        """ReadOnlyProvider must allow all standard read RPCs."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        ro_match = re.search(
            r"(_READ_ONLY_ALLOWED = frozenset.*?class ReadOnlyProvider:.*?)(?=\n# |\ndef |\nclass )",
            source, re.DOTALL)
        ns = {}
        exec(ro_match.group(1), ns)
        RO = ns['ReadOnlyProvider']
        mock_base = MagicMock()
        mock_base.make_request.return_value = {'result': '0x42'}
        prov = RO(mock_base)
        read_methods = ['eth_call', 'eth_getBalance', 'eth_getTransactionCount',
                        'eth_blockNumber', 'eth_chainId', 'eth_gasPrice',
                        'eth_estimateGas', 'eth_getTransactionReceipt']
        for method in read_methods:
            result = prov.make_request(method, [])
            assert result == {'result': '0x42'}, f"{method} should be allowed"

    def test_position_ledger_unresolved_lifecycle(self):
        """PositionLedger: create → mark_unresolved → verify state."""
        import re, time as _time
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        pl_match = re.search(r'(class PositionLedger:.*?)(?=\n# ── Read-Only|\nclass )', source, re.DOTALL)
        ns = {'time': _time}
        exec(pl_match.group(1), ns)
        PL = ns['PositionLedger']
        ledger = PL(token_addr='0xgone', symbol='GONE', route='pons',
                    managed_raw=1000, cost_basis_usd=5.00, residual_raw=1000)
        ledger.mark_unresolved()
        assert ledger.status == PL.UNRESOLVED
        assert not ledger.is_fully_resolved()
        # Net PnL should be None (no proceeds)
        assert ledger.net_pnl_usd is None


class TestAmendment6BugFixes:
    """Tests for concrete bugs identified by ChatGPT review of exported source."""

    def test_no_duplicate_gas_estimate_in_sell_quote(self):
        """SellQuote base dict must NOT include gas_estimate — each constructor
        call provides it explicitly to prevent duplicate keyword argument."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        fn = re.search(r'def get_sell_quote\(.*?\n(?=\ndef )', source, re.DOTALL)
        assert fn
        body = fn.group(0)
        # Find the base dict definition
        base_idx = body.find('base = dict(')
        assert base_idx >= 0
        base_end = body.find(')', base_idx)
        base_def = body[base_idx:base_end+1]
        assert 'gas_estimate' not in base_def, \
            "base dict must NOT contain gas_estimate — it's passed explicitly to each SellQuote"

    def test_nonce_helper_registers_durable_op(self):
        """_acquire_nonce must register a durable TxOp before returning nonce."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert 'register_op(' in source
        # The _acquire_nonce function must call register_op
        import re
        fn = re.search(r'def _acquire_nonce\(.*?\n(?=\ndef )', source, re.DOTALL)
        assert fn
        body = fn.group(0)
        assert 'register_op' in body, \
            "_acquire_nonce must register durable TxOp before returning"

    def test_resync_nonce_respects_pending(self):
        """resync_nonce must not reissue nonces with PENDING operations."""
        import re, threading, collections, time as _time, uuid
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        txop_match = re.search(r'(class TxOp:.*?)(?=\nclass TxCoordinator)', source, re.DOTALL)
        coord_match = re.search(r'(class TxCoordinator:.*?)(?=\n# ── Position Ledger)', source, re.DOTALL)
        ns = {'threading': threading, 'collections': collections, 'time': _time, 'uuid': uuid}
        exec(txop_match.group(1), ns)
        exec(coord_match.group(1), ns)
        TC = ns['TxCoordinator']
        TxOp = ns['TxOp']
        mock_w3 = MagicMock()
        # Chain nonce is 100, but we've issued nonces 100-104 already
        mock_w3.eth.get_transaction_count.return_value = 100
        coord = TC(mock_w3, '0xW', None)
        # Acquire 5 nonces (100-104)
        for _ in range(5):
            coord.acquire_nonce()
        # Register a pending op at nonce 103
        op = coord.register_op('sell', nonce=103)
        assert op.status == TxOp.PENDING
        # Resync — chain still at 100 but nonce 103 is pending
        coord.resync_nonce()
        # Next nonce must be >= 104 (not 100, which would reissue 100-103)
        next_n, _ = coord.acquire_nonce()
        assert next_n >= 104, \
            f"After resync with pending nonce 103, next must be >= 104, got {next_n}"

    def test_failed_residual_check_does_not_resolve(self):
        """If balance check fails after positive proceeds, _do_sell must return
        UNRESOLVED (fail closed), not RESOLVED."""
        import re
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        fn = re.search(r'def _do_sell\(.*?\n(?=\ndef )', source, re.DOTALL)
        assert fn
        body = fn.group(0)
        # After the positive proceeds path, exception handler must NOT set residual_raw = 0
        assert 'residual_raw = 0  # Balance check failed' not in body, \
            "Failed balance check must NOT default to residual_raw=0 (certifying sale)"
        # Must return UNRESOLVED on balance check failure
        assert 'UNRESOLVED' in body

    def test_duplicate_receipt_rejected(self):
        """PositionLedger.record_sell must reject duplicate tx_hash to prevent
        double-crediting proceeds."""
        import re, time as _time
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        pl_match = re.search(r'(class PositionLedger:.*?)(?=\n# ── Read-Only|\nclass )', source, re.DOTALL)
        ns = {'time': _time}
        exec(pl_match.group(1), ns)
        PL = ns['PositionLedger']
        ledger = PL(token_addr='0xtest', symbol='TEST', managed_raw=10000,
                    cost_basis_usd=50.00, residual_raw=10000)
        # First record — should apply
        ledger.record_sell(5000, 25.00, tx_hash='0xabc123')
        assert ledger.proceeds_usd == 25.00
        assert ledger.sold_raw == 5000
        # Duplicate record with same tx_hash — must be rejected
        ledger.record_sell(5000, 25.00, tx_hash='0xabc123')
        assert ledger.proceeds_usd == 25.00, \
            "Duplicate tx_hash must NOT double-credit proceeds"
        assert ledger.sold_raw == 5000, \
            "Duplicate tx_hash must NOT double-credit sold quantity"
        assert len(ledger.sell_tx_hashes) == 1

    def test_receipt_serialization_handles_attributedict(self):
        """PositionLedger.to_dict must normalize Web3 AttributeDict receipts."""
        import re, time as _time
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        pl_match = re.search(r'(class PositionLedger:.*?)(?=\n# ── Read-Only|\nclass )', source, re.DOTALL)
        ns = {'time': _time}
        exec(pl_match.group(1), ns)
        PL = ns['PositionLedger']
        ledger = PL(token_addr='0xtest', symbol='TEST', managed_raw=1000,
                    cost_basis_usd=10.00, residual_raw=1000)
        # Simulate a Web3 AttributeDict-like receipt
        class FakeAttributeDict:
            def __init__(self, d):
                self._d = d
            def items(self):
                return self._d.items()
            def __iter__(self):
                return iter(self._d)
            def keys(self):
                return self._d.keys()
            def values(self):
                return self._d.values()
            def __getitem__(self, k):
                return self._d[k]
        fake_receipt = FakeAttributeDict({'status': 1, 'blockNumber': 12345})
        ledger.record_sell(1000, 10.00, tx_hash='0xreceipt', receipt=fake_receipt)
        d = ledger.to_dict()
        # Receipts must be plain dicts, not AttributeDict
        assert isinstance(d['receipts'][0], dict), \
            "Receipts must be normalized to plain dict for JSON serialization"

    def test_do_sell_fail_closed_on_balance_error(self):
        """_do_sell: when balance check throws after positive proceeds,
        result must be UNRESOLVED, not RESOLVED."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        # Check the _do_sell function for fail-closed behavior
        import re
        fn = re.search(r'def _do_sell\(.*?\n(?=\ndef )', source, re.DOTALL)
        assert fn
        body = fn.group(0)
        # The except block after bal() for positive proceeds must return UNRESOLVED
        assert 'fail closed' in body.lower(), \
            "_do_sell must document fail-closed behavior on balance check failure"

    def test_nonce_only_wrapper_exists(self):
        """_nonce_only() backward-compatible wrapper must exist for build_transaction dicts."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        assert 'def _nonce_only(' in source
        assert '_nonce_only()' in source  # Used in build_transaction dicts

    def test_expired_quote_at_signing_detected(self):
        """Quote freshness must be re-checked at signing time — a quote that
        passed the 4-second decision cache could expire during approval/queue."""
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            source = f.read()
        # The sell functions must check quote freshness: they refuse to sign
        # when no valid quote is available (min_out == 0)
        for fn_name in ['v3_sell', 'v3_sell_spy']:
            fn_start = source.find(f'def {fn_name}(')
            assert fn_start >= 0
            fn_end = source.find('\ndef ', fn_start + 1)
            fn_body = source[fn_start:fn_end]
            assert 'refusing to sign' in fn_body, \
                f"{fn_name} must refuse to sign without executable quote"


class TestAmendment6Integration:
    """Tests for amendment 6 integration: zero-reset approvals, broadcast helpers,
    timeout handling, portfolio equity, and transport attempt recording."""

    def _load_source(self):
        with open('/root/shaheer-project/crypto-alpha-engine/repair/rh_rotation_engine.py') as f:
            return f.read()

    def _extract_class(self, source, class_name):
        """Extract a class definition from source."""
        import re
        pattern = rf'^class {class_name}[\s(:].*?(?=\n(?:class |def |\Z))'
        m = re.search(pattern, source, re.MULTILINE | re.DOTALL)
        return m.group(0) if m else None

    # ── Zero-reset approvals ──

    def test_approve_zero_reset_on_nonzero_insufficient(self):
        """approve() must approve(0) before approve(MAX) when current allowance
        is nonzero but insufficient — required by USDT-like tokens."""
        source = self._load_source()
        fn_start = source.find('def approve(addr):')
        assert fn_start >= 0
        fn_end = source.find('\ndef ', fn_start + 1)
        fn_body = source[fn_start:fn_end]
        # Must check if allowance > 0 and do zero-reset
        assert 'approve(spender, 0)' in fn_body or 'approve(permit2_ca, 0)' in fn_body, \
            "approve() must zero-reset when allowance is nonzero but insufficient"
        assert 'zero-reset' in fn_body.lower(), \
            "approve() must document zero-reset behavior"

    def test_permit2_zero_reset_on_nonzero_insufficient(self):
        """_ensure_permit2_approval() must zero-reset when ERC20 allowance to Permit2
        is nonzero but insufficient."""
        source = self._load_source()
        fn_start = source.find('def _ensure_permit2_approval(')
        assert fn_start >= 0
        fn_end = source.find('\ndef ', fn_start + 1)
        fn_body = source[fn_start:fn_end]
        assert 'approve(permit2_ca, 0)' in fn_body, \
            "_ensure_permit2_approval must zero-reset ERC20→Permit2 when nonzero but insufficient"

    # ── Transport attempt durable recording ──

    def test_txop_has_broadcast_attempted_at(self):
        """TxOp must have broadcast_attempted_at slot for recording when
        transport was attempted — crash recovery can distinguish 'never sent' from 'sent but no ack'."""
        source = self._load_source()
        txop_class = self._extract_class(source, 'TxOp')
        assert txop_class
        assert 'broadcast_attempted_at' in txop_class, \
            "TxOp must track broadcast_attempted_at for durable transport recording"
        assert 'signed_hash' in txop_class, \
            "TxOp must track signed_hash for intent verification"

    def test_broadcast_helper_records_before_send(self):
        """_broadcast() must record transport attempt durably BEFORE calling
        send_raw_transaction — crash-recovery needs this."""
        source = self._load_source()
        fn_start = source.find('def _broadcast(')
        assert fn_start >= 0, "_broadcast helper must exist"
        fn_end = source.find('\ndef ', fn_start + 1)
        fn_body = source[fn_start:fn_end]
        # Skip docstring — find the actual code body after triple-quote closes
        doc_end = fn_body.find('"""', fn_body.find('"""') + 3)
        code_body = fn_body[doc_end + 3:] if doc_end >= 0 else fn_body
        # Must mark broadcast BEFORE send_raw_transaction in code body
        mark_idx = code_body.find('mark_broadcast')
        send_idx = code_body.find('send_raw_transaction')
        assert mark_idx >= 0 and send_idx >= 0, \
            "_broadcast must call mark_broadcast and send_raw_transaction"
        assert mark_idx < send_idx, \
            "_broadcast must record transport attempt BEFORE calling send_raw_transaction"
        assert '_save_state()' in code_body, \
            "_broadcast must persist state before broadcast for crash safety"

    def test_broadcast_helper_records_tx_hash(self):
        """_broadcast() must record the tx_hash in the op after successful send."""
        source = self._load_source()
        fn_start = source.find('def _broadcast(')
        assert fn_start >= 0
        fn_end = source.find('\ndef ', fn_start + 1)
        fn_body = source[fn_start:fn_end]
        assert 'op.tx_hash' in fn_body, \
            "_broadcast must record tx_hash in the op after send"

    # ── Broadcast timeout handling ──

    def test_txop_has_timeout_status(self):
        """TxOp must have TIMEOUT status — distinct from FAILED. A timed-out tx
        may still confirm later; FAILED means no tx hash was obtained."""
        source = self._load_source()
        txop_class = self._extract_class(source, 'TxOp')
        assert txop_class
        assert "TIMEOUT = 'timeout'" in txop_class, \
            "TxOp must have TIMEOUT status (distinct from FAILED)"

    def test_wait_receipt_handles_timeout(self):
        """_wait_receipt() must handle timeout gracefully — mark op as TIMEOUT,
        not FAILED, and return None instead of raising."""
        source = self._load_source()
        fn_start = source.find('def _wait_receipt(')
        assert fn_start >= 0, "_wait_receipt helper must exist"
        fn_end = source.find('\ndef ', fn_start + 1)
        fn_body = source[fn_start:fn_end]
        assert 'mark_timeout' in fn_body, \
            "_wait_receipt must mark op as TIMEOUT on receipt timeout"
        assert 'confirm_op' in fn_body, \
            "_wait_receipt must confirm_op on successful receipt"

    def test_coordinator_has_unreconciled_check(self):
        """TxCoordinator.has_unreconciled() must detect pending/timed-out ops
        that need reconciliation before new buy/sell."""
        source = self._load_source()
        coord_class = self._extract_class(source, 'TxCoordinator')
        assert coord_class
        assert 'def has_unreconciled(self)' in coord_class, \
            "TxCoordinator must have has_unreconciled() method"
        assert 'TIMEOUT' in coord_class, \
            "has_unreconciled must check for TIMEOUT ops"

    def test_coordinator_reconcile_op(self):
        """TxCoordinator.reconcile_op() must attempt to check on-chain receipt
        for a timed-out operation."""
        source = self._load_source()
        coord_class = self._extract_class(source, 'TxCoordinator')
        assert coord_class
        assert 'def reconcile_op(self' in coord_class, \
            "TxCoordinator must have reconcile_op() method"
        assert 'get_transaction_receipt' in coord_class, \
            "reconcile_op must check on-chain receipt"

    # ── Portfolio equity without double-counting ──

    def test_portfolio_equity_includes_weth(self):
        """_portfolio_equity() must include WETH balance — not just native ETH.
        Omitting WETH underestimates equity during V3/V4 swaps."""
        source = self._load_source()
        fn_start = source.find('def _portfolio_equity():')
        assert fn_start >= 0, "_portfolio_equity function must exist"
        fn_end = source.find('\ndef ', fn_start + 1)
        fn_body = source[fn_start:fn_end]
        assert 'WETH' in fn_body or 'weth' in fn_body, \
            "_portfolio_equity must include WETH balance"
        assert 'spy_bal_usd' in fn_body, \
            "_portfolio_equity must include SPY"
        assert 'usdg_bal' in fn_body, \
            "_portfolio_equity must include USDG"

    def test_portfolio_equity_no_double_counting(self):
        """_portfolio_equity() must not double-count partial proceeds that are
        already in the ETH balance."""
        source = self._load_source()
        fn_start = source.find('def _portfolio_equity():')
        assert fn_start >= 0
        fn_end = source.find('\ndef ', fn_start + 1)
        fn_body = source[fn_start:fn_end]
        # Must subtract proceeds already in ETH from managed position value
        assert 'proceeds_usd' in fn_body, \
            "_portfolio_equity must account for proceeds already in ETH balance"

    def test_daily_drawdown_uses_portfolio_equity(self):
        """_check_daily_drawdown() must use _portfolio_equity() for reconciled equity,
        not just eth_bal() + spy_bal_usd() + usdg_bal()."""
        source = self._load_source()
        fn_start = source.find('def _check_daily_drawdown():')
        assert fn_start >= 0
        fn_end = source.find('\ndef ', fn_start + 1)
        fn_body = source[fn_start:fn_end]
        assert '_portfolio_equity()' in fn_body, \
            "_check_daily_drawdown must use _portfolio_equity() for reconciled equity"

    # ── TxCoordinator timeout lifecycle (end-to-end with real class) ──

    def test_txop_timeout_lifecycle(self):
        """TxOp: PENDING → TIMEOUT → reconciled (CONFIRMED or stays TIMEOUT).
        Exercises the real TxOp class."""
        import re as _re, time as _time, uuid as _uuid, threading as _threading, collections as _collections
        source = self._load_source()
        # Extract TxOp and TxCoordinator classes
        txop_match = _re.search(r'^(class TxOp:.*?)(?=\nclass )', source, _re.MULTILINE | _re.DOTALL)
        coord_match = _re.search(r'^(class TxCoordinator:.*?)(?=\n# ── )', source, _re.MULTILINE | _re.DOTALL)
        assert txop_match and coord_match
        ns = {'time': _time, 'uuid': _uuid, 'threading': _threading, 'collections': _collections}
        exec(txop_match.group(1), ns)
        exec(coord_match.group(1), ns)
        TxOp = ns['TxOp']
        TxCoordinator = ns['TxCoordinator']

        # Create op and transition through timeout lifecycle
        op = TxOp('sell', nonce=42, token_addr='0xAABB')
        assert op.status == TxOp.PENDING

        # Mark broadcast attempt
        op.broadcast_attempted_at = _time.time()
        op.signed_hash = 'abc123'
        assert op.broadcast_attempted_at is not None

        # Timeout
        op.status = TxOp.TIMEOUT
        op.error = 'receipt timeout'
        assert op.status == TxOp.TIMEOUT

        # Serialize and restore
        d = op.to_dict()
        assert d['status'] == 'timeout'
        assert 'broadcast_attempted_at' in d
        assert d['signed_hash'] == 'abc123'

        # Restore
        op2 = TxOp(d['op_type'], **{k: v for k, v in d.items() if k != 'op_type'})
        assert op2.status == TxOp.TIMEOUT
        assert op2.broadcast_attempted_at == op.broadcast_attempted_at
        assert op2.nonce == 42

    def test_coordinator_timeout_and_reconcile(self):
        """TxCoordinator: mark_timeout → has_unreconciled → reconcile_op.
        Uses mock w3 to simulate receipt check."""
        import re as _re, time as _time, uuid as _uuid, threading as _threading, collections as _collections
        source = self._load_source()
        txop_match = _re.search(r'^(class TxOp:.*?)(?=\nclass )', source, _re.MULTILINE | _re.DOTALL)
        coord_match = _re.search(r'^(class TxCoordinator:.*?)(?=\n# ── )', source, _re.MULTILINE | _re.DOTALL)
        assert txop_match and coord_match
        ns = {'time': _time, 'uuid': _uuid, 'threading': _threading, 'collections': _collections}
        exec(txop_match.group(1), ns)
        exec(coord_match.group(1), ns)
        TxCoordinator = ns['TxCoordinator']

        # Mock w3 that returns nonce 100 and a receipt on reconcile
        class MockW3:
            class eth:
                @staticmethod
                def get_transaction_count(addr):
                    return 100
                @staticmethod
                def get_transaction_receipt(tx_hash):
                    return {'status': 1, 'transactionHash': tx_hash, 'blockNumber': 999}

        coord = TxCoordinator(MockW3(), '0xWallet', None)
        nonce, gen = coord.acquire_nonce()
        op = coord.register_op('sell', nonce=nonce, token_addr='0xToken')

        # Mark broadcast and timeout
        coord.mark_broadcast(op.op_id, signed_hash='0xabc')
        coord.mark_timeout(op.op_id, error='receipt timeout 120s')

        assert coord.has_unreconciled()
        assert len(coord.timeout_ops()) == 1

        # Reconcile — mock returns receipt
        op.tx_hash = '0xdef'
        reconciled = coord.reconcile_op(op.op_id)
        assert reconciled.status == 'confirmed'
        assert not coord.has_unreconciled()

    def test_coordinator_mark_broadcast_before_send(self):
        """mark_broadcast must be callable before send, recording timestamp and signed hash."""
        import re as _re, time as _time, uuid as _uuid, threading as _threading, collections as _collections
        source = self._load_source()
        txop_match = _re.search(r'^(class TxOp:.*?)(?=\nclass )', source, _re.MULTILINE | _re.DOTALL)
        coord_match = _re.search(r'^(class TxCoordinator:.*?)(?=\n# ── )', source, _re.MULTILINE | _re.DOTALL)
        assert txop_match and coord_match
        ns = {'time': _time, 'uuid': _uuid, 'threading': _threading, 'collections': _collections}
        exec(txop_match.group(1), ns)
        exec(coord_match.group(1), ns)
        TxCoordinator = ns['TxCoordinator']

        class MockW3:
            class eth:
                @staticmethod
                def get_transaction_count(addr):
                    return 50
        coord = TxCoordinator(MockW3(), '0xW', None)
        nonce, gen = coord.acquire_nonce()
        op = coord.register_op('buy', nonce=nonce)

        # Before marking broadcast
        assert op.broadcast_attempted_at is None
        assert op.signed_hash is None

        # Mark broadcast
        before = _time.time()
        coord.mark_broadcast(op.op_id, signed_hash='0x1234')
        after = _time.time()

        assert op.broadcast_attempted_at is not None
        assert before <= op.broadcast_attempted_at <= after
        assert op.signed_hash == '0x1234'
        assert op.status == 'pending'  # Still pending — not yet confirmed
