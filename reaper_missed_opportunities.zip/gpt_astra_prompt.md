# GPT Astra 6 — REAPER Liquidation Engine Speed & Execution Fix

## Context

I have a DeFi liquidation engine called REAPER (v5.4.5) running on a Linux server, monitoring 9 blockchains and 7 lending protocols (AAVE V3, Morpho, Venus, Benqi, Moonwell, Mendi, LayerBank). It's written in Python, uses Web3, and runs as a systemd service.

In the last 2.5 hours of running, the engine has:
- **Identified 6,273 profitable liquidation candidates** totaling **$24.3 million in estimated profit**
- **Executed ZERO actual liquidations**
- **Earned $0**

## The Problem — Why It Can't Execute

Here are the specific failure reasons, ranked by frequency:

### Blocker #1: EXECUTOR_MIGRATION_REQUIRED (4,607 times — Ethereum Morpho only)
The Morpho liquidation executor contract on Ethereum needs migration to V4. The existing executor is `0x1efd7FED19B5756F8E44862189D7e3414987a436`. The engine's morpho_prepare pipeline rejects every Ethereum Morpho candidate because it detects the executor version is outdated. **This blocks $24.2M worth of opportunities — 99.7% of all missed profit.**

Questions:
1. What does "executor migration to V4" mean in the context of Morpho Blue liquidations? Is this a contract redeployment, a proxy upgrade, or a configuration change?
2. What specific steps are needed to migrate/deploy a V4 executor for Morpho on Ethereum?
3. Is there a way to check what version the current executor is and what V4 requires?

### Blocker #2: EXECUTOR_MISSING on Scroll (2,143 times)
No executor contract deployed on Scroll (chain_id 534352). The engine-ready config shows Scroll is DEFERRED with `executor_and_treasury` gate failures.

### Blocker #3: NO_PROFITABLE_ROUTE (4,157 times — Arbitrum 2,475, Polygon 553, Ethereum 526, Optimism 353, Base 251)
The engine finds liquidatable positions but the DEX aggregator can't find a swap route from seized collateral to debt token that's profitable after slippage/fees.

Questions:
1. What DEX aggregators work best for liquidation swap routing? (Currently using built-in aggregator)
2. Would integrating 1inch, Paraswap, or CowSwap API improve route quality?
3. Are there private market maker routes or RFQ systems that liquidation bots typically use?

### Blocker #4: Preparation Speed
Timing data from 232,777 preparation attempts:
- Median: 186ms
- P90: 15.6 seconds  
- 42,256 attempts (18%) took >10 seconds
- 13,426 attempts (5.8%) took >20 seconds
- Max: 303 seconds (5 minutes!)

421 opportunities were lost specifically to PREPARATION_DEADLINE_EXPIRED.

Questions:
1. What is the typical preparation time for competitive liquidation bots?
2. How can we reduce preparation time from 15s (P90) to sub-second?
3. Should we pre-compute execution paths and cache them?
4. Would dedicated RPC nodes (vs shared Chainstack) significantly help?

### Blocker #5: Protocols in MONITOR_ONLY mode
Morpho on Base and Optimism are set to MONITORING_ONLY — seeing candidates but not executing. Moonwell on Base and Optimism is also MONITOR_ONLY.

### Blocker #6: DEBT_USD_FEED_MISSING (934 times — ETH 416, Polygon 401, Base 118)
Missing price feeds for certain debt tokens.

## What I Need From You

1. **Immediate fix for the Morpho V4 executor migration on Ethereum** — step-by-step instructions. This is the #1 priority since it blocks $24.2M in opportunities.

2. **Architecture recommendations to make the engine faster:**
   - How do professional MEV/liquidation bots achieve sub-100ms execution?
   - What infrastructure changes would have the biggest impact?
   - Should we use Flashbots Protect / MEV-Share / private transaction pools?
   - Should we pre-build liquidation transactions and just submit them when conditions are met?

3. **DEX aggregation improvements** — what's the best approach for liquidation swap routing to reduce NO_PROFITABLE_ROUTE failures?

4. **Priority list** — if you could only fix 3 things, what would give us the most profit the fastest?

## Technical Environment
- Server: Linux (Ubuntu), 64GB RAM, dedicated server
- RPC: Chainstack (shared endpoints, not dedicated)
- Engine: Python, asyncio, Web3.py
- Chains: Ethereum, Arbitrum, Base, Polygon, Optimism, BNB, Avalanche, Gnosis, Linea, Scroll, Mantle
- Protocols: AAVE V3, Morpho Blue, Venus, Benqi, Moonwell, Mendi, LayerBank
- Existing Morpho executor on ETH: `0x1efd7FED19B5756F8E44862189D7e3414987a436`
- Pendle adapter: `0xDB02EA09f2eCd3e180E652664E6d67780CDEa4DE`
- Engine release: `/opt/reaper/releases/20260914T111734Z-tDjgcOSv`

## Constraints
- Do NOT suggest using Alchemy — we only use Chainstack
- Do NOT suggest using OpenAI API
- Budget-conscious — prioritize free/low-cost solutions first
- We have Codex CLI + ChatGPT Pro (GPT Astra 6) available for coding assistance
