# REAPER Missed Liquidation Opportunities — Full Analysis
## Date: 2026-09-14 | Engine: v5.4.5 | Release: 20260914T111734Z-tDjgcOSv

---

## EXECUTIVE SUMMARY

REAPER has been running for ~2.5 hours across 9 live chains, monitoring 7 lending protocols (AAVE, Morpho, Venus, Benqi, Moonwell, Mendi, LayerBank). In that time:

- **6,273 profitable liquidation candidates identified**
- **$24,329,634 in estimated total missed profit**
- **ZERO actual liquidations executed**
- **ZERO dollars earned**

The engine sees the opportunities. It calculates the profit. But it CANNOT execute them.

---

## TOP 20 MISSED OPPORTUNITIES

| # | Chain | Protocol | Expected Net Profit | Borrower |
|---|-------|----------|-------------------|----------|
| 1 | Ethereum | Morpho | $46,565.93 | 0x5ceDE91b3c5783d093... |
| 2 | Ethereum | Morpho | $42,756.31 | 0x7C6211aB60FDa17EEc... |
| 3 | Ethereum | Morpho | $37,699.13 | 0xae0a739c3724bB5Cd2... |
| 4 | Ethereum | Morpho | $17,511.90 | 0x2385233abb910357e2... |
| 5 | Ethereum | Morpho | $16,611.07 | 0x2385233abb910357e2... |
| 6 | Ethereum | Morpho | $12,816.55 | 0xaFbf278e06D2269abA... |
| 7 | Ethereum | Morpho | $12,780.82 | 0x6DDb8eAC7aD4f906D6... |
| 8 | Ethereum | Morpho | $11,395.21 | 0xAa34d20be3F9623ccF... |
| 9 | Ethereum | Morpho | $10,961.50 | 0x6DDb8eAC7aD4f906D6... |
| 10 | Ethereum | Morpho | $10,407.54 | 0xaFbf278e06D2269abA... |
| 11 | Ethereum | AAVE | $8,500.26 | 0x852F79dAd4e6C44a89... |
| 12-20 | Ethereum | AAVE | $8,500 each | 0x852F79dAd4e6C44a89... (same borrower, repeated) |

**$24.25M of the $24.33M total is on Ethereum alone.**

---

## ROOT CAUSE ANALYSIS — WHY EVERY SINGLE ONE WAS MISSED

### Cause #1: EXECUTOR_MIGRATION_REQUIRED (4,607 occurrences — Ethereum Morpho)
- **Chain:** Ethereum (chain_id=1)
- **What it means:** The Morpho liquidation executor contract on Ethereum needs to be migrated to V4. The current executor (`0x1efd7FED19B5756F8E44862189D7e3414987a436`) exists, but the engine's Morpho preparation pipeline requires a newer executor version that hasn't been deployed yet.
- **Impact:** This is the #1 blocker. ALL of the $46K, $42K, $37K, $17K, $16K, $12K, $11K, $10K opportunities on Ethereum Morpho were blocked by this.
- **This alone accounts for ~$24.2M in missed opportunities.**

### Cause #2: EXECUTOR_MISSING (2,143 occurrences — Scroll)
- **Chain:** Scroll (chain_id=534352)
- **What it means:** No executor contract deployed on Scroll at all. The engine-ready config confirms Scroll is DEFERRED with `executor_and_treasury` gate failures.
- **Impact:** Any Morpho liquidations on Scroll are completely blocked.

### Cause #3: NO_PROFITABLE_ROUTE (4,157 occurrences — multiple chains)
- **Breakdown:** Arbitrum 2,475 | Polygon 553 | Ethereum 526 | Optimism 353 | Base 251
- **What it means:** The engine found liquidatable positions, but the DEX swap route to convert seized collateral back to the debt token wasn't profitable after slippage/fees. The aggregator couldn't find a good enough route.
- **This is a market/liquidity issue** — not a configuration issue. These would require better DEX aggregation or private market maker routes.

### Cause #4: DEBT_USD_FEED_MISSING (934 occurrences)
- **Breakdown:** Ethereum 416 | Polygon 401 | Base 118
- **What it means:** The engine doesn't have a USD price feed for the debt token, so it can't calculate profitability. Likely exotic/new tokens that aren't in the price oracle.

### Cause #5: NO_REPAYABLE_COLLATERAL (791 occurrences)
- **Breakdown:** Arbitrum 440 | Polygon 152 | Ethereum 105 | Base 94
- **What it means:** The seized collateral can't cover the debt repayment. Position is undercollateralized beyond what liquidation can recover.

### Cause #6: PREPARATION_DEADLINE_EXPIRED (421 occurrences)
- **Breakdown:** Optimism 159 | Base 158 | Ethereum 105
- **What it means:** The engine took too long to prepare the liquidation transaction. By the time it was ready, the opportunity window had closed (someone else liquidated it, or the position recovered).
- **Timing data:** Median preparation time is 186ms, but P90 is 15.6 seconds. 42,256 preparations took >10s. 13,426 took >20s.

### Cause #7: CONTRACT_SIMULATION_REVERT (6 occurrences — Ethereum)
- **What it means:** The liquidation TX was built and simulated, but reverted on-chain simulation. Could be stale state, front-running, or edge case.

---

## LIFECYCLE OF A TYPICAL MISSED $46K OPPORTUNITY

```
Borrower: 0x5ceDE91b3c5783d093... (Ethereum Morpho)

1. [T+0.000s] morpho_quote — Engine spots liquidatable position, gets quote (146ms)
2. [T+0.176s] morpho_quote — Second quote attempt (176ms)  
3. [T+0.360s] morpho_quote — Third quote (183ms)
4. [T+0.523s] morpho_quote — Fourth quote (163ms)
5. [T+1.228s] morpho_prepare — Starts preparation (3.7 seconds)
6. ... Engine tries to prepare execution path ...
7. BLOCKED: EXECUTOR_MIGRATION_REQUIRED
8. ... Position keeps getting re-queued and expiring over hours ...
9. [T+85402s] candidate_preparation_expired — Still can't execute, expired again
```

The engine SEES it. It QUOTES it. It knows it's worth $46,565. But it physically cannot execute because the Morpho executor contract needs migration.

---

## TIMING ANALYSIS

| Metric | Value |
|--------|-------|
| Total preparation attempts | 232,777 |
| Median preparation time | 186ms |
| Average preparation time | 4,888ms |
| P90 preparation time | 15,672ms |
| Preparations >10 seconds | 42,256 (18%) |
| Preparations >20 seconds | 13,426 (5.8%) |
| Max preparation time | 303,669ms (5 minutes!) |

---

## CHAIN-BY-CHAIN MISSED PROFIT

| Chain | Missed Profit | Primary Blocker |
|-------|--------------|-----------------|
| Ethereum | $24,255,069 | EXECUTOR_MIGRATION_REQUIRED (Morpho) |
| Arbitrum | $56,969 | NO_PROFITABLE_ROUTE |
| Base | $13,235 | NO_PROFITABLE_ROUTE / DEADLINE_EXPIRED |
| BNB | $3,691 | (smaller positions) |
| Polygon | $670 | NO_PROFITABLE_ROUTE / DEBT_FEED_MISSING |

---

## DEFERRED / BLOCKED CHAINS & PROTOCOLS

### Chains not executing:
- **Scroll:** DEFERRED — executor_and_treasury gate failure (EXECUTOR_MISSING)
- **Mantle:** DEFERRED — funding, keeper, treasury, route config all missing

### Protocols in MONITOR_ONLY mode (seeing but not executing):
- **Morpho on Base** — MONITORING_ONLY
- **Morpho on Optimism** — MONITORING_ONLY
- **Moonwell on Base** — MONITORING_ONLY
- **Moonwell on Optimism** — MONITORING_ONLY

---

## WHAT NEEDS TO HAPPEN TO START MAKING MONEY

### Priority 1 — CRITICAL (unlocks $24M+ opportunity pool):
**Deploy/migrate Morpho V4 executor on Ethereum.** The `EXECUTOR_MIGRATION_REQUIRED` error is blocking ALL Ethereum Morpho liquidations. This is where 99.7% of the missed profit is.

### Priority 2 — HIGH:
**Enable Morpho execution on Base and Optimism** (currently MONITORING_ONLY). These chains have profitable candidates being seen but not acted on.

### Priority 3 — MEDIUM:
**Deploy executor on Scroll.** Currently EXECUTOR_MISSING.

### Priority 4 — SPEED:
**Reduce preparation time.** 18% of preparations take >10 seconds. For time-sensitive liquidations, we need sub-second preparation. This may require:
- Pre-computed execution paths cached and ready
- Faster RPC responses (dedicated nodes vs shared Chainstack)
- Pre-signed approval transactions
- Mempool monitoring for early detection

### Priority 5 — COVERAGE:
**Add missing price feeds** for debt tokens (934 missed due to DEBT_USD_FEED_MISSING).
**Configure Mantle** to bring another chain online.

---

## RAW DATA FILES INCLUDED IN THIS ZIP

1. `reaper_missed_opportunities_report.md` — This report
2. `reaper_missed_opportunities_raw.json` — Full event data (economics, declined, expired, etc.)
3. `reaper_big_misses.json` — All 6,083 evaluations with expected_net > $1, sorted by profit
4. `reaper_engine_ready.json` — Engine configuration and chain states
5. `gpt_astra_prompt.md` — Ready-to-paste prompt for GPT Astra 6

