# EXISTING INFRASTRUCTURE — Available for Skeletor ARB Engine

**Purpose:** This document lists every piece of infrastructure we already own and operate that Skeletor can reuse. The builder (GPT Astra 6) should leverage ALL of this rather than building from scratch.

---

## 1. SERVER

| Spec | Value |
|------|-------|
| CPU | 32-core Intel Xeon Platinum 8280 @ 2.70GHz |
| RAM | 62 GB (39 GB available after REAPER) |
| OS | Ubuntu 24.04.4 LTS, Linux 6.8.0 |
| Python | 3.12.3 |
| IP | 104.248.159.95 |
| Init | systemd (all services managed via systemd units) |
| Disk | SSD, ample space |

**Resource budget for Skeletor:** Up to 8 cores, 8 GB RAM comfortably. The REAPER liquidation engine uses ~2-4 cores and ~4 GB RAM.

---

## 2. RPC PROVIDER — CHAINSTACK (PAID TIER)

We have **Chainstack paid plan** with dedicated endpoints for all 11 EVM chains. Both HTTP and WebSocket (WSS) endpoints are available.

**DO NOT use Alchemy. We only use Chainstack.**

| Chain | Chain ID | HTTP RPC | WSS RPC |
|-------|----------|----------|---------|
| Ethereum | 1 | `https://ethereum-mainnet.core.chainstack.com/<key>` | `wss://ethereum-mainnet.core.chainstack.com/<key>` |
| Arbitrum | 42161 | `https://arbitrum-mainnet.core.chainstack.com/<key>` | `wss://arbitrum-mainnet.core.chainstack.com/<key>` |
| Base | 8453 | `https://base-mainnet.core.chainstack.com/<key>` | `wss://base-mainnet.core.chainstack.com/<key>` |
| Polygon | 137 | `https://polygon-mainnet.core.chainstack.com/<key>` | `wss://polygon-mainnet.core.chainstack.com/<key>` |
| Optimism | 10 | `https://optimism-mainnet.core.chainstack.com/<key>` | `wss://optimism-mainnet.core.chainstack.com/<key>` |
| BNB Chain | 56 | `https://bsc-mainnet.core.chainstack.com/<key>` | `wss://bsc-mainnet.core.chainstack.com/<key>` |
| Avalanche | 43114 | `https://avalanche-mainnet.core.chainstack.com/ext/bc/C/rpc/<key>` | `wss://avalanche-mainnet.core.chainstack.com/ext/bc/C/ws/<key>` |
| Gnosis | 100 | `https://gnosis-mainnet.core.chainstack.com/<key>` | `wss://gnosis-mainnet.core.chainstack.com/<key>` |
| Scroll | 534352 | `https://scroll-mainnet.core.chainstack.com/<key>` | `wss://scroll-mainnet.core.chainstack.com/<key>` |
| Linea | 59144 | `https://linea-mainnet.core.chainstack.com/<key>` | `wss://linea-mainnet.core.chainstack.com/<key>` |
| Mantle | 5000 | `https://rpc.mantle.xyz` (public) | N/A |

> **Note:** `<key>` placeholders represent unique Chainstack API keys per chain. The actual keys are stored in `/etc/reaper/reaper.env` on the VPS. Skeletor should read these from environment variables at runtime — NEVER hardcode them.

### Chainstack Advantages
- Dedicated endpoints (not shared/public)
- Higher rate limits than free RPCs
- WebSocket support for real-time event streaming
- Lower latency (~50-100ms to most chains)
- Archive node access where available

---

## 3. KEEPER WALLETS (One Per Chain)

These wallets are already funded with native gas tokens and are used by REAPER. Skeletor can either **reuse these** (with nonce coordination) or **generate new wallets** (recommended to avoid conflicts).

| Chain | Keeper Address | Native Token |
|-------|---------------|-------------|
| Ethereum | `0x763563240FA18b7d92D3DA307802872BBBa96a32` | ETH |
| Arbitrum | `0xAC08dee465B6a9256bdc385582Cb01Cc6eF15A81` | ETH |
| Base | `0x759A424B133c71d8c3a58521b0a0e4ef2d30e66F` | ETH |
| Polygon | `0xf2ea3FF36680b73A0e77Fc00C1dCcf09608e4e51` | POL |
| Optimism | `0x7F74ef1FDbf498Ae232576CBeb77062f5B4e4a7E` | ETH |
| BNB Chain | `0xa1F98440625972b48562EE97F2C69dA5d4022731` | BNB |
| Avalanche | `0x168fb0fC5b58eC59d8101f805154AC9BB9CC7e73` | AVAX |
| Gnosis | `0x0E28ADBb1f19DC3bE726c70A97816Bc9E92Ba248` | xDAI |
| Scroll | `0x00E41aD44Fa33fc2871A5D08CaDBe7EAB852F9B4` | ETH |
| Linea | `0xcbDf02d2A99255A518f62beD1403FFb7Cbd382A7` | ETH |
| Mantle | `0x93Dc0C6C4aB4d72be3665aE9d13c200345dC23C5` | MNT |

> **RECOMMENDATION:** Generate fresh wallets for Skeletor. If both REAPER and Skeletor send TXs from the same wallet simultaneously, nonce collisions will cause failures. Fresh wallets = zero coordination overhead.

### Funding Wallets (Can send gas to new Skeletor wallets)

| Chain | Funding Address |
|-------|----------------|
| Ethereum | `0xa7CBD4CA8A1EEC70c6D9ACCb2e4003655dB05126` |
| Arbitrum | `0xdA48d445055509adEbd6141F29F75Ef331C59123` |
| Base | `0x6137743C05d48BBda7C6e18c6B3eEf07D81acfAB` |
| Polygon | `0xD1cd944A18a378deD91106a58addd541785c0368` |
| Optimism | `0x99563B7409cf11CCFB7Dc908F0549667CB80Aa20` |
| BNB Chain | `0x243a6CeFF0216e0A5E3a1E9bd11FF7334c7D7f21` |
| Avalanche | `0x3A1377555CefAd17A7f3d26C036EC4814ae9Ec9d` |
| Gnosis | `0xbDf9378ea9f2656614F2Bf7bBaca6BF7DE33c6d0` |
| Scroll | `0xD19cb864467EA0F2EC4D08F13977161d39Fd488e` |
| Linea | `0x522eBa0E688a0701A56fcb5dA84153f9297c4d8d` |
| Mantle | `0x66529e4D87885eb22eb4A8B6C54D3d87E4a895F0` |

---

## 4. DEPLOYED SMART CONTRACTS (REAPER — Reference Only)

These are REAPER's contracts. Skeletor needs its OWN contracts, but these show the deployment pattern and owner/treasury setup we use.

| Component | Chain | Address |
|-----------|-------|---------|
| V4 Executor | Ethereum | `0x1efd7FED19B5756F8E44862189D7e3414987a436` |
| Executor | Arbitrum | `0x26544e60aA28b9912b3C8af0Da774E5B97292C2c` |
| Treasury | Ethereum | `0xB3C1B3670aBBE92459cced7A875B92B8045b8eB2` |
| Owner | Ethereum | `0x0be30E1d830f066E709B38A92C5755A6EadFA741` |
| Pendle Adapter | Ethereum | `0xDB02EA09f2eCd3e180E652664E6d67780CDEa4DE` |

---

## 5. FLASH LOAN PROVIDERS (Already Integrated in REAPER)

### Morpho — 0% Fee Flash Loans
- **Status:** LIVE on Ethereum, integrated in REAPER v5.4.5
- **Key advantage:** ZERO fee flash loans — borrow any amount, pay back same amount
- **Markets:** ETH, USDC, USDT, DAI, WBTC, wstETH, and more
- **Available chains:** Ethereum (confirmed), Base (expanding)
- **Skeletor use:** PRIMARY flash loan source wherever available

### AAVE V3 — 0.05% Fee Flash Loans
- **Status:** LIVE on all our chains except Mantle, integrated in REAPER
- **Fee:** 0.05% of borrowed amount (e.g., borrow $100,000 → pay $50 fee)
- **Markets:** All major tokens on all supported chains
- **Available chains:** Ethereum, Arbitrum, Base, Polygon, Optimism, BNB, Avalanche, Gnosis, Scroll, Linea
- **Skeletor use:** FALLBACK when Morpho unavailable

### Balancer V2 — 0% Fee Flash Loans
- **Status:** Available but NOT integrated in REAPER yet
- **Key advantage:** ZERO fee, like Morpho
- **Vault address:** `0xBA12222222228d8Ba445958a75a0704d566BF2C8` (same on all chains)
- **Available chains:** Ethereum, Polygon, Arbitrum, Gnosis, Avalanche, Base, Optimism
- **Skeletor use:** SECONDARY source — free flash loans on multiple chains

---

## 6. VELORA SWAP ROUTING API (PAID)

- **Status:** LIVE — returning 200 OK quotes
- **Access method:** WARP proxy (persistent systemd service + DNS refresh timer every 5 min)
- **API key:** Stored in `/etc/reaper/reaper.env` as `REAPER_VELORA_API_KEY`
- **Capabilities:** Optimal swap routing across DEXs, price quotes, slippage estimation
- **Chains supported:** Polygon, Optimism, Ethereum (confirmed working)
- **Skeletor use:** Can use for price discovery and route optimization as a supplementary data source. However, Skeletor's primary price source should be direct DEX pool state monitoring via WebSocket (faster, no API dependency).

---

## 7. REAPER v5.4.5 — Currently Running Alongside

The REAPER liquidation engine is running on the same VPS. Key details for coexistence:

| Detail | Value |
|--------|-------|
| Release | `20260914T111734Z-tDjgcOSv` |
| Install path | `/opt/reaper/current` (symlink to releases dir) |
| Service | `reaper-engine.service` (systemd) |
| Config | `/etc/reaper/reaper.env` |
| State | `/var/lib/reaper/state/` |
| Metrics DB | `/var/lib/reaper/state/metrics.sqlite3` |
| PID | Active, 9 chains LIVE |
| Chains LIVE | ETH, ARB, Base, Polygon, OP, BNB, AVAX, Gnosis, Linea |
| Chains DEFERRED | Scroll (executor deploying), Mantle (config pending) |
| Protocols | AAVE, Morpho, Venus, Benqi, Moonwell, Mendi, LayerBank |

### Coexistence Rules
1. Skeletor runs as a **separate systemd service** — never inside REAPER's process
2. Skeletor gets its own `/opt/skeletor/` directory, `/var/lib/skeletor/` state, `/var/log/skeletor/` logs
3. If sharing RPC endpoints, be aware of rate limits — Chainstack paid tier has generous limits but not infinite
4. **DO NOT** modify any REAPER files, config, or state — REAPER has release verification that blocks startup if files change
5. Skeletor can READ REAPER's env file to extract RPC URLs (or better: share them via a common env include)

---

## 8. PROTOCOLS ON EACH CHAIN (What REAPER Monitors)

This shows the lending protocols per chain. Useful context because flash loan availability often matches lending protocol deployment:

| Chain | Protocols |
|-------|-----------|
| Ethereum | AAVE, Morpho |
| Arbitrum | AAVE, Morpho |
| Base | AAVE, Moonwell, Morpho |
| Polygon | AAVE, Morpho |
| Optimism | AAVE |
| BNB Chain | AAVE, Venus, Morpho |
| Avalanche | AAVE, Benqi, Morpho |
| Gnosis | AAVE, Morpho |
| Linea | AAVE, Mendi, LayerBank, Morpho |
| Scroll | Morpho (deploying) |
| Mantle | (deferred) |

---

## 9. GAS FUNDING CONFIGURATION

Each chain has configured gas limits that REAPER uses. Skeletor should use similar conservative settings:

| Chain | Max TX Fee | Max Daily Fee | Native Unit |
|-------|-----------|--------------|-------------|
| Ethereum | 0.005 ETH | 0.02 ETH | ETH |
| Arbitrum | 0.0005 ETH | 0.005 ETH | ETH |
| Base | 0.0005 ETH | 0.005 ETH | ETH |
| Polygon | 1 POL | 5 POL | POL |
| Optimism | 0.0005 ETH | 0.005 ETH | ETH |
| BNB | 0.005 BNB | 0.015 BNB | BNB |
| Avalanche | 0.005 AVAX | 0.025 AVAX | AVAX |
| Gnosis | 0.001 xDAI | 0.005 xDAI | xDAI |
| Scroll | 0.0005 ETH | 0.005 ETH | ETH |
| Linea | 0.0005 ETH | 0.005 ETH | ETH |
| Mantle | 0.051 MNT | 0.25 MNT | MNT |

---

## 10. DEVELOPMENT ENVIRONMENT

| Tool | Version/Detail |
|------|---------------|
| Python | 3.12.3 |
| pip | Available, standard library |
| Node.js | If needed for Solidity tooling (Hardhat/Foundry) |
| Solidity compiler | Install `solc` or use `py-solc-x` or Foundry's `forge` |
| Git | Available |
| systemd | For service management |
| SQLite | Built into Python 3.12 |
| web3.py | Install via pip |
| eth-abi | Install via pip |

### Recommended Additional Dependencies
```
pip install web3 eth-abi websockets aiohttp
```

For Solidity compilation, either:
- **Foundry** (recommended): `curl -L https://foundry.paradigm.xyz | bash && foundryup`
- **Hardhat**: `npm install --save-dev hardhat`
- **py-solc-x**: `pip install py-solc-x`

---

## 11. SECURITY CONSTRAINTS

1. **NEVER** hardcode private keys in source code — load from env vars only
2. **NEVER** log private keys, seed phrases, or API credentials
3. **NEVER** commit secrets to git
4. All private keys are stored in `/etc/reaper/reaper.env` (root-only readable)
5. Skeletor should use the same pattern: `/etc/skeletor/skeletor.env` with `chmod 600`
6. Smart contracts must have `onlyOwner` modifiers on all execution functions
7. Emergency sweep function must exist to recover stuck tokens

---

## 12. COMMUNICATION / MONITORING

| System | Detail |
|--------|--------|
| Status files | JSON status at `/var/lib/skeletor/state/status.json` |
| Logs | `/var/log/skeletor/engine.log` |
| Relay page | `57gz69594c-ux.github.io/shaheer-relay/` (for human-readable updates) |
| Filebin | `https://filebin.net/shaheer-relay-dydhytrzlufq6zwo` (file exchange) |

---

## 13. WHAT WE DO NOT HAVE

| Item | Status | Impact |
|------|--------|--------|
| 1inch API key | Not available (KYC barrier) | Cannot use 1inch for routing — use direct DEX pool reads instead |
| Alchemy | **DO NOT USE** — Chainstack is our only RPC provider | Build everything on Chainstack endpoints |
| OpenAI API key | REVOKED (Sep 11) | Use Codex CLI only for GPT interactions |
| Allium | PENDING APPROVAL | No on-chain analytics API yet |
| Archive nodes | Chainstack may have partial archive — verify per chain | Backtest mode may be limited |

---

## 14. QUICK-START INSTRUCTIONS FOR THE BUILDER

1. **Read `SKELETOR_ARB_ENGINE_REQUIREMENTS.md` first** — it has the full architecture, DEX targets, phased plan, and all technical requirements.

2. **Start with the smart contract** (`SkeletorArbitrageur.sol`) — this is the on-chain component that executes the actual arb. Test it on Arbitrum Sepolia first.

3. **Build the price monitor next** — WebSocket subscriptions to DEX pool Swap events on Arbitrum (most active L2). Use Chainstack WSS endpoint.

4. **Build the arb detector** — Compare prices across 2+ DEXs for WETH/USDC on Arbitrum. This is the simplest case.

5. **Build the executor** — Combine flash loan + swap calls into one atomic TX. Test with dry_run mode first.

6. **Deploy to mainnet** — Start with Arbitrum only, conservative settings, $5 min profit. Scale from there.

7. **The environment config lives at `/etc/reaper/reaper.env`** on the VPS. All Chainstack RPC URLs and keeper wallet details are there. Skeletor should source its RPC URLs from there or from a shared config include.

8. **Run as systemd service** — Follow the same pattern as `reaper-engine.service`. Auto-restart on crash, log to journald + file.

---

*This document is a companion to `SKELETOR_ARB_ENGINE_REQUIREMENTS.md`. Together, they contain everything needed to build the Skeletor ARB Engine from scratch using our existing infrastructure.*
