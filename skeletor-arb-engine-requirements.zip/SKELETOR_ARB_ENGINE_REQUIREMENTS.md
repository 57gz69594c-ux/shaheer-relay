# SKELETOR ARB ENGINE — Complete Requirements Document

**Project:** Skeletor — Cross-DEX Flash Loan Arbitrage Engine
**Target:** $500/day net profit
**Author:** Claude (for Shaheer Khan)
**Date:** 2026-09-14
**Builder:** GPT Astra 6 (Codex CLI, xhigh reasoning)

---

## 1. CONCEPT OVERVIEW

Skeletor is a **cross-DEX flash loan arbitrage bot** that runs alongside the existing REAPER v5.4.5 liquidation engine on the same VPS. The core strategy:

1. **Flash loan** tokens from a lending protocol (Morpho, AAVE, or native DEX flash swaps) — zero capital required
2. **Buy** on DEX A where the token is cheaper
3. **Sell** on DEX B where the token is more expensive
4. **Repay** the flash loan + fee
5. **Keep** the spread as pure profit

All steps happen in a **single atomic transaction**. If the arb isn't profitable after gas, the entire tx reverts — **zero capital risk**. The only cost on failure is the gas for the reverted tx (negligible on L2s).

### Why This Works
- DEX prices diverge constantly due to: different liquidity depths, delayed arbitrage, MEV bot competition gaps, cross-pool imbalances
- Flash loans provide unlimited capital for a single block — we can arb with $1M+ without owning a cent
- L2 chains (Arbitrum, Base, Optimism, Scroll, Linea) have sub-cent gas, making even tiny spreads profitable
- We already have the infrastructure: 11 chains with paid RPCs, WebSocket feeds, funded keeper wallets

---

## 2. TARGET ECONOMICS — $500/DAY PATH

### Phase 1: Foundation (Week 1-2) — Target: $50/day
- Deploy on 2-3 high-volume L2s (Arbitrum, Base, Polygon)
- Target large-cap pairs only (WETH/USDC, WETH/USDT, WBTC/WETH)
- 2-DEX arbitrage (Uniswap V3 ↔ SushiSwap, Uniswap V3 ↔ Camelot, etc.)
- Conservative: 10-20 trades/day at $2.50-$5 avg profit each

### Phase 2: Expansion (Week 3-4) — Target: $150/day
- Add all 11 chains
- Add mid-cap pairs (LINK, ARB, OP, AVAX, MATIC native pairs)
- Multi-hop routes (A→B→C→A triangular arbitrage)
- Increase to 50-100 trades/day

### Phase 3: Optimization (Month 2) — Target: $300/day
- Mempool monitoring for frontrun-resistant execution
- Private transaction submission (Flashbots Protect on ETH, equivalent on L2s)
- Sub-100ms latency path optimization
- Dynamic gas bidding to win competitive arbs

### Phase 4: Scale (Month 2-3) — Target: $500/day
- Cross-chain arbitrage opportunities (same token, different chain prices)
- CEX-DEX price deviation monitoring (read-only CEX feeds as signals)
- JIT (Just-In-Time) liquidity provision alongside arb
- Flash swap integration (no flash loan fee — use DEX native flash swaps)

### Revenue Model
```
Per-trade profit = (sell_price - buy_price) * amount - flash_loan_fee - gas_cost

Flash loan fees:
  - Morpho: 0% (free flash loans!)
  - AAVE V3: 0.05% (very cheap)
  - Uniswap V3 flash swap: 0.3% of the swap (pool fee)
  - Balancer: 0% flash loans

Gas costs by chain:
  - Ethereum: $2-15 per tx (only for large arbs >$50 profit)
  - Arbitrum: $0.01-0.10
  - Base: $0.001-0.01
  - Optimism: $0.01-0.05
  - Polygon: $0.01-0.05
  - BNB: $0.05-0.20
  - Avalanche: $0.05-0.30
  - Gnosis: $0.001-0.01
  - Scroll: $0.01-0.05
  - Linea: $0.01-0.05
  - Mantle: $0.001-0.01
```

### Realistic Daily P&L Estimate (Phase 4)
```
Arbitrum:  40 trades × $3.00 avg = $120/day
Base:      30 trades × $2.50 avg = $75/day
Polygon:   25 trades × $2.00 avg = $50/day
Ethereum:   5 trades × $25.00 avg = $125/day (large arbs only)
Optimism:  15 trades × $2.00 avg = $30/day
BNB:       20 trades × $2.50 avg = $50/day
Avalanche: 15 trades × $2.00 avg = $30/day
Others:    10 trades × $2.00 avg = $20/day
                                    --------
TOTAL:                              $500/day
```

---

## 3. ARCHITECTURE REQUIREMENTS

### 3.1 High-Level Architecture

```
┌─────────────────────────────────────────────────────┐
│                  SKELETOR ENGINE                     │
│                                                      │
│  ┌──────────┐  ┌──────────┐  ┌──────────────────┐  │
│  │ Price     │  │ Arb      │  │ Execution        │  │
│  │ Monitor   │→ │ Detector │→ │ Engine           │  │
│  │ (WSS)     │  │          │  │ (Flash Loan TX)  │  │
│  └──────────┘  └──────────┘  └──────────────────┘  │
│       ↑                              ↓               │
│  ┌──────────┐              ┌──────────────────┐     │
│  │ DEX Pool │              │ Smart Contract   │     │
│  │ State    │              │ (Arbitrageur.sol)│     │
│  │ Cache    │              └──────────────────┘     │
│  └──────────┘                                        │
│       ↑                                              │
│  ┌──────────┐  ┌──────────┐  ┌──────────────────┐  │
│  │ On-chain │  │ Metrics  │  │ Gas Optimizer    │  │
│  │ Listener │  │ & P&L    │  │ & MEV Protect    │  │
│  └──────────┘  └──────────┘  └──────────────────┘  │
└─────────────────────────────────────────────────────┘
```

### 3.2 Core Components

#### A. Price Monitor (Real-Time)
- **WebSocket subscriptions** to all DEX pool contracts on all chains
- Monitor `Swap` events on Uniswap V2/V3, SushiSwap, PancakeSwap, etc.
- Maintain in-memory price book for every tracked pair on every DEX
- Sub-second price updates via Chainstack WSS endpoints (already available)
- Calculate effective prices including:
  - Pool fees (0.01%, 0.05%, 0.3%, 1% tiers on Uni V3)
  - Price impact for given trade size
  - Slippage tolerance

#### B. Arbitrage Detector
- Compare prices across all DEXs for each pair on each chain
- Calculate optimal trade size (maximize profit considering price impact)
- Filter: only execute if `expected_profit > gas_cost * safety_margin`
- Safety margin: 1.5x (only execute if profit is 50% more than gas cost)
- Support three arb types:
  1. **Direct**: Buy on DEX A, sell on DEX B (same pair)
  2. **Triangular**: A→B on DEX1, B→C on DEX2, C→A on DEX3
  3. **Multi-hop**: Longer cycles through 4+ pools if profitable

#### C. Execution Engine
- Build and submit flash loan transactions atomically
- Transaction building:
  1. Encode flash loan borrow call
  2. Encode swap calls (buy on cheap DEX)
  3. Encode swap calls (sell on expensive DEX)
  4. Encode flash loan repay
  5. Verify profit > 0 in the callback
- Gas estimation: simulate the full tx, get exact gas, add 10% buffer
- Nonce management: pre-fetch, track pending, handle stuck txs
- Concurrent execution: can fire multiple arbs on different chains simultaneously

#### D. Smart Contract (Arbitrageur.sol)
- Solidity contract deployed on each active chain
- Receives flash loan callback
- Executes the swap sequence
- Verifies profit before returning funds
- Sweeps profit to treasury wallet
- Must be gas-optimized (assembly where beneficial)
- Supports multiple flash loan providers (Morpho, AAVE, Balancer, Uniswap flash swaps)
- Supports multiple DEX routers
- Owner-only execution (prevent others from using our contract)

#### E. DEX Pool State Cache
- On startup: fetch all pool reserves/tick data for tracked pairs
- Maintain live state via WebSocket event subscriptions
- For Uniswap V3: track current tick, liquidity at each tick range
- For Uniswap V2 / SushiSwap: track reserve0, reserve1
- For Curve: track balances array
- This cache enables instant price calculation without RPC calls

#### F. Gas Optimizer & MEV Protection
- **Ethereum mainnet**: Use Flashbots Protect RPC to avoid sandwich attacks
  - Endpoint: `https://rpc.flashbots.net`
  - Sends tx directly to block builders, bypassing public mempool
- **Arbitrum**: Use Arbitrum Sequencer Feed for faster inclusion
- **Other L2s**: Standard submission is fine (no significant MEV on most L2s yet)
- Dynamic gas pricing: fetch current base fee + priority fee, set competitive but not wasteful
- EIP-1559 transaction type on all chains that support it

#### G. Metrics & P&L Tracking
- SQLite database (like REAPER's metrics.sqlite3)
- Track per-trade: chain, pair, buy_dex, sell_dex, amount, profit_usd, gas_cost, tx_hash, timestamp
- Track per-day: total_trades, total_profit, total_gas, net_profit, win_rate
- Track per-chain: volume, profit, most profitable pairs
- Real-time P&L dashboard via CLI or status file (JSON)

### 3.3 Language & Framework
- **Python 3.12** (already installed on the VPS)
- **web3.py** for all blockchain interactions
- **websockets** library for WSS connections
- **asyncio** for concurrent multi-chain monitoring
- **eth-abi** for encoding/decoding contract calls
- **Solidity** for the on-chain arbitrage contract (compile with `solc` or use `py-solc-x`)

### 3.4 Directory Structure (Recommended)
```
/opt/skeletor/
├── engine/
│   ├── __init__.py
│   ├── main.py              # Entry point, async event loop
│   ├── config.py            # Chain configs, DEX configs, env loading
│   ├── price_monitor.py     # WSS pool event subscriptions
│   ├── arb_detector.py      # Cross-DEX price comparison & opportunity detection
│   ├── executor.py          # Flash loan TX builder & submitter
│   ├── pool_cache.py        # In-memory DEX pool state
│   ├── gas_optimizer.py     # Gas pricing, Flashbots integration
│   ├── metrics.py           # SQLite metrics tracking
│   ├── flash_loan.py        # Flash loan provider abstraction
│   └── utils.py             # Helpers, logging, error handling
├── contracts/
│   ├── SkeletorArbitrageur.sol   # Main arb contract
│   ├── interfaces/               # DEX router interfaces, flash loan interfaces
│   └── deploy.py                 # Deployment script
├── config/
│   ├── skeletor.env          # Environment config (RPCs, addresses)
│   ├── dex_registry.json     # DEX router addresses per chain
│   ├── pairs.json            # Token pairs to monitor
│   └── pools.json            # Known pool addresses per DEX per chain
├── tests/
│   ├── test_arb_detector.py
│   ├── test_executor.py
│   ├── test_pool_cache.py
│   └── test_flash_loan.py
├── scripts/
│   ├── deploy_all_chains.py  # Deploy contract to all chains
│   ├── status.py             # Print current engine status
│   └── backtest.py           # Historical arb opportunity analysis
└── skeletor.service          # systemd unit file
```

---

## 4. DEX TARGETS BY CHAIN

### Ethereum (Chain ID: 1)
| DEX | Type | Router Address | Flash Loan Source |
|-----|------|---------------|-------------------|
| Uniswap V3 | Concentrated | `0xE592427A0AEce92De3Edee1F18E0157C05861564` | Uniswap V3 flash swap |
| Uniswap V2 | Constant Product | `0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D` | — |
| SushiSwap | Constant Product | `0xd9e1cE17f2641f24aE83637ab66a2cca9C378B9F` | — |
| Curve | StableSwap | Various pools | — |
| Balancer V2 | Weighted | `0xBA12222222228d8Ba445958a75a0704d566BF2C8` | Balancer flash loans (0%) |
| 1inch (read-only) | Aggregator | — | Price reference only |
| **Flash Loans:** | Morpho (0%), AAVE V3 (0.05%), Balancer (0%) | | |

### Arbitrum (Chain ID: 42161)
| DEX | Type | Router |
|-----|------|--------|
| Uniswap V3 | Concentrated | `0xE592427A0AEce92De3Edee1F18E0157C05861564` |
| SushiSwap | Constant Product | `0x1b02dA8Cb0d097eB8D57A175b88c7D8b47997506` |
| Camelot V2 | Custom AMM | `0xc873fEcbd354f5A56E00E710B90EF4201db2448d` |
| GMX Swap | Oracle-priced | — |
| Trader Joe V2.1 | Liquidity Book | `0xb4315e873dBcf96Ffd0acd8EA43f689D8c20fB30` |
| **Flash Loans:** | AAVE V3, Uniswap V3 flash swap | |

### Base (Chain ID: 8453)
| DEX | Type | Router |
|-----|------|--------|
| Uniswap V3 | Concentrated | `0x2626664c2603336E57B271c5C0b26F421741e481` |
| Aerodrome | ve(3,3) | `0xcF77a3Ba9A5CA399B7c97c74d54e5b1Beb874E43` |
| SushiSwap V3 | Concentrated | Verify on-chain |
| BaseSwap | Constant Product | `0x327Df1E6de05895d2ab08513aaDD9313Fe505d86` |
| **Flash Loans:** | AAVE V3, Morpho, Uniswap V3 flash swap | |

### Polygon (Chain ID: 137)
| DEX | Type | Router |
|-----|------|--------|
| Uniswap V3 | Concentrated | `0xE592427A0AEce92De3Edee1F18E0157C05861564` |
| QuickSwap V3 | Concentrated | `0xf5b509bB0909a69B1c207E495f687a596C168E12` |
| SushiSwap | Constant Product | `0x1b02dA8Cb0d097eB8D57A175b88c7D8b47997506` |
| Balancer V2 | Weighted | `0xBA12222222228d8Ba445958a75a0704d566BF2C8` |
| **Flash Loans:** | AAVE V3, Balancer (0%), Uniswap V3 flash swap | |

### BNB Chain (Chain ID: 56)
| DEX | Type | Router |
|-----|------|--------|
| PancakeSwap V3 | Concentrated | `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` |
| PancakeSwap V2 | Constant Product | `0x10ED43C718714eb63d5aA57B78B54704E256024E` |
| Uniswap V3 | Concentrated | `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` |
| BiSwap | Constant Product | `0x3a6d8cA21D1CF76F653A67577FA0D27453350dD8` |
| **Flash Loans:** | PancakeSwap V3 flash swap, AAVE V3 | |

### Optimism (Chain ID: 10)
| DEX | Type | Router |
|-----|------|--------|
| Uniswap V3 | Concentrated | `0xE592427A0AEce92De3Edee1F18E0157C05861564` |
| Velodrome V2 | ve(3,3) | `0xa062aE8A9c5e11aaA026fc2670B0D65cCc8B2858` |
| **Flash Loans:** | AAVE V3, Uniswap V3 flash swap | |

### Avalanche (Chain ID: 43114)
| DEX | Type | Router |
|-----|------|--------|
| Trader Joe V2.1 | Liquidity Book | `0xb4315e873dBcf96Ffd0acd8EA43f689D8c20fB30` |
| Pangolin | Constant Product | `0xE54Ca86531e17Ef3616d22Ca28b0D458b6C89106` |
| Uniswap V3 | Concentrated | Verify deployment |
| **Flash Loans:** | AAVE V3, Benqi (if flash loan supported) | |

### Gnosis (Chain ID: 100)
| DEX | Type | Router |
|-----|------|--------|
| SushiSwap | Constant Product | Verify deployment |
| Honeyswap | Constant Product | `0x1C232F01118CB8B424793ae03F870aa7D0ac7f77` |
| **Flash Loans:** | AAVE V3 | |

### Scroll (Chain ID: 534352)
| DEX | Type | Router |
|-----|------|--------|
| SyncSwap | zkSync-style | Verify deployment |
| SpaceFi | Constant Product | Verify deployment |
| Uniswap V3 | Concentrated | Verify deployment |
| **Flash Loans:** | Morpho (if available), native flash swaps | |

### Linea (Chain ID: 59144)
| DEX | Type | Router |
|-----|------|--------|
| SyncSwap | zkSync-style | Verify deployment |
| Uniswap V3 | Concentrated | Verify deployment |
| **Flash Loans:** | Morpho, native flash swaps | |

### Mantle (Chain ID: 5000)
| DEX | Type | Router |
|-----|------|--------|
| Agni Finance | Concentrated | Verify deployment |
| FusionX | Concentrated | Verify deployment |
| **Flash Loans:** | Native flash swaps | |

> **IMPORTANT:** All router addresses marked "Verify deployment" or "Verify on-chain" must be confirmed before coding. DEX deployments change. Always verify against the DEX's official docs or on-chain factory contracts.

---

## 5. TOKEN PAIRS TO MONITOR (Priority Order)

### Tier 1 — Highest Volume (Monitor on ALL chains where available)
- WETH/USDC
- WETH/USDT
- WBTC/WETH
- WBTC/USDC

### Tier 2 — High Volume
- LINK/WETH
- ARB/WETH (Arbitrum)
- OP/WETH (Optimism)
- MATIC/WETH (Polygon)
- AVAX/WAVAX (Avalanche)
- BNB/BUSD (BNB Chain)
- wstETH/WETH (all chains)
- rETH/WETH (Ethereum, Arbitrum)
- cbETH/WETH (Base)

### Tier 3 — Mid Volume (Phase 2+)
- UNI/WETH
- AAVE/WETH
- CRV/WETH
- MKR/WETH
- LDO/WETH
- GMX/WETH (Arbitrum)
- PENDLE/WETH
- SNX/WETH

### Tier 4 — Stablecoin Arbs (Low profit per trade, high frequency)
- USDC/USDT (depeg arbs)
- DAI/USDC
- FRAX/USDC
- LUSD/USDC

---

## 6. FLASH LOAN STRATEGY

### Priority Order (by cost):
1. **Morpho** — 0% fee, available on ETH, Base, maybe others. **WE ALREADY USE THIS IN REAPER.**
2. **Balancer V2** — 0% fee, available on ETH, Polygon, Arbitrum, Gnosis, Avalanche, Base, Optimism
3. **AAVE V3** — 0.05% fee, available on ALL our chains except Mantle. **WE ALREADY USE THIS IN REAPER.**
4. **Uniswap V3 Flash Swap** — 0.3% pool fee (expensive but available everywhere Uni V3 exists)
5. **DEX-native flash swaps** — Varies, use as last resort

### Flash Loan Implementation
```
// Pseudocode for the smart contract callback

function onFlashLoan(address token, uint256 amount, uint256 fee, bytes data) {
    // 1. Decode the arb instructions from `data`
    (address buyDex, address sellDex, bytes buyCalldata, bytes sellCalldata) = abi.decode(data);
    
    // 2. Execute buy on cheap DEX
    IERC20(token).approve(buyDex, amount);
    buyDex.call(buyCalldata);  // swap token → targetToken
    
    // 3. Execute sell on expensive DEX
    uint256 targetBalance = IERC20(targetToken).balanceOf(address(this));
    IERC20(targetToken).approve(sellDex, targetBalance);
    sellDex.call(sellCalldata);  // swap targetToken → token
    
    // 4. Verify profit
    uint256 finalBalance = IERC20(token).balanceOf(address(this));
    require(finalBalance >= amount + fee, "No profit");
    
    // 5. Repay flash loan
    IERC20(token).transfer(msg.sender, amount + fee);
    
    // 6. Sweep profit to treasury
    uint256 profit = IERC20(token).balanceOf(address(this));
    IERC20(token).transfer(treasury, profit);
}
```

---

## 7. SMART CONTRACT REQUIREMENTS

### SkeletorArbitrageur.sol
```solidity
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// Key features needed:
// 1. Support multiple flash loan providers (Morpho, AAVE, Balancer, Uniswap)
// 2. Support multiple DEX routers for swaps
// 3. Owner-only execution (onlyOwner modifier)
// 4. Configurable treasury address for profit sweeping
// 5. Emergency withdrawal function
// 6. Multicall support (batch multiple swaps in one callback)
// 7. Permit-based approvals where possible (gas savings)
// 8. Re-entrancy protection
// 9. Minimal storage (gas optimization)
// 10. Event emission for off-chain tracking

interface ISkeletorArbitrageur {
    // Execute a flash loan arb
    function executeArb(
        address flashLoanProvider,  // Morpho, AAVE, Balancer vault
        address token,              // Token to flash loan
        uint256 amount,             // Flash loan amount
        bytes calldata swapData     // Encoded swap instructions
    ) external;
    
    // Execute using Uniswap V3 flash swap (different interface)
    function executeFlashSwap(
        address pool,               // Uniswap V3 pool
        bool zeroForOne,
        int256 amountSpecified,
        bytes calldata swapData
    ) external;
    
    // Triangular arb with multiple swaps
    function executeMultiSwap(
        address flashLoanProvider,
        address token,
        uint256 amount,
        SwapStep[] calldata steps   // Array of swap instructions
    ) external;
    
    // Emergency functions
    function sweepToken(address token, address to) external;
    function sweepETH(address to) external;
    
    // Config
    function setTreasury(address treasury) external;
    function setApprovedRouter(address router, bool approved) external;
}

struct SwapStep {
    address router;     // DEX router to use
    bytes calldata_;    // Encoded swap call
}
```

### Deployment Strategy
- Deploy one `SkeletorArbitrageur` contract per chain
- Owner = the keeper wallet for that chain (reuse REAPER keepers)
- Treasury = same treasury wallet as REAPER (or a new one, configurable)
- Pre-approve all DEX routers in the contract's approved router list
- Pre-approve token spending for common tokens (gas savings on first trade)

---

## 8. EXECUTION FLOW (Per Opportunity)

```
1. Price Monitor detects price divergence:
   - WETH/USDC on Uniswap V3 (Arbitrum): 1 WETH = 2,510 USDC
   - WETH/USDC on Camelot (Arbitrum):     1 WETH = 2,515 USDC
   - Spread: $5 per WETH

2. Arb Detector calculates:
   - Optimal size: 20 WETH (limited by liquidity depth on Camelot)
   - Expected gross profit: 20 × $5 = $100
   - Flash loan fee (Morpho, 0%): $0
   - Gas cost estimate: $0.08 (Arbitrum)
   - Net profit estimate: $99.92
   - Safety check: $99.92 > $0.08 × 1.5 = $0.12 ✓ EXECUTE

3. Executor builds transaction:
   a. Call Morpho flash loan: borrow 20 WETH
   b. In callback:
      - Swap 20 WETH → ~50,200 USDC on Uniswap V3
      - Swap ~50,200 USDC → ~20.04 WETH on Camelot
   c. Repay 20 WETH to Morpho
   d. Profit: ~0.04 WETH (~$100) sent to treasury

4. Executor submits tx:
   - Sign with keeper wallet private key
   - Submit via Chainstack RPC
   - Monitor for inclusion
   - Log result to metrics DB

5. If tx reverts:
   - Only gas cost lost (~$0.08)
   - Log the failure reason
   - Blacklist this specific opportunity for 60 seconds (prices may have moved)
```

---

## 9. RISK MANAGEMENT

### Transaction-Level
- **Atomic execution**: Flash loan ensures all-or-nothing. If arb fails → tx reverts, no funds lost
- **Profit verification**: Smart contract requires `profit > 0` before completing
- **Gas cap**: Never spend more than `max_gas_per_tx` (configurable per chain)
- **Daily gas budget**: Total gas spending capped at a daily limit per chain

### Operational
- **Stale price protection**: If last price update > 3 seconds old, skip the opportunity
- **Minimum profit threshold**: Skip arbs below $1 profit (not worth the risk/gas)
- **Max trade size**: Cap per-trade size to limit price impact and smart contract risk
- **Rate limiting**: Max N transactions per minute per chain (prevent gas wars with self)
- **Circuit breaker**: If 5 consecutive trades fail on a chain → pause that chain for 10 minutes

### Security
- **Owner-only contract calls**: Only our keeper wallet can trigger the arb contract
- **Approved router whitelist**: Contract only interacts with pre-approved DEX routers
- **No token approvals to unknown contracts**
- **Emergency sweep function**: Owner can withdraw any stuck tokens
- **Re-entrancy guards**: All callback functions protected

---

## 10. MONITORING & ALERTS

### Status File (JSON)
```json
{
  "status": "RUNNING",
  "uptime_hours": 24.5,
  "today": {
    "trades": 87,
    "gross_profit_usd": 312.45,
    "gas_cost_usd": 4.12,
    "net_profit_usd": 308.33,
    "win_rate": 0.94
  },
  "chains": {
    "arbitrum": {"trades": 32, "profit_usd": 96.20},
    "base": {"trades": 25, "profit_usd": 62.50},
    "polygon": {"trades": 15, "profit_usd": 30.00}
  },
  "last_trade": {
    "chain": "arbitrum",
    "pair": "WETH/USDC",
    "profit_usd": 3.42,
    "timestamp": "2026-09-14T12:34:56Z"
  }
}
```

### systemd Service
- Run as `skeletor-engine.service` alongside `reaper-engine.service`
- Auto-restart on crash (RestartSec=5)
- Logs to `/var/log/skeletor/engine.log`
- State dir: `/var/lib/skeletor/state/`

---

## 11. INTEGRATION WITH EXISTING REAPER INFRASTRUCTURE

### What Skeletor REUSES from REAPER:
1. **Chainstack RPC endpoints** (HTTP + WSS) — all 11 chains already configured
2. **Keeper wallet addresses** — can reuse same wallets for gas (or create new ones)
3. **Flash loan access** — Morpho and AAVE already integrated in REAPER
4. **Velora swap routing API** — can use for price discovery (though Skeletor mainly reads DEX pools directly)
5. **Server infrastructure** — same VPS, plenty of capacity (32 cores, 62GB RAM)
6. **Python 3.12 environment**
7. **systemd service patterns** — copy REAPER's service/timer setup

### What Skeletor DOES NOT share with REAPER:
1. **Separate process** — Skeletor runs as its own systemd service
2. **Separate smart contracts** — different on-chain contracts (arb vs liquidation)
3. **Separate state directory** — `/var/lib/skeletor/` not `/var/lib/reaper/`
4. **Separate metrics DB** — own SQLite file
5. **Separate nonce management** — if sharing keeper wallets, MUST coordinate nonces (or use separate wallets)

### Nonce Coordination (CRITICAL if sharing wallets)
If Skeletor and REAPER share the same keeper wallets, they MUST NOT submit transactions simultaneously from the same wallet on the same chain. Options:
- **Option A (Recommended)**: Generate NEW wallets for Skeletor — fund with small gas amounts
- **Option B**: Use a nonce manager lockfile/socket shared between both engines
- **Option C**: Assign some chains to Skeletor-only wallets, others share

---

## 12. CONFIGURATION REQUIREMENTS

### Environment Variables (skeletor.env)
```bash
# Execution mode
SKELETOR_MODE=live                    # live | dry_run | monitor_only

# Chain selection
SKELETOR_CHAINS=arbitrum,base,polygon,ethereum,optimism,bnb,avalanche

# RPC endpoints (reuse from REAPER or separate)
SKELETOR_ETHEREUM_RPC=<chainstack_http_url>
SKELETOR_ETHEREUM_WS=<chainstack_wss_url>
# ... repeat for each chain

# Keeper wallets (one per chain)
SKELETOR_KEEPER_ADDRESS_42161=<address>
SKELETOR_KEEPER_PRIVATE_KEY_42161=<key>
# ... repeat for each chain

# Profit settings
SKELETOR_MIN_PROFIT_USD=1.00         # Skip arbs below this
SKELETOR_SAFETY_MARGIN=1.5           # Profit must be 1.5x gas cost
SKELETOR_MAX_TRADE_SIZE_USD=100000   # Max single trade value

# Gas settings per chain
SKELETOR_MAX_GAS_PER_TX_1=5000000000000000      # 0.005 ETH
SKELETOR_MAX_DAILY_GAS_1=20000000000000000       # 0.02 ETH
SKELETOR_MAX_GAS_PER_TX_42161=500000000000000    # 0.0005 ETH
SKELETOR_MAX_DAILY_GAS_42161=5000000000000000    # 0.005 ETH
# ... repeat per chain

# Flash loan providers
SKELETOR_FLASH_PROVIDERS=morpho,balancer,aave    # Priority order

# MEV protection
SKELETOR_USE_FLASHBOTS=true          # Ethereum only
SKELETOR_FLASHBOTS_RPC=https://rpc.flashbots.net

# Metrics
SKELETOR_METRICS_DB=/var/lib/skeletor/state/metrics.sqlite3
SKELETOR_STATUS_FILE=/var/lib/skeletor/state/status.json

# Treasury
SKELETOR_TREASURY_ADDRESS=<treasury_wallet>
```

### DEX Registry (dex_registry.json)
```json
{
  "42161": {
    "uniswap_v3": {
      "router": "0xE592427A0AEce92De3Edee1F18E0157C05861564",
      "factory": "0x1F98431c8aD98523631AE4a59f267346ea31F984",
      "quoter": "0xb27308f9F90D607463bb33eA1BeBb41C27CE5AB6",
      "type": "concentrated"
    },
    "sushiswap": {
      "router": "0x1b02dA8Cb0d097eB8D57A175b88c7D8b47997506",
      "factory": "0xc35DADB65012eC5796536bD9864eD8773aBc74C4",
      "type": "constant_product"
    },
    "camelot_v2": {
      "router": "0xc873fEcbd354f5A56E00E710B90EF4201db2448d",
      "factory": "0x6EcCab422D763aC031210895C81787E87B43A652",
      "type": "custom"
    }
  }
}
```

---

## 13. PERFORMANCE REQUIREMENTS

- **Latency**: Price detection → TX submission < 500ms (target < 200ms)
- **Throughput**: Handle 1000+ price updates/second across all chains
- **Memory**: < 2GB RAM (the VPS has 62GB, REAPER uses ~4GB)
- **CPU**: < 4 cores sustained (32 available, REAPER uses ~2-4)
- **Uptime**: 99.9% — systemd auto-restart on any crash
- **Startup**: Full pool state sync < 60 seconds

---

## 14. TESTING REQUIREMENTS

### Unit Tests
- Arb detection algorithm correctness
- Price impact calculation accuracy
- Flash loan callback encoding/decoding
- Gas estimation accuracy

### Integration Tests
- End-to-end arb execution on testnet (Arbitrum Sepolia, Base Sepolia)
- Flash loan borrow + swap + repay cycle
- Multi-hop route execution
- Error handling: insufficient liquidity, front-run, price moved

### Dry Run Mode
- Full pipeline runs but submits transactions with `eth_call` instead of `eth_sendRawTransaction`
- Logs what would have been executed
- Essential for initial tuning before going live

### Backtest Mode
- Replay historical pool events from an archive node
- Calculate what arbs would have been possible in the last 24h
- Estimate theoretical daily profit
- Use this to validate the detection algorithm before going live

---

## 15. COMPETITIVE EDGE CONSIDERATIONS

### Why We Can Compete
1. **Low gas chains**: Most MEV competition is on Ethereum mainnet. L2s have far less competition.
2. **Paid Chainstack RPCs**: Faster than public RPCs — we see events ~100ms sooner.
3. **WebSocket feeds**: Real-time event streaming, not polling. Critical for speed.
4. **Multiple chains**: Diversified across 11 chains — more opportunities, less competition per chain.
5. **Flash loan expertise**: We already run a flash-loan-based liquidation engine.
6. **Zero capital risk**: Flash loans mean we never risk our own money.

### Known Challenges
1. **MEV bots on Ethereum mainnet**: Very competitive. Focus on L2s first.
2. **Sandwich attacks**: Use Flashbots Protect on Ethereum. Less of an issue on L2s.
3. **Price feed latency**: Whoever sees the opportunity first wins. Our paid WSS helps.
4. **Gas price spikes**: Can eat into profits during high-activity periods.
5. **Smart contract risk**: The arb contract must be thoroughly tested. A bug = stuck funds.

---

## 16. DEPLOYMENT CHECKLIST

1. [ ] Write and test `SkeletorArbitrageur.sol` contract
2. [ ] Deploy contract to testnet (Arbitrum Sepolia)
3. [ ] Run integration tests on testnet
4. [ ] Deploy contract to mainnet (start with Arbitrum, Base, Polygon)
5. [ ] Fund keeper wallets with small gas amounts ($5-10 per L2 chain)
6. [ ] Configure `skeletor.env` with all chain details
7. [ ] Build DEX pool registry (factory scan for all tracked pairs)
8. [ ] Run in `dry_run` mode for 24h — verify opportunity detection
9. [ ] Run in `monitor_only` mode for 24h — verify trade sizing
10. [ ] Switch to `live` mode with conservative settings (min profit $5)
11. [ ] Monitor for 48h, tune parameters
12. [ ] Lower min profit threshold, add more pairs, expand to more chains
13. [ ] Set up systemd service with auto-restart
14. [ ] Profit

---

## 17. OPEN QUESTIONS FOR BUILDER (GPT Astra 6)

1. Should Skeletor generate new keeper wallets or reuse REAPER's existing wallets?
   - **Recommendation**: Generate new wallets to avoid nonce conflicts
2. Which flash loan provider to prioritize? 
   - **Recommendation**: Morpho (0% fee) → Balancer (0%) → AAVE (0.05%)
3. Should the arb contract support upgradability (proxy pattern)?
   - **Recommendation**: No — keep it simple, deploy new version if needed
4. Multi-block MEV (cross-block arbitrage)?
   - **Recommendation**: Not for v1 — single-block atomic arbs only
5. Should we use a relayer service (e.g., OpenMEV, MEV Blocker)?
   - **Recommendation**: Flashbots Protect for ETH mainnet, direct submission for L2s

---

*This document contains everything needed to build the Skeletor ARB Engine from scratch. All existing infrastructure details are in the companion document `EXISTING_INFRASTRUCTURE.md`.*
