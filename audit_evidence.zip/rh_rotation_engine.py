"""
RH Chain Rotation Engine v4 — MOMENTUM-VERIFIED, NO PROFIT CAP.

RULES:
  1. Only enter coins ACTIVELY pumping (5m > +10%)
  2. PRE-ENTRY: 3 momentum readings over 10s — must be stable/rising
  3. NO profit ceiling — ride the wave, let it 20x if it wants
  4. Dynamic trailing stop: tight when momentum cools, wide when pumping
  5. Exit when sellers meet buyers (B/S ratio drops)
  6. Exit when 5m momentum STARTS to die (not at death point)
  7. Hard SL: -5% safety net (tightened from -8%)
  8. 2-second polling — never miss a move
  9. Blacklist tokens with consistently bad fills
"""
import json
import logging
import os
import time
import sys
import threading
import urllib.request
from web3 import Web3
from eth_account import Account

_log_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'logs')
os.makedirs(_log_dir, exist_ok=True)
_log_file = os.path.join(_log_dir, 'engine.log')
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(message)s',
    handlers=[
        logging.StreamHandler(),                          # stdout (for nohup / Claude session)
        logging.FileHandler(_log_file, mode='a'),         # always append to logs/engine.log
    ]
)
logger = logging.getLogger('rot')

# ── Chain ──
RPC = 'https://rpc.mainnet.chain.robinhood.com'
CID = 4663
AGG = '0x65050a9b7e5075a2ba5ced7b1b64ee66262c40dc'
HOOK = '0xE5e702641Ea86F4ae6cC3cDaeD2B886f976Be044'
POSMGR = '0x8366a39CC670B4001A1121B8F6A443A643e40951'
Z = '0x0000000000000000000000000000000000000000'
V3_ROUTER = '0xcaf681a66d020601342297493863e78c959e5cb2'   # SwapRouter02 on RH Chain
QUOTER_V2 = '0x33e885ed0ec9bf04ecfb19341582aadcb4c8a9e7'   # QuoterV2 for V3 simulation
WETH_ADDR = '0x0Bd7D308f8E1639FAb988df18A8011f41EAcAD73'

# ── V4 Contracts (verified on-chain) ──
V4_POOL_MANAGER = '0x8366a39cc670b4001a1121b8f6a443a643e40951'  # PoolManager Singleton
V4_QUOTER       = '0x8dc178efb8111bb0973dd9d722ebeff267c98f94'  # V4 Quoter
V4_STATE_VIEW   = '0xf3334192d15450cdd385c8b70e03f9a6bd9e673b'  # StateView
V4_UNIVERSAL_ROUTER = '0x8876789976decbfcbbbe364623c63652db8c0904'  # Universal Router v2.1.1
PERMIT2         = '0x000000000022D473030F116dDEE9F6B43aC78BA3'  # Permit2

# ── Quote Token Registry (generic — any quote token with address, decimals, display name) ──
QUOTE_TOKENS = {
    # addr_lower: (symbol, decimals)
    '0x117cc2133c37b721f49de2a7a74833232b3b4c0c': ('SPY', 18),
    '0x5fc5360d0400a0fd4f2af552add042d716f1d168': ('USDG', 6),
    '0xccee82fe024c36fa15e1005ede3e9e4787e23d09': ('HIMS', 18),
    '0xd0601ce157db5bdc3162bbac2a2c8af5320d9eec': ('NVDA', 18),
}
# Feature flags — enable new quotes one at a time
QUOTE_ENABLED = {
    '0x117cc2133c37b721f49de2a7a74833232b3b4c0c': True,   # SPY — tested, live
    '0x5fc5360d0400a0fd4f2af552add042d716f1d168': True,   # USDG — ENABLED (canary, $47 buffer)
    '0xccee82fe024c36fa15e1005ede3e9e4787e23d09': False,  # HIMS — pending canary
    '0xd0601ce157db5bdc3162bbac2a2c8af5320d9eec': False,  # NVDA — pending canary
}
# Legacy alias (SPY-specific code still references this)
SPY_ADDR  = '0x117cc2133c37B721F49dE2A7a74833232B3B4C0C'
ACCEPTED_QUOTES = {  # Legacy — will be replaced by QUOTE_TOKENS + QUOTE_ENABLED
    '0x117cc2133c37b721f49de2a7a74833232b3b4c0c': ('SPY', 500),
}
ETH_USD = 2466

# ── v3 Strategy — MOMENTUM FIRST, NO CAP ──
HARD_SL = 3.0           # -3% from entry → sell & rotate (tightened from -5%: data shows >3% loss = never recovers on memes)
HARD_TP = 25.0          # +25% from entry → INSTANT SELL & lock profit (data: optimal TP across 61 trades)
TRAIL_TIGHT = 3.0       # 3% drop from peak when momentum cooling
TRAIL_WIDE = 7.0        # 7% drop from peak when momentum strong (let it run)
GAS_RESERVE = 0.003     # ETH kept for gas
POLL_SEC = 2            # 2-second price checks
CONFIRM = 2             # 2 consecutive ticks to confirm signal

# ── Entry filters — ONLY mid-pump coins ──
MIN_LIQ = 20000
MIN_5M_ENTRY = 19.0     # +19% min pump — Codex Ultra optimal from 38-trade analysis (Sep 8)
MAX_5M_ENTRY = 225.0    # REFUSE entry if pump already >+225% — Codex Ultra optimal (Sep 8)
MIN_1H_ENTRY = 0.0      # 1h must be positive (sustained)
MOMENTUM_STRONG = 10.0  # 5m > +10% = pump still ripping → wide trail
MOMENTUM_DEATH = 5.0    # 5m drops below +5% → momentum dead → EXIT (raised from 3%: exit faster on fading pumps)
MOMENTUM_HISTORY = 4    # Track last 4 readings to detect slowdown trend
WARMUP_TICKS = 8        # Skip exits for first 8 ticks (16s) — let position settle
MIN_BS_ENTRY = 1.02     # B/S > 1.02 = buyers must be winning — Codex Ultra optimal (Sep 8)

# Known Pons-compatible tokens (V4 hook=0xE5e702, ETH pair)
PONS_WHITELIST = {
    '0x9d0e8be0ef309c7aa92ef031997c3dde0540c4a1',  # MORALS
    '0x2862d471505f7d365ce6f53cf1176baaa8d666f6',  # ENTITY
    '0x64c2cc275e3a09cb8c63e8633e0473ef0a1612a4',  # ATLAS
    '0x5ec9cd905ff6695fc8b5943a5e1e83a23b610156',  # PONINU
    '0xe76a12bcd2f0e6d3db9f9012321642198e6cbd1b',  # RH4
    '0x17c35105dab9936f113af60f3bf74783caf08301',  # HD
    '0x000d9659a0c1ddedce0d73fe4be5c55a781e980e',  # GIVER
    '0x47366e0f257ac009e82bd46fb74e2fb50826ce98',  # AOBS
    '0x86202ef2ecf0fb70a3b74794cd5bdc5a91bb0f97',  # ONLY
}
COST_BASIS = 803.0

# Blacklisted tokens — consistently bad fills / slippage death traps
_HARDCODED_BLACKLIST = {
    '0x78b96280c3347e0f58a7147b73eb0ec5ffff025d',  # RSTR — -10% to -25% slippage every time
    '0x9e88da78e13755bea9a4988c987849794ec3f5e8',  # Pledge — repeated bad fills, -6.8% instant SL (Shaheer directive)
    '0xf6994adbe500c8466e60ce11e38fe69d1b1e7777',  # Pledge (alt addr) — blacklisted
    '0xf1d0c16a8924207783c0b2397b68bc7635908736',  # IPUNK — V4 honeypot, sells always revert
}
_BLACKLIST_FILE = '/tmp/rh_blacklist.json'
def _load_blacklist():
    bl = set(_HARDCODED_BLACKLIST)
    try:
        with open(_BLACKLIST_FILE) as f:
            bl.update(json.load(f))
    except Exception:
        pass
    return bl
def _save_blacklist():
    try:
        dynamic = [a for a in PONS_BLACKLIST if a not in _HARDCODED_BLACKLIST]
        with open(_BLACKLIST_FILE, 'w') as f:
            json.dump(dynamic, f)
    except Exception:
        pass
PONS_BLACKLIST = _load_blacklist()
HDR = {'User-Agent': 'rot/3.0'}

# ── ABI ──
E20 = json.loads('[{"inputs":[{"name":"a","type":"address"}],"name":"balanceOf","outputs":[{"name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"decimals","outputs":[{"name":"","type":"uint8"}],"stateMutability":"view","type":"function"},{"inputs":[{"name":"s","type":"address"},{"name":"v","type":"uint256"}],"name":"approve","outputs":[{"name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"name":"o","type":"address"},{"name":"s","type":"address"}],"name":"allowance","outputs":[{"name":"","type":"uint256"}],"stateMutability":"view","type":"function"}]')
SWAP = json.loads('[{"inputs":[{"name":"steps","type":"tuple[]","components":[{"name":"stepType","type":"uint8"},{"name":"tokenIn","type":"address"},{"name":"tokenOut","type":"address"},{"name":"pool","type":"address"},{"name":"fee","type":"uint24"},{"name":"tickSpacing","type":"int24"},{"name":"hook","type":"address"},{"name":"hookData","type":"bytes"},{"name":"recipient","type":"address"},{"name":"poolId","type":"bytes32"}]},{"name":"recipient","type":"address"},{"name":"amountIn","type":"uint256"},{"name":"amountOutMin","type":"uint256"},{"name":"deadline","type":"uint256"}],"name":"swap","outputs":[{"name":"","type":"uint256"}],"stateMutability":"payable","type":"function"}]')
# SwapRouter02 ABI — NO deadline in params (handled via multicall wrapper)
V3_SWAP_ABI = json.loads('[{"inputs":[{"components":[{"name":"tokenIn","type":"address"},{"name":"tokenOut","type":"address"},{"name":"fee","type":"uint24"},{"name":"recipient","type":"address"},{"name":"amountIn","type":"uint256"},{"name":"amountOutMinimum","type":"uint256"},{"name":"minHopPriceX36","type":"uint160"}],"name":"params","type":"tuple"}],"name":"exactInputSingle","outputs":[{"name":"amountOut","type":"uint256"}],"stateMutability":"payable","type":"function"},{"inputs":[{"name":"amountMinimum","type":"uint256"},{"name":"recipient","type":"address"}],"name":"unwrapWETH9","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"name":"deadline","type":"uint256"},{"name":"data","type":"bytes[]"}],"name":"multicall","outputs":[{"name":"results","type":"bytes[]"}],"stateMutability":"payable","type":"function"},{"inputs":[],"name":"refundETH","outputs":[],"stateMutability":"payable","type":"function"}]')
QUOTER_V2_ABI = json.loads('[{"inputs":[{"components":[{"name":"tokenIn","type":"address"},{"name":"tokenOut","type":"address"},{"name":"amountIn","type":"uint256"},{"name":"fee","type":"uint24"},{"name":"minHopPriceX36","type":"uint160"}],"name":"params","type":"tuple"}],"name":"quoteExactInputSingle","outputs":[{"name":"amountOut","type":"uint256"},{"name":"sqrtPriceX96After","type":"uint160"},{"name":"initializedTicksCrossed","type":"uint32"},{"name":"gasEstimate","type":"uint256"}],"stateMutability":"nonpayable","type":"function"}]')
WETH_ABI = json.loads('[{"inputs":[],"name":"deposit","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"name":"wad","type":"uint256"}],"name":"withdraw","outputs":[],"stateMutability":"nonpayable","type":"function"}]')

# ── V4 ABIs ──
# Universal Router: execute(bytes commands, bytes[] inputs, uint256 deadline)
V4_ROUTER_ABI = json.loads('[{"inputs":[{"name":"commands","type":"bytes"},{"name":"inputs","type":"bytes[]"},{"name":"deadline","type":"uint256"}],"name":"execute","outputs":[],"stateMutability":"payable","type":"function"}]')
# V4 Quoter: quoteExactInputSingle (uses PoolKey + params)
V4_QUOTER_ABI = json.loads('[{"inputs":[{"components":[{"components":[{"name":"currency0","type":"address"},{"name":"currency1","type":"address"},{"name":"fee","type":"uint24"},{"name":"tickSpacing","type":"int24"},{"name":"hooks","type":"address"}],"name":"poolKey","type":"tuple"},{"name":"zeroForOne","type":"bool"},{"name":"exactAmount","type":"uint128"},{"name":"hookData","type":"bytes"}],"name":"params","type":"tuple"}],"name":"quoteExactInputSingle","outputs":[{"name":"amountOut","type":"uint256"},{"name":"gasEstimate","type":"uint256"}],"stateMutability":"nonpayable","type":"function"}]')
# StateView: getSlot0 and getLiquidity (by poolId bytes32)
V4_STATE_VIEW_ABI = json.loads('[{"inputs":[{"name":"poolId","type":"bytes32"}],"name":"getSlot0","outputs":[{"name":"sqrtPriceX96","type":"uint160"},{"name":"tick","type":"int24"},{"name":"protocolFee","type":"uint24"},{"name":"lpFee","type":"uint24"}],"stateMutability":"view","type":"function"},{"inputs":[{"name":"poolId","type":"bytes32"}],"name":"getLiquidity","outputs":[{"name":"liquidity","type":"uint128"}],"stateMutability":"view","type":"function"}]')
# Permit2: approve + allowance
PERMIT2_ABI = json.loads('[{"inputs":[{"name":"owner","type":"address"},{"name":"token","type":"address"},{"name":"spender","type":"address"}],"name":"allowance","outputs":[{"name":"amount","type":"uint160"},{"name":"expiration","type":"uint48"},{"name":"nonce","type":"uint48"}],"stateMutability":"view","type":"function"},{"inputs":[{"name":"token","type":"address"},{"name":"spender","type":"address"},{"name":"amount","type":"uint160"},{"name":"expiration","type":"uint48"}],"name":"approve","outputs":[],"stateMutability":"nonpayable","type":"function"}]')

# V4 fee tiers to probe (common on Uniswap V4)
V4_FEES_TICKS = [(500, 10), (3000, 60), (10000, 200), (100, 1)]  # (fee, tickSpacing) pairs

# Track which route each token uses: 'pons' or 'v3' or 'v4'
TOKEN_ROUTE = {}  # addr_lower -> 'pons' | 'v3'
V3_FEES = [10000, 3000, 500, 100]  # Fee tiers to try

# ── Scan speed caches ──
_v3_fail_cache = {}    # addr_lower -> timestamp of last failure (skip re-test for 5 min)
_pair_data_cache = {}  # addr_lower -> {'quote_sym': ..., 'quote_addr': ..., 'ts': ..., 'pair_addr': ...}
_v4_pool_cache = {}    # dexscreener_token_addr_lower -> {'pool_id': bytes32, 'pool_key': tuple, 'c0': addr, 'c1': addr, 'quote_sym': str, 'quote_dec': int}
V3_FAIL_TTL = 300      # 5 min before re-testing a failed V3 token
SCAN_INTERVAL = 5      # Seconds between scans (was 15)

# V4 pool discovery constants (all RH Chain V4 pools use these)
V4_DEFAULT_FEE = 0
V4_DEFAULT_TICK_SPACING = 200
# Initialize event topic for V4 PoolManager
V4_INIT_TOPIC = None  # Computed lazily after w3 is initialized
# Persistence file for V4 routes + pool cache (Finding 6: survive restarts)
V4_CACHE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.v4_routes_cache.json')

# ── Fast Price Monitor (sub-second) ──
FAST_POLL_SEC = 0.4          # eth_getLogs poll interval — ~400ms
FAST_SL_THRESHOLD = -3.0     # Fast stop-loss: -3% from entry triggers instant sell (matches HARD_SL)
FAST_PEAK_DROP = 6.0         # Fast trailing: 6% drop from peak triggers instant sell
MONITOR_BLOCK_RANGE = 20     # How many blocks to scan per poll (~1.5s of blocks)
V3_SWAP_TOPIC = Web3.keccak(text='Swap(address,address,int256,int256,uint160,uint128,int24)').hex()
V3_FACTORY_RH = '0x1f7d7550B1b028f7571E69A784071f0205FD2EfA'  # Correct V3 Factory (24.5KB bytecode)
FACTORY_ABI = json.loads('[{"inputs":[{"name":"tokenA","type":"address"},{"name":"tokenB","type":"address"},{"name":"fee","type":"uint24"}],"name":"getPool","outputs":[{"name":"pool","type":"address"}],"stateMutability":"view","type":"function"}]')
POOL_SLOT0_ABI = json.loads('[{"inputs":[],"name":"slot0","outputs":[{"name":"sqrtPriceX96","type":"uint160"},{"name":"tick","type":"int24"},{"name":"observationIndex","type":"uint16"},{"name":"observationCardinality","type":"uint16"},{"name":"observationCardinalityNext","type":"uint16"},{"name":"feeProtocol","type":"uint8"},{"name":"unlocked","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"token0","outputs":[{"name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"token1","outputs":[{"name":"","type":"address"}],"stateMutability":"view","type":"function"}]')

# ── Wallet ──
with open('/root/shaheer-project/.rh_chain_key.json') as f: _k = json.load(f)
w3 = Web3(Web3.HTTPProvider(RPC, request_kwargs={'headers': {'User-Agent':'rot/3','Content-Type':'application/json'}, 'timeout': 15}))
acct = Account.from_key(_k['private_key'])
W = acct.address
sc = w3.eth.contract(address=Web3.to_checksum_address(AGG), abi=SWAP)
v3r = w3.eth.contract(address=Web3.to_checksum_address(V3_ROUTER), abi=V3_SWAP_ABI)
quoter_v2 = w3.eth.contract(address=Web3.to_checksum_address(QUOTER_V2), abi=QUOTER_V2_ABI)
weth_c = w3.eth.contract(address=Web3.to_checksum_address(WETH_ADDR), abi=WETH_ABI)
v4_router = w3.eth.contract(address=Web3.to_checksum_address(V4_UNIVERSAL_ROUTER), abi=V4_ROUTER_ABI)
v4_quoter = w3.eth.contract(address=Web3.to_checksum_address(V4_QUOTER), abi=V4_QUOTER_ABI)
v4_state = w3.eth.contract(address=Web3.to_checksum_address(V4_STATE_VIEW), abi=V4_STATE_VIEW_ABI)
permit2_c = w3.eth.contract(address=Web3.to_checksum_address(PERMIT2), abi=PERMIT2_ABI)


# ── V4 Cache Persistence (Finding 6: survive restarts) ──
def _save_v4_cache():
    """Persist V4 routes + pool cache to disk so positions survive restarts."""
    try:
        data = {}
        for al, pool_data in _v4_pool_cache.items():
            # Convert bytes to hex for JSON serialization
            data[al] = {
                'pool_id': '0x' + pool_data['pool_id'].hex(),
                'pool_key': list(pool_data['pool_key']),  # tuple → list
                'c0': pool_data['c0'],
                'c1': pool_data['c1'],
                'fee': pool_data['fee'],
                'tick_spacing': pool_data['tick_spacing'],
                'hooks': pool_data['hooks'],
                'quote_sym': pool_data['quote_sym'],
                'quote_dec': pool_data['quote_dec'],
                'quote_addr': pool_data['quote_addr'],
                'liq': pool_data['liq'],
            }
        # Also save TOKEN_ROUTE entries that are V4
        v4_routes = {k: v for k, v in TOKEN_ROUTE.items() if v.startswith('v4')}
        payload = {'v4_pool_cache': data, 'v4_routes': v4_routes, 'ts': time.time()}
        with open(V4_CACHE_FILE, 'w') as f:
            json.dump(payload, f, indent=2)
        logger.info('V4 cache saved: %d pools, %d routes', len(data), len(v4_routes))
    except Exception as ex:
        logger.warning('V4 cache save failed: %s', str(ex)[:80])


def _load_v4_cache():
    """Load V4 routes + pool cache from disk on startup."""
    if not os.path.exists(V4_CACHE_FILE):
        return
    try:
        with open(V4_CACHE_FILE) as f:
            payload = json.load(f)
        loaded_pools = 0
        loaded_routes = 0
        for al, pd in payload.get('v4_pool_cache', {}).items():
            pool_id_hex = pd['pool_id']
            pool_id_bytes = bytes.fromhex(pool_id_hex[2:] if pool_id_hex.startswith('0x') else pool_id_hex)
            _v4_pool_cache[al] = {
                'pool_id': pool_id_bytes,
                'pool_key': tuple(pd['pool_key']),  # list → tuple
                'c0': pd['c0'],
                'c1': pd['c1'],
                'fee': pd['fee'],
                'tick_spacing': pd['tick_spacing'],
                'hooks': pd['hooks'],
                'quote_sym': pd['quote_sym'],
                'quote_dec': pd['quote_dec'],
                'quote_addr': pd['quote_addr'],
                'liq': pd['liq'],
            }
            loaded_pools += 1
        for al, route in payload.get('v4_routes', {}).items():
            if al not in TOKEN_ROUTE:
                # Finding 6 (R2): Filter cached routes through QUOTE_ENABLED
                # Don't restore routes for disabled quote tokens
                pool_d = _v4_pool_cache.get(al)
                if pool_d:
                    qa = pool_d.get('quote_addr', '')
                    qs = pool_d.get('quote_sym', '?')
                    if qs not in ('ETH', '?') and not QUOTE_ENABLED.get(qa, False):
                        logger.info('V4 cache: skipping route %s for %s — %s quote disabled', route, al[:10], qs)
                        continue
                TOKEN_ROUTE[al] = route
                loaded_routes += 1
        age = time.time() - payload.get('ts', 0)
        logger.info('V4 cache loaded: %d pools, %d routes (%.0fs old)', loaded_pools, loaded_routes, age)
    except Exception as ex:
        logger.warning('V4 cache load failed: %s', str(ex)[:80])


# Load V4 cache on startup
_load_v4_cache()


def fetch(url):
    try:
        return json.loads(urllib.request.urlopen(urllib.request.Request(url, headers=HDR), timeout=10).read())
    except:
        return None


def price(addr):
    """Get price + momentum data from DexScreener."""
    d = fetch(f'https://api.dexscreener.com/latest/dex/tokens/{addr}')
    if not d: return None
    best = None
    best_liq = 0
    for p in (d.get('pairs') or []):
        if p.get('chainId') == 'robinhood':
            liq = float(p.get('liquidity', {}).get('usd', 0))
            if liq > best_liq:
                best_liq = liq
                best = p
    if not best: return None
    return {
        'p': float(best.get('priceUsd', 0)),
        'c5': best.get('priceChange', {}).get('m5', 0) or 0,
        'c1h': best.get('priceChange', {}).get('h1', 0) or 0,
        'b5': best.get('txns', {}).get('m5', {}).get('buys', 0),
        's5': best.get('txns', {}).get('m5', {}).get('sells', 0),
        'liq': best_liq,
        'fdv': float(best.get('fdv', 0)),
        'sym': best.get('baseToken', {}).get('symbol', '?'),
    }


def bal(addr):
    tc = w3.eth.contract(address=Web3.to_checksum_address(addr), abi=E20)
    r = tc.functions.balanceOf(W).call()
    d = tc.functions.decimals().call()
    return r, d


def eth_bal():
    return float(Web3.from_wei(w3.eth.get_balance(W), 'ether'))


def update_bal(sym=None, addr=None, tamt=0, tval=0):
    try:
        e = eth_bal()
        t = tval + e * ETH_USD
        d = {'total_usd': round(t, 2), 'holdings': [], 'eth_balance': e, 'eth_price': ETH_USD,
             'wallet': W, 'chain_id': CID, 'platform': 'robinhood_chain', 'cost_basis': COST_BASIS, 'source': 'robinhood_chain'}
        if sym and tamt > 0:
            d['holdings'].append({'symbol': sym, 'amount': tamt, 'value_usd': round(tval, 2), 'address': addr})
        with open('/tmp/robinhood-balance.json', 'w') as f: json.dump(d, f, indent=2)
    except: pass


def approve(addr):
    tc = w3.eth.contract(address=Web3.to_checksum_address(addr), abi=E20)
    a = tc.functions.allowance(W, Web3.to_checksum_address(AGG)).call()
    if a > 10**30: return True
    tx = tc.functions.approve(Web3.to_checksum_address(AGG), 2**256-1).build_transaction(
        {'from': W, 'nonce': w3.eth.get_transaction_count(W), 'gas': 100000, 'gasPrice': int(w3.eth.gas_price*2), 'chainId': CID})
    s = acct.sign_transaction(tx)
    h = w3.eth.send_raw_transaction(s.raw_transaction)
    r = w3.eth.wait_for_transaction_receipt(h, timeout=60)
    return r['status'] == 1


def sell(addr, sym, market_price=0):
    r, d = bal(addr)
    if r == 0: return 0.0
    if not approve(addr): return 0.0
    tokens_human = r / (10**d)
    logger.info('SELL %s (%s tokens)', sym, f'{tokens_human:,.0f}')
    steps = [{'stepType':2,'tokenIn':Web3.to_checksum_address(addr),'tokenOut':Z,'pool':Z,'fee':0,'tickSpacing':200,'hook':HOOK,'hookData':b'','recipient':POSMGR,'poolId':b'\x00'*32}]
    # ═══ FIX 1: amountOutMin on sell — loose 50% anti-MEV protection ═══
    # Loose so stop-loss exits always go through, but blocks sandwich attacks
    min_out = 0
    if market_price > 0 and tokens_human > 0:
        expected_eth = (tokens_human * market_price) / ETH_USD
        min_eth = expected_eth * 0.50  # 50% floor — allows exits at any reasonable price
        min_out = Web3.to_wei(min_eth, 'ether')
        logger.info('  SELL amountOutMin: %.6f ETH ($%.2f) — 50%% floor', min_eth, min_eth * ETH_USD)
    try:
        # Try with 50% floor first, then emergency retry with min_out=0
        for attempt_min, attempt_label in [(min_out, '50% floor'), (0, 'EMERGENCY min_out=0')]:
            tx = sc.functions.swap(steps, Z, r, attempt_min, int(time.time())+300).build_transaction(
                {'from':W,'value':0,'nonce':w3.eth.get_transaction_count(W),'gas':400000,'gasPrice':int(w3.eth.gas_price*5),'chainId':CID})  # 5x gas = INSTANT
            s = acct.sign_transaction(tx)
            h = w3.eth.send_raw_transaction(s.raw_transaction)
            rc = w3.eth.wait_for_transaction_receipt(h, timeout=120)
            if rc['status'] == 1:
                e = eth_bal()
                logger.info('SOLD %s → %.6f ETH ($%.2f) [%s]', sym, e, e*ETH_USD, attempt_label)
                update_bal()
                return e
            logger.error('SELL %s REVERTED (%s)%s', sym, attempt_label,
                         ' — retrying with min_out=0' if attempt_min > 0 else '')
        return 0.0
    except Exception as ex:
        logger.error('SELL %s ERR: %s', sym, ex)
        return 0.0


def buy(addr, eth_amt, sym, market_price=0):
    wei = Web3.to_wei(eth_amt, 'ether')
    logger.info('BUY %s with %.6f ETH ($%.2f)', sym, eth_amt, eth_amt*ETH_USD)
    steps = [{'stepType':2,'tokenIn':Z,'tokenOut':Web3.to_checksum_address(addr),'pool':Z,'fee':0,'tickSpacing':200,'hook':HOOK,'hookData':b'','recipient':POSMGR,'poolId':b'\x00'*32}]
    # ═══ FIX 1: amountOutMin — reject on-chain if fill > 3% worse than market ═══
    min_out = 0
    if market_price > 0:
        try:
            tc = w3.eth.contract(address=Web3.to_checksum_address(addr), abi=E20)
            d = tc.functions.decimals().call()
        except Exception:
            d = 18
        expected_tokens = (eth_amt * ETH_USD) / market_price
        min_tokens = expected_tokens * (1 - MAX_SLIPPAGE / 100)
        min_out = int(min_tokens * (10 ** d))
        logger.info('  amountOutMin: %.0f tokens (%.0f expected, %d%% tolerance)', min_tokens, expected_tokens, MAX_SLIPPAGE)
    try:
        tx = sc.functions.swap(steps, Z, wei, min_out, int(time.time())+300).build_transaction(
            {'from':W,'value':wei,'nonce':w3.eth.get_transaction_count(W),'gas':350000,'gasPrice':int(w3.eth.gas_price*2.5),'chainId':CID})
        s = acct.sign_transaction(tx)
        h = w3.eth.send_raw_transaction(s.raw_transaction)
        rc = w3.eth.wait_for_transaction_receipt(h, timeout=120)
        if rc['status'] == 1:
            r, d = bal(addr)
            tb = r/(10**d)
            logger.info('BOUGHT %s: %s tokens', sym, f'{tb:,.0f}')
            try:
                approve(addr)
            except Exception as appr_ex:
                logger.error('PONS BUY %s: post-buy approval failed (non-fatal): %s', sym, appr_ex)
            entry_usd = eth_amt * ETH_USD / tb if tb > 0 else 0
            return tb, entry_usd
        logger.error('BUY %s REVERTED', sym)
        return 0, 0
    except Exception as ex:
        logger.error('BUY %s ERR: %s', sym, ex)
        return 0, 0


def pons_ok(addr):
    for attempt in range(2):
        try:
            ca = Web3.to_checksum_address(addr)
            steps = [{'stepType':2,'tokenIn':Z,'tokenOut':ca,'pool':Z,'fee':0,'tickSpacing':200,'hook':HOOK,'hookData':b'','recipient':POSMGR,'poolId':b'\x00'*32}]
            nonce = w3.eth.get_transaction_count(W)
            gp = int(w3.eth.gas_price * 2)
            tx = sc.functions.swap(steps, Z, Web3.to_wei(0.0005,'ether'), 0, int(time.time())+300).build_transaction(
                {'from':W,'value':Web3.to_wei(0.0005,'ether'),'nonce':nonce,'gas':500000,'gasPrice':gp,'chainId':CID})
            w3.eth.estimate_gas(tx)
            return True
        except:
            if attempt == 0: time.sleep(1)
    return False


def honeypot_check(addr):
    """CRITICAL: Simulate buy + sell via eth_call with state overrides BEFORE committing real money.
    Returns True if token is SAFE (can be sold). Returns False if HONEYPOT.

    FIX (Codex Ultra): Previous implementation used separate eth_calls for buy and sell,
    so the sell sim didn't have the tokens from the buy sim → false positives.
    Now uses state overrides to inject a fake token balance for the sell simulation,
    making the sell test independent of buy state."""
    ca = Web3.to_checksum_address(addr)
    route = TOKEN_ROUTE.get(addr.lower(), 'pons')

    try:
        # Step 1: Simulate buy to verify pool exists and we can get tokens
        if route.startswith('v4'):
            # V4: use cached pool data (exact on-chain PoolKey) for Quoter check
            pool_data = _v4_pool_cache.get(addr.lower())
            if not pool_data:
                logger.warning('  HONEYPOT CHECK: V4 no cached pool data — SKIP')
                return False
            pool_key = pool_data['pool_key']
            quote_dec = pool_data['quote_dec']
            c0, c1 = pool_data['c0'], pool_data['c1']
            qt_is_c0 = (pool_data['quote_addr'] == c0.lower())
            buy_zero_for_one = qt_is_c0  # Send quote (c0) to receive token (c1)
            test_amt = int(0.0001 * (10 ** quote_dec))
            try:
                result = v4_quoter.functions.quoteExactInputSingle(
                    (pool_key, buy_zero_for_one, test_amt, b'')).call()
                tokens_out = result[0]
            except Exception:
                tokens_out = 0
            if tokens_out == 0:
                logger.warning('  HONEYPOT CHECK: V4 buy quote returned 0 — SKIP')
                return False
            # Verify sell direction works too (reverse direction)
            sell_zero_for_one = not buy_zero_for_one
            try:
                sell_result = v4_quoter.functions.quoteExactInputSingle(
                    (pool_key, sell_zero_for_one, tokens_out, b'')).call()
                sell_out = sell_result[0]
            except Exception:
                sell_out = 0
            if sell_out == 0:
                logger.warning('  HONEYPOT CHECK: V4 sell quote returned 0 — HONEYPOT! BLACKLISTING %s', addr[:10])
                return False
            # Roundtrip sanity: should get back at least 50% of what we put in
            roundtrip = sell_out / test_amt * 100 if test_amt > 0 else 0
            if roundtrip < 50:
                logger.warning('  HONEYPOT CHECK: V4 roundtrip %.1f%% — too much tax/fee — SKIP %s', roundtrip, addr[:10])
                return False
            # Finding 5 (R2): Simulate actual token transfer to catch transfer taxes/blacklists.
            # Use state override to inject a fake balance, then call transfer(W, 1).
            v4_token = c1 if qt_is_c0 else c0
            v4_token_cs = Web3.to_checksum_address(v4_token)
            try:
                # Build transfer(W, 1) calldata — tests the real transfer path
                token_c = w3.eth.contract(address=v4_token_cs, abi=E20)
                transfer_abi = json.loads('[{"inputs":[{"name":"to","type":"address"},{"name":"value","type":"uint256"}],"name":"transfer","outputs":[{"name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"}]')
                token_t = w3.eth.contract(address=v4_token_cs, abi=transfer_abi)
                tx_data = token_t.functions.transfer(W, 1).build_transaction(
                    {'from': W, 'gas': 200000, 'gasPrice': 0, 'nonce': 0, 'chainId': CID, 'value': 0})
                # State override: give W a huge token balance (slot 0 mapping assumption)
                # balanceOf mapping slot = keccak256(abi.encode(address, uint256(slot)))
                # Try common balance slots (0, 1, 2) via brute-force override of balanceOf return
                # Simpler: just override the balance via the account's storage directly
                # Most ERC20s store balances at mapping slot 0: keccak(addr . slot)
                bal_slot = Web3.keccak(
                    bytes.fromhex(W[2:].lower().zfill(64)) + (0).to_bytes(32, 'big')
                )
                big_bal = (10**30).to_bytes(32, 'big')
                state_override = {
                    v4_token_cs: {
                        'stateDiff': {
                            '0x' + bal_slot.hex(): '0x' + big_bal.hex(),
                        }
                    }
                }
                # eth_call with state override
                result = w3.eth.call(tx_data, 'latest', state_override)
                # If we get here without revert, transfer is allowed
                logger.info('  HONEYPOT CHECK: V4 transfer sim OK for %s', v4_token[:10])
            except Exception as tex:
                err_str = str(tex)[:120]
                if 'revert' in err_str.lower() or 'execution reverted' in err_str.lower():
                    logger.warning('  HONEYPOT CHECK: V4 token %s BLOCKS transfer — HONEYPOT! %s', v4_token[:10], err_str)
                    return False
                # Non-revert errors (state override not supported, RPC issues) — log but proceed
                # The Quoter roundtrip already passed, so this is best-effort
                logger.info('  HONEYPOT CHECK: V4 transfer sim inconclusive: %s — proceeding (roundtrip %.1f%% OK)', err_str, roundtrip)
            # CRITICAL: Simulate actual V4 sell through Universal Router to catch
            # hook-blocked sells (e.g. IPUNK — Quoter passes but UR reverts because
            # beforeSwap hook rejects unauthorized sellers).
            try:
                sell_commands, sell_inputs = _encode_v4_swap(
                    pool_key, sell_zero_for_one, tokens_out, 0)
                sell_deadline = int(time.time()) + 300
                sell_tx = v4_router.functions.execute(
                    sell_commands, sell_inputs, sell_deadline
                ).build_transaction({
                    'from': W, 'value': 0,
                    'nonce': w3.eth.get_transaction_count(W),
                    'gas': 500000, 'gasPrice': int(w3.eth.gas_price * 2),
                    'chainId': CID})
                permit2_ca_cs = Web3.to_checksum_address(PERMIT2)
                p2_slot = Web3.keccak(
                    bytes.fromhex(permit2_ca_cs[2:].lower().zfill(64)) +
                    Web3.keccak(bytes.fromhex(W[2:].lower().zfill(64)) + (1).to_bytes(32, 'big'))
                )
                ur_sell_override = {
                    v4_token_cs: {
                        'stateDiff': {
                            '0x' + bal_slot.hex(): '0x' + big_bal.hex(),
                            '0x' + p2_slot.hex(): '0x' + ((2**256-1).to_bytes(32, 'big')).hex(),
                        }
                    }
                }
                w3.eth.call(sell_tx, 'latest', ur_sell_override)
                logger.info('  HONEYPOT CHECK: V4 UR sell sim OK — hook allows sells')
            except Exception as ur_ex:
                ur_err = str(ur_ex)[:200]
                if 'sell not allowed' in ur_err.lower() or '6570f956' in ur_err or '90bfb865' in ur_err:
                    logger.warning('  🚨 HONEYPOT DETECTED: V4 hook BLOCKS sells for %s — BLACKLISTING: %s',
                                   addr[:10], ur_err[:80])
                    PONS_BLACKLIST.add(addr.lower())
                    return False
                logger.info('  HONEYPOT CHECK: V4 UR sell sim inconclusive: %s — proceeding (roundtrip %.1f%% OK)',
                            ur_err[:80], roundtrip)
            logger.info('  HONEYPOT CHECK: V4 roundtrip OK (%.1f%%) + UR sell OK — SAFE', roundtrip)
            return True

        elif route.startswith('v3'):
            fee = int(route.split('_')[1])
            weth = Web3.to_checksum_address(WETH_ADDR)

            if route.startswith('v3spy'):
                quote_ca = Web3.to_checksum_address(SPY_ADDR)
                test_buy = int(0.0001 * 1e18)
                # Use QuoterV2 for stateless quote (no state override needed)
                try:
                    result = quoter_v2.functions.quoteExactInputSingle(
                        (quote_ca, ca, test_buy, fee, 0)).call()
                    tokens_out = result[0]
                except Exception:
                    tokens_out = 0
                if tokens_out == 0:
                    logger.warning('  HONEYPOT CHECK: V3-SPY buy quote returned 0 — SKIP')
                    return False
                # Quote sell direction
                try:
                    sell_result = quoter_v2.functions.quoteExactInputSingle(
                        (ca, quote_ca, tokens_out, fee, 0)).call()
                    sell_out = sell_result[0]
                except Exception:
                    sell_out = 0
            else:
                test_buy = Web3.to_wei(0.0001, 'ether')
                # Use QuoterV2 for stateless quote
                try:
                    result = quoter_v2.functions.quoteExactInputSingle(
                        (weth, ca, test_buy, fee, 0)).call()
                    tokens_out = result[0]
                except Exception:
                    tokens_out = 0
                if tokens_out == 0:
                    logger.warning('  HONEYPOT CHECK: V3 buy quote returned 0 — SKIP')
                    return False
                # Quote sell direction
                try:
                    sell_result = quoter_v2.functions.quoteExactInputSingle(
                        (ca, weth, tokens_out, fee, 0)).call()
                    sell_out = sell_result[0]
                except Exception:
                    sell_out = 0

            if sell_out == 0:
                logger.warning('  HONEYPOT CHECK: sell quote returned 0 — HONEYPOT! BLACKLISTING %s', addr[:10])
                return False

            # Roundtrip sanity check: should get back at least 50% (accounts for fees/slippage)
            roundtrip = sell_out / test_buy * 100 if test_buy > 0 else 0
            if roundtrip < 50:
                logger.warning('  HONEYPOT CHECK: roundtrip %.1f%% — excessive tax — SKIP %s', roundtrip, addr[:10])
                return False
            logger.info('  HONEYPOT CHECK: V3 roundtrip OK (%.1f%%) — SAFE', roundtrip)
            return True

        else:
            # Pons: The swap contract returns EMPTY bytes from eth_call() — no
            # return data at all — so we cannot read tokens_out from the call
            # result.  Use estimate_gas() instead: success = swap would work.
            # (Codex Ultra fix — Sep 7 2026)

            # ── BUY check: estimate_gas on a real-sized Pons swap ──
            steps_buy = [{'stepType':2,'tokenIn':Z,'tokenOut':ca,'pool':Z,'fee':0,'tickSpacing':200,'hook':HOOK,'hookData':b'','recipient':POSMGR,'poolId':b'\x00'*32}]
            test_wei = Web3.to_wei(0.0005, 'ether')
            buy_tx = sc.functions.swap(steps_buy, Z, test_wei, 0, int(time.time())+300).build_transaction(
                {'from':W,'value':test_wei,'nonce':w3.eth.get_transaction_count(W),
                 'gas':500000,'gasPrice':int(w3.eth.gas_price*2),'chainId':CID})
            try:
                buy_gas = w3.eth.estimate_gas(buy_tx)
            except Exception as bex:
                logger.warning('  HONEYPOT CHECK: Pons buy estimate_gas FAILED: %s — INCONCLUSIVE', str(bex)[:80])
                return False  # inconclusive — block but caller must NOT blacklist

            logger.info('  HONEYPOT CHECK: Pons buy estimate_gas OK (%d gas)', buy_gas)

            # ── SELL check: estimate_gas with state override ──
            # Inject a fake token balance + approval so the sell sim has tokens
            # to sell.  Use a large synthetic amount (10^18 raw units).
            synthetic_tokens = 10**18
            steps_sell = [{'stepType':2,'tokenIn':ca,'tokenOut':Z,'pool':Z,'fee':0,'tickSpacing':200,'hook':HOOK,'hookData':b'','recipient':POSMGR,'poolId':b'\x00'*32}]
            sell_tx = sc.functions.swap(steps_sell, Z, synthetic_tokens, 0, int(time.time())+300).build_transaction(
                {'from':W,'value':0,'nonce':w3.eth.get_transaction_count(W),
                 'gas':500000,'gasPrice':int(w3.eth.gas_price*2),'chainId':CID})

            # Build state override: inject balance at slot 0, approval at slot 1
            balance_slot = Web3.keccak(
                bytes.fromhex(W[2:].lower().zfill(64)) +
                (0).to_bytes(32, 'big')  # slot 0 — most common for balanceOf
            )
            approval_slot = Web3.keccak(
                bytes.fromhex(AGG[2:].lower().zfill(64)) +
                Web3.keccak(
                    bytes.fromhex(W[2:].lower().zfill(64)) +
                    (1).to_bytes(32, 'big')  # slot 1 — most common for allowances
                )
            )
            big_bal = (10**30).to_bytes(32, 'big')
            max_approval = ((2**256 - 1).to_bytes(32, 'big'))
            state_override = {
                ca: {
                    'stateDiff': {
                        '0x' + balance_slot.hex(): '0x' + big_bal.hex(),
                        '0x' + approval_slot.hex(): '0x' + max_approval.hex(),
                    }
                }
            }

            try:
                sell_gas = w3.eth.estimate_gas(sell_tx, 'latest', state_override)
                logger.info('  HONEYPOT CHECK: Pons sell estimate_gas OK (%d gas) — SAFE', sell_gas)
                return True
            except Exception as sex:
                err_str = str(sex)[:120]
                if 'revert' in err_str.lower() or 'execution reverted' in err_str.lower():
                    logger.warning('  🚨 HONEYPOT DETECTED: Pons sell reverted — BLACKLISTING %s: %s', addr[:10], err_str)
                    PONS_BLACKLIST.add(addr.lower())
                    _save_blacklist()
                    return False
                # Non-revert error (state override unsupported, RPC glitch) — INCONCLUSIVE
                # Block entry but do NOT blacklist — token can retry next scan.
                logger.warning('  HONEYPOT CHECK: Pons sell sim inconclusive: %s — BLOCKING (not blacklisting)', err_str)
                return False

    except Exception as ex:
        logger.warning('  🚨 HONEYPOT CHECK FAILED: %s — INCONCLUSIVE (not blacklisting)', str(ex)[:80])
        return False


def v3_ok(addr):
    """Check if token can be swapped via Uniswap V3 (WETH pair ONLY).

    CRITICAL: Must verify the DexScreener pair is actually WETH-denominated.
    Gas estimation alone is NOT sufficient — the router accepts non-WETH pairs
    but returns 0 tokens (learned the hard way with hoodrat/USDG).
    """
    # Step 1: Check pair data to verify quote token is WETH/ETH
    # Use cached pair data from scan() if available (saves ~1s API call)
    al = addr.lower()
    cached = _pair_data_cache.get(al)
    if cached and (time.time() - cached['ts']) < 120:  # Cache valid for 2 min
        qt_addr = cached['quote_addr']
        qt_sym = cached['quote_sym']
    else:
        # Fallback: fetch from DexScreener (only if cache miss)
        d = fetch(f'https://api.dexscreener.com/latest/dex/tokens/{addr}')
        if not d:
            return False
        qt_addr = ''
        qt_sym = '?'
        for p in (d.get('pairs') or []):
            if p.get('chainId') != 'robinhood':
                continue
            qt = p.get('quoteToken', {})
            qt_addr = (qt.get('address') or '').lower()
            qt_sym = (qt.get('symbol') or '').upper()
            # Cache pair data for v4_ok (saves re-fetch)
            _pair_data_cache[al] = {
                'quote_sym': qt_sym,
                'quote_addr': qt_addr,
                'pair_addr': p.get('pairAddress', ''),
                'ts': time.time(),
            }
            break
    weth_pair = (qt_addr == WETH_ADDR.lower() or qt_sym in ('WETH', 'ETH'))
    spy_pair = qt_addr in ACCEPTED_QUOTES
    # Also accept any enabled quote token from the registry
    enabled_quote = qt_addr in QUOTE_TOKENS and QUOTE_ENABLED.get(qt_addr, False)
    if not weth_pair and not spy_pair and not enabled_quote:
        logger.info('  %s: V3 REJECTED — not WETH/SPY/enabled-quote-paired (quote=%s)', addr[:10], qt_sym)
        return False

    # Step 2: Simulate the swap via eth_call to verify we'd get tokens back
    # Gas estimation alone is NOT enough — V3 pools can execute with 0 output
    # if concentrated liquidity is out of range.
    ca = Web3.to_checksum_address(addr)

    if spy_pair:
        # SPY-paired token: simulate SPY → token swap
        quote_sym, quote_fee = ACCEPTED_QUOTES[qt_addr]
        spy_ca = Web3.to_checksum_address(SPY_ADDR)
        test_amt = int(0.0001 * 1e18)  # 0.0001 SPY
        try:
            params = (spy_ca, ca, quote_fee, W, test_amt, 0, 0)
            tx = v3r.functions.exactInputSingle(params).build_transaction(
                {'from':W,'value':0,'nonce':w3.eth.get_transaction_count(W),
                 'gas':500000,'gasPrice':int(w3.eth.gas_price*2),'chainId':CID})
            result = w3.eth.call(tx)
            out_amt = int.from_bytes(result[:32], 'big') if len(result) >= 32 else 0
            if out_amt > 0:
                TOKEN_ROUTE[addr.lower()] = f'v3spy_{quote_fee}'
                logger.info('  %s: V3-SPY fee=%d VERIFIED (output=%d for 0.0001 SPY)', addr[:10], quote_fee, out_amt)
                return True
            logger.info('  %s: V3-SPY fee=%d output=0 — SKIP', addr[:10], quote_fee)
        except:
            pass
        return False

    # WETH-paired: existing logic
    weth = Web3.to_checksum_address(WETH_ADDR)
    test_amt = Web3.to_wei(0.0001, 'ether')
    for fee in V3_FEES:
        try:
            # SwapRouter02 params: no deadline in tuple
            params = (weth, ca, fee, W, test_amt, 0, 0)
            tx = v3r.functions.exactInputSingle(params).build_transaction(
                {'from':W,'value':test_amt,'nonce':w3.eth.get_transaction_count(W),
                 'gas':500000,'gasPrice':int(w3.eth.gas_price*2),'chainId':CID})
            # Use eth_call to simulate and get actual output amount
            result = w3.eth.call(tx)
            out_amt = int.from_bytes(result[:32], 'big') if len(result) >= 32 else 0
            if out_amt == 0:
                logger.info('  %s: V3 fee=%d simulated OK but output=0 — SKIP', addr[:10], fee)
                continue
            TOKEN_ROUTE[addr.lower()] = f'v3_{fee}'
            logger.info('  %s: V3 fee=%d VERIFIED (output=%d for 0.0001 ETH)', addr[:10], fee, out_amt)
            return True
        except:
            pass
    return False


def _unwrap_all_weth():
    """Safety: unwrap ALL WETH back to native ETH. Called on V3 failures."""
    try:
        weth_erc = w3.eth.contract(address=Web3.to_checksum_address(WETH_ADDR), abi=E20)
        weth_bal = weth_erc.functions.balanceOf(W).call()
        if weth_bal > 0:
            logger.info('Unwrapping %s WETH → ETH', Web3.from_wei(weth_bal, 'ether'))
            tx = weth_c.functions.withdraw(weth_bal).build_transaction(
                {'from': W, 'nonce': w3.eth.get_transaction_count(W),
                 'gas': 60000, 'gasPrice': int(w3.eth.gas_price * 3), 'chainId': CID})
            s = acct.sign_transaction(tx)
            h = w3.eth.send_raw_transaction(s.raw_transaction)
            r = w3.eth.wait_for_transaction_receipt(h, timeout=60)
            if r['status'] == 1:
                logger.info('WETH unwrapped OK. ETH: %.6f', eth_bal())
            else:
                logger.error('WETH unwrap REVERTED')
    except Exception as ex:
        logger.error('WETH unwrap ERR: %s', ex)


def v3_buy(addr, eth_amt, sym, market_price=0):
    """Buy token via V3 SwapRouter02: wrap ETH → WETH, then swap WETH → token."""
    route = TOKEN_ROUTE.get(addr.lower(), 'v3_10000')
    fee = int(route.split('_')[1])
    wei = Web3.to_wei(eth_amt, 'ether')
    logger.info('V3 BUY %s with %.6f ETH ($%.2f) fee=%d', sym, eth_amt, eth_amt*ETH_USD, fee)
    # ═══ FIX 1: amountOutMin for V3 buy ═══
    min_out = 0
    if market_price > 0:
        try:
            tc = w3.eth.contract(address=Web3.to_checksum_address(addr), abi=E20)
            d = tc.functions.decimals().call()
        except Exception:
            d = 18
        expected_tokens = (eth_amt * ETH_USD) / market_price
        min_tokens = expected_tokens * (1 - MAX_SLIPPAGE / 100)
        min_out = int(min_tokens * (10 ** d))
        logger.info('  V3 amountOutMin: %.0f tokens (%d%% tolerance)', min_tokens, MAX_SLIPPAGE)
    try:
        # Wrap ETH → WETH first
        wrap_tx = weth_c.functions.deposit().build_transaction(
            {'from':W,'value':wei,'nonce':w3.eth.get_transaction_count(W),
             'gas':60000,'gasPrice':int(w3.eth.gas_price*3),'chainId':CID})
        s = acct.sign_transaction(wrap_tx)
        h = w3.eth.send_raw_transaction(s.raw_transaction)
        w3.eth.wait_for_transaction_receipt(h, timeout=60)

        # Approve WETH for V3 Router
        weth_erc = w3.eth.contract(address=Web3.to_checksum_address(WETH_ADDR), abi=E20)
        allowance = weth_erc.functions.allowance(W, Web3.to_checksum_address(V3_ROUTER)).call()
        if allowance < wei:
            appr_tx = weth_erc.functions.approve(Web3.to_checksum_address(V3_ROUTER), 2**256-1).build_transaction(
                {'from':W,'nonce':w3.eth.get_transaction_count(W),'gas':100000,
                 'gasPrice':int(w3.eth.gas_price*3),'chainId':CID})
            s = acct.sign_transaction(appr_tx)
            h = w3.eth.send_raw_transaction(s.raw_transaction)
            w3.eth.wait_for_transaction_receipt(h, timeout=60)

        # Swap WETH → token via multicall (deadline-protected)
        ca = Web3.to_checksum_address(addr)
        weth = Web3.to_checksum_address(WETH_ADDR)
        params = (weth, ca, fee, W, wei, min_out, 0)
        swap_calldata = v3r.encode_abi('exactInputSingle', args=[params])
        deadline = int(time.time()) + 300
        swap_tx = v3r.functions.multicall(deadline, [bytes.fromhex(swap_calldata[2:])]).build_transaction(
            {'from':W,'value':0,'nonce':w3.eth.get_transaction_count(W),
             'gas':400000,'gasPrice':int(w3.eth.gas_price*3),'chainId':CID})
        s = acct.sign_transaction(swap_tx)
        h = w3.eth.send_raw_transaction(s.raw_transaction)
        rc = w3.eth.wait_for_transaction_receipt(h, timeout=120)
        if rc['status'] == 1:
            r, d = bal(addr)
            tb = r/(10**d)
            if tb <= 0:
                # Swap succeeded on-chain but returned 0 tokens — BAD PAIR
                logger.error('V3 BUY %s: swap ok but 0 tokens received — unwrapping WETH', sym)
                _unwrap_all_weth()
                PONS_BLACKLIST.add(addr.lower())  # Never try this token again
                _save_blacklist()
                return 0, 0
            logger.info('V3 BOUGHT %s: %s tokens', sym, f'{tb:,.0f}')
            # Pre-approve token for V3 Router (for selling later) — non-fatal
            try:
                tok_c = w3.eth.contract(address=ca, abi=E20)
                a = tok_c.functions.allowance(W, Web3.to_checksum_address(V3_ROUTER)).call()
                if a < 10**30:
                    appr_tx = tok_c.functions.approve(Web3.to_checksum_address(V3_ROUTER), 2**256-1).build_transaction(
                        {'from':W,'nonce':w3.eth.get_transaction_count(W),'gas':100000,
                         'gasPrice':int(w3.eth.gas_price*3),'chainId':CID})
                    s = acct.sign_transaction(appr_tx)
                    h = w3.eth.send_raw_transaction(s.raw_transaction)
                    w3.eth.wait_for_transaction_receipt(h, timeout=60)
            except Exception as appr_ex:
                logger.error('V3 BUY %s: post-buy approval failed (non-fatal): %s', sym, appr_ex)
            entry_usd = eth_amt * ETH_USD / tb if tb > 0 else 0
            return tb, entry_usd
        logger.error('V3 BUY %s REVERTED — unwrapping WETH', sym)
        _unwrap_all_weth()
        return 0, 0
    except Exception as ex:
        logger.error('V3 BUY %s ERR: %s — unwrapping WETH', sym, ex)
        _unwrap_all_weth()
        return 0, 0


def v3_sell(addr, sym, market_price=0):
    """Sell token via V3 SwapRouter02: token → WETH, then unwrap WETH → ETH."""
    route = TOKEN_ROUTE.get(addr.lower(), 'v3_10000')
    fee = int(route.split('_')[1])
    r, d = bal(addr)
    if r == 0: return 0.0
    tokens_human = r / (10**d)
    logger.info('V3 SELL %s (%s tokens) fee=%d', sym, f'{tokens_human:,.0f}', fee)
    # ═══ FIX 1: amountOutMin on V3 sell — loose 50% anti-MEV ═══
    min_out = 0
    if market_price > 0 and tokens_human > 0:
        expected_weth = (tokens_human * market_price) / ETH_USD
        min_weth = expected_weth * 0.50
        min_out = Web3.to_wei(min_weth, 'ether')
        logger.info('  V3 SELL amountOutMin: %.6f WETH — 50%% floor', min_weth)
    try:
        ca = Web3.to_checksum_address(addr)
        weth = Web3.to_checksum_address(WETH_ADDR)

        # Approve token for V3 Router
        tok_c = w3.eth.contract(address=ca, abi=E20)
        a = tok_c.functions.allowance(W, Web3.to_checksum_address(V3_ROUTER)).call()
        if a < r:
            appr_tx = tok_c.functions.approve(Web3.to_checksum_address(V3_ROUTER), 2**256-1).build_transaction(
                {'from':W,'nonce':w3.eth.get_transaction_count(W),'gas':100000,
                 'gasPrice':int(w3.eth.gas_price*5),'chainId':CID})
            s = acct.sign_transaction(appr_tx)
            h = w3.eth.send_raw_transaction(s.raw_transaction)
            w3.eth.wait_for_transaction_receipt(h, timeout=60)

        # Swap token → WETH via multicall (deadline-protected)
        # Try with 50% floor first, then emergency retry with min_out=0
        for attempt_min, attempt_label in [(min_out, '50% floor'), (0, 'EMERGENCY min_out=0')]:
            params = (ca, weth, fee, W, r, attempt_min, 0)
            swap_calldata = v3r.encode_abi('exactInputSingle', args=[params])
            deadline = int(time.time()) + 300
            swap_tx = v3r.functions.multicall(deadline, [bytes.fromhex(swap_calldata[2:])]).build_transaction(
                {'from':W,'value':0,'nonce':w3.eth.get_transaction_count(W),
                 'gas':400000,'gasPrice':int(w3.eth.gas_price*5),'chainId':CID})
            s = acct.sign_transaction(swap_tx)
            h = w3.eth.send_raw_transaction(s.raw_transaction)
            rc = w3.eth.wait_for_transaction_receipt(h, timeout=120)
            if rc['status'] == 1:
                # Unwrap WETH → ETH
                _unwrap_all_weth()
                e = eth_bal()
                logger.info('V3 SOLD %s → %.6f ETH ($%.2f) [%s]', sym, e, e*ETH_USD, attempt_label)
                update_bal()
                return e
            logger.error('V3 SELL %s REVERTED (%s)%s', sym, attempt_label,
                         ' — retrying with min_out=0' if attempt_min > 0 else '')
        return 0.0
    except Exception as ex:
        logger.error('V3 SELL %s ERR: %s', sym, ex)
        return 0.0


def spy_bal():
    """Get SPY token balance in human-readable units."""
    try:
        spy_c = w3.eth.contract(address=Web3.to_checksum_address(SPY_ADDR), abi=E20)
        raw = spy_c.functions.balanceOf(W).call()
        return raw / 1e18  # SPY has 18 decimals
    except:
        return 0.0


def spy_bal_usd():
    """Get SPY balance in USD using QuoterV2 (SPY → WETH → USD)."""
    sb = spy_bal()
    if sb <= 0:
        return 0.0
    try:
        # Quote SPY → WETH to get USD value
        spy_raw = int(sb * 1e18)
        result = quoter_v2.functions.quoteExactInputSingle(
            (Web3.to_checksum_address(SPY_ADDR), Web3.to_checksum_address(WETH_ADDR),
             spy_raw, 500, 0)).call()
        weth_out = result[0]
        return float(Web3.from_wei(weth_out, 'ether')) * ETH_USD
    except:
        return sb * 750  # Fallback rough estimate


def v3_buy_spy(addr, spy_amt, sym, market_price=0):
    """Buy token via V3: SPY → token. Same logic as v3_buy but with SPY as quote."""
    route = TOKEN_ROUTE.get(addr.lower(), 'v3spy_500')
    fee = int(route.split('_')[1])
    spy_wei = int(spy_amt * 1e18)
    pre_spy_bal = spy_bal()  # Capture BEFORE swap for accurate entry_usd
    spy_usd = spy_bal_usd()  # For logging
    deploy_usd_pre = spy_amt / pre_spy_bal * spy_usd if pre_spy_bal > 0 else spy_amt * 750  # Pre-swap USD value
    logger.info('V3-SPY BUY %s with %.6f SPY (~$%.2f) fee=%d', sym, spy_amt, spy_amt / pre_spy_bal * spy_usd if pre_spy_bal > 0 else 0, fee)
    # amountOutMin — same 2% tolerance as WETH buys
    min_out = 0
    if market_price > 0:
        try:
            tc = w3.eth.contract(address=Web3.to_checksum_address(addr), abi=E20)
            d = tc.functions.decimals().call()
        except Exception:
            d = 18
        deploy_usd = spy_amt / spy_bal() * spy_usd if spy_bal() > 0 else spy_amt * 750
        expected_tokens = deploy_usd / market_price
        min_tokens = expected_tokens * (1 - MAX_SLIPPAGE / 100)
        min_out = int(min_tokens * (10 ** d))
        logger.info('  V3-SPY amountOutMin: %.0f tokens (%d%% tolerance)', min_tokens, MAX_SLIPPAGE)
    try:
        spy_ca = Web3.to_checksum_address(SPY_ADDR)
        ca = Web3.to_checksum_address(addr)

        # Approve SPY for V3 Router
        spy_c = w3.eth.contract(address=spy_ca, abi=E20)
        allowance = spy_c.functions.allowance(W, Web3.to_checksum_address(V3_ROUTER)).call()
        if allowance < spy_wei:
            appr_tx = spy_c.functions.approve(Web3.to_checksum_address(V3_ROUTER), 2**256-1).build_transaction(
                {'from':W,'nonce':w3.eth.get_transaction_count(W),'gas':100000,
                 'gasPrice':int(w3.eth.gas_price*3),'chainId':CID})
            s = acct.sign_transaction(appr_tx)
            h = w3.eth.send_raw_transaction(s.raw_transaction)
            w3.eth.wait_for_transaction_receipt(h, timeout=60)

        # Swap SPY → token via multicall (deadline-protected)
        params = (spy_ca, ca, fee, W, spy_wei, min_out, 0)
        swap_calldata = v3r.encode_abi('exactInputSingle', args=[params])
        deadline = int(time.time()) + 300
        swap_tx = v3r.functions.multicall(deadline, [bytes.fromhex(swap_calldata[2:])]).build_transaction(
            {'from':W,'value':0,'nonce':w3.eth.get_transaction_count(W),
             'gas':400000,'gasPrice':int(w3.eth.gas_price*3),'chainId':CID})
        s = acct.sign_transaction(swap_tx)
        h = w3.eth.send_raw_transaction(s.raw_transaction)
        rc = w3.eth.wait_for_transaction_receipt(h, timeout=120)
        if rc['status'] == 1:
            r, d = bal(addr)
            tb = r/(10**d)
            if tb <= 0:
                logger.error('V3-SPY BUY %s: swap ok but 0 tokens — BLACKLIST', sym)
                PONS_BLACKLIST.add(addr.lower())
                _save_blacklist()
                return 0, 0
            logger.info('V3-SPY BOUGHT %s: %s tokens', sym, f'{tb:,.0f}')
            # Pre-approve token for selling later (non-fatal — sell will retry)
            try:
                tok_c = w3.eth.contract(address=ca, abi=E20)
                a = tok_c.functions.allowance(W, Web3.to_checksum_address(V3_ROUTER)).call()
                if a < 10**30:
                    appr_tx = tok_c.functions.approve(Web3.to_checksum_address(V3_ROUTER), 2**256-1).build_transaction(
                        {'from':W,'nonce':w3.eth.get_transaction_count(W),'gas':100000,
                         'gasPrice':int(w3.eth.gas_price*3),'chainId':CID})
                    s = acct.sign_transaction(appr_tx)
                    h = w3.eth.send_raw_transaction(s.raw_transaction)
                    w3.eth.wait_for_transaction_receipt(h, timeout=60)
            except Exception as appr_ex:
                logger.error('V3-SPY BUY %s: post-buy approval failed (non-fatal): %s', sym, appr_ex)
            entry_usd = deploy_usd_pre / tb if tb > 0 else 0
            return tb, entry_usd
        logger.error('V3-SPY BUY %s REVERTED', sym)
        return 0, 0
    except Exception as ex:
        logger.error('V3-SPY BUY %s ERR: %s', sym, ex)
        return 0, 0


def v3_sell_spy(addr, sym, market_price=0):
    """Sell token via V3: token → SPY. Same logic as v3_sell but outputs SPY."""
    route = TOKEN_ROUTE.get(addr.lower(), 'v3spy_500')
    fee = int(route.split('_')[1])
    r, d = bal(addr)
    if r == 0: return 0.0
    tokens_human = r / (10**d)
    logger.info('V3-SPY SELL %s (%s tokens) fee=%d', sym, f'{tokens_human:,.0f}', fee)
    # amountOutMin — 50% floor (same anti-MEV as WETH sells)
    min_out = 0
    if market_price > 0 and tokens_human > 0:
        # Estimate how much SPY we should get back
        token_value_usd = tokens_human * market_price
        spy_price_usd = spy_bal_usd() / spy_bal() if spy_bal() > 0 else 750
        expected_spy = token_value_usd / spy_price_usd
        min_spy = expected_spy * 0.50
        min_out = int(min_spy * 1e18)
        logger.info('  V3-SPY SELL amountOutMin: %.6f SPY — 50%% floor', min_spy)
    try:
        ca = Web3.to_checksum_address(addr)
        spy_ca = Web3.to_checksum_address(SPY_ADDR)

        # Approve token for V3 Router
        tok_c = w3.eth.contract(address=ca, abi=E20)
        a = tok_c.functions.allowance(W, Web3.to_checksum_address(V3_ROUTER)).call()
        if a < r:
            appr_tx = tok_c.functions.approve(Web3.to_checksum_address(V3_ROUTER), 2**256-1).build_transaction(
                {'from':W,'nonce':w3.eth.get_transaction_count(W),'gas':100000,
                 'gasPrice':int(w3.eth.gas_price*5),'chainId':CID})
            s = acct.sign_transaction(appr_tx)
            h = w3.eth.send_raw_transaction(s.raw_transaction)
            w3.eth.wait_for_transaction_receipt(h, timeout=60)

        # Swap token → SPY via multicall (deadline-protected)
        for attempt_min, attempt_label in [(min_out, '50% floor'), (0, 'EMERGENCY min_out=0')]:
            params = (ca, spy_ca, fee, W, r, attempt_min, 0)
            swap_calldata = v3r.encode_abi('exactInputSingle', args=[params])
            deadline = int(time.time()) + 300
            swap_tx = v3r.functions.multicall(deadline, [bytes.fromhex(swap_calldata[2:])]).build_transaction(
                {'from':W,'value':0,'nonce':w3.eth.get_transaction_count(W),
                 'gas':400000,'gasPrice':int(w3.eth.gas_price*5),'chainId':CID})
            s = acct.sign_transaction(swap_tx)
            h = w3.eth.send_raw_transaction(s.raw_transaction)
            rc = w3.eth.wait_for_transaction_receipt(h, timeout=120)
            if rc['status'] == 1:
                new_spy = spy_bal()
                spy_usd = spy_bal_usd()
                eth_equiv = spy_usd / ETH_USD if ETH_USD > 0 else 0
                logger.info('V3-SPY SOLD %s → %.6f SPY (~$%.2f) [%s]', sym, new_spy, spy_usd, attempt_label)
                update_bal()
                return eth_equiv
            logger.error('V3-SPY SELL %s REVERTED (%s)%s', sym, attempt_label,
                         ' — retrying with min_out=0' if attempt_min > 0 else '')
        return 0.0
    except Exception as ex:
        logger.error('V3-SPY SELL %s ERR: %s', sym, ex)
        return 0.0


def _v4_pool_key(token_addr, quote_addr, fee, tick_spacing, hooks=Z):
    """Build a PoolKey tuple for V4. currency0 must be < currency1 (sorted)."""
    a = Web3.to_checksum_address(token_addr)
    b = Web3.to_checksum_address(quote_addr)
    if int(a, 16) < int(b, 16):
        return (a, b, fee, tick_spacing, Web3.to_checksum_address(hooks))
    else:
        return (b, a, fee, tick_spacing, Web3.to_checksum_address(hooks))


def _v4_zero_for_one(token_addr, quote_addr):
    """For a buy: we send quote (WETH/SPY) and receive token.
    zeroForOne = True if we're selling currency0 for currency1.
    For a sell: vice versa."""
    return int(Web3.to_checksum_address(quote_addr), 16) < int(Web3.to_checksum_address(token_addr), 16)


def _v4_pool_id(pool_key):
    """Compute PoolManager pool ID = keccak256(abi.encode(PoolKey))."""
    from eth_abi import encode
    encoded = encode(
        ['address', 'address', 'uint24', 'int24', 'address'],
        list(pool_key)
    )
    return Web3.keccak(encoded)


def _resolve_v4_pool(dex_token_addr, pool_id_hex):
    """Resolve a V4 pool from its DexScreener pool ID.
    Queries the V4 PoolManager Initialize event to get the exact PoolKey.
    Returns dict with pool_key, c0, c1, quote_sym, quote_dec or None."""
    al = dex_token_addr.lower()
    if al in _v4_pool_cache:
        return _v4_pool_cache[al]

    try:
        pool_id_bytes = bytes.fromhex(pool_id_hex[2:] if pool_id_hex.startswith('0x') else pool_id_hex)

        # Verify pool exists via StateView
        slot0 = v4_state.functions.getSlot0(pool_id_bytes).call()
        if slot0[0] == 0:  # sqrtPriceX96 == 0 means not initialized
            return None
        liq = v4_state.functions.getLiquidity(pool_id_bytes).call()
        if liq == 0:
            logger.info('  V4 pool %s has zero liquidity — skip', pool_id_hex[:16])
            return None

        # Query Initialize event to get exact currency0, currency1
        global V4_INIT_TOPIC
        if V4_INIT_TOPIC is None:
            V4_INIT_TOPIC = '0x' + Web3.keccak(
                text='Initialize(bytes32,address,address,uint24,int24,address,uint160,int24)'
            ).hex()

        pm = Web3.to_checksum_address(V4_POOL_MANAGER)
        current = w3.eth.block_number
        logs = w3.eth.get_logs({
            'fromBlock': max(0, current - 300000),
            'toBlock': 'latest',
            'address': pm,
            'topics': [V4_INIT_TOPIC, '0x' + pool_id_bytes.hex()],
        })

        if not logs:
            logger.warning('  V4 pool %s: no Initialize event found', pool_id_hex[:16])
            return None

        log = logs[0]
        topics = [t.hex() if isinstance(t, bytes) else t for t in log.get('topics', [])]
        if len(topics) < 4:
            return None

        c0 = Web3.to_checksum_address('0x' + topics[2][-40:])
        c1 = Web3.to_checksum_address('0x' + topics[3][-40:])

        # Data: fee(uint24), tickSpacing(int24), hooks(address), sqrtPriceX96, tick
        data = log['data']
        if isinstance(data, str):
            data = bytes.fromhex(data[2:] if data.startswith('0x') else data)
        fee = int.from_bytes(data[0:32], 'big')
        ts_raw = int.from_bytes(data[32:64], 'big')
        if ts_raw >= 2**23:
            ts_raw -= 2**24
        hooks = Web3.to_checksum_address('0x' + data[76:96].hex())

        pool_key = (c0, c1, fee, ts_raw, hooks)

        # Finding 2 (R2): Verify DexScreener token is plausibly one of c0/c1
        # V4 on-chain addresses may differ from DexScreener (e.g. RENT).
        # Match first 10 hex chars after '0x' (5 bytes = 40 bits) — strict enough to reject unrelated ERC20s.
        # NO known-quote bypass: a quote token should never be the "token we buy".
        dex_lower = dex_token_addr.lower()
        dex_prefix = dex_lower[:12]  # '0x' + first 10 hex chars
        c0_lower, c1_lower = c0.lower(), c1.lower()
        c0_prefix, c1_prefix = c0_lower[:12], c1_lower[:12]
        exact_match = (dex_lower == c0_lower or dex_lower == c1_lower)
        prefix_match = (dex_prefix == c0_prefix or dex_prefix == c1_prefix)
        if not exact_match and not prefix_match:
            logger.warning('  V4 pool %s: DexScreener token %s does NOT match c0=%s or c1=%s — SKIP (fail closed)',
                           pool_id_hex[:16], dex_token_addr[:10], c0[:10], c1[:10])
            return None

        # Identify the quote token
        quote_sym = '?'
        quote_dec = 18
        quote_addr_lower = ''
        for qt_a, (qt_s, qt_d) in QUOTE_TOKENS.items():
            if c0.lower() == qt_a or c1.lower() == qt_a:
                quote_sym = qt_s
                quote_dec = qt_d
                quote_addr_lower = qt_a
                break
        # Also check WETH
        if c0.lower() == WETH_ADDR.lower() or c1.lower() == WETH_ADDR.lower():
            quote_sym = 'ETH'
            quote_dec = 18
            quote_addr_lower = WETH_ADDR.lower()

        result = {
            'pool_id': pool_id_bytes,
            'pool_key': pool_key,
            'c0': c0,
            'c1': c1,
            'fee': fee,
            'tick_spacing': ts_raw,
            'hooks': hooks,
            'quote_sym': quote_sym,
            'quote_dec': quote_dec,
            'quote_addr': quote_addr_lower,
            'liq': liq,
        }
        _v4_pool_cache[al] = result
        logger.info('  V4 pool resolved: %s/%s fee=%d ts=%d hooks=%s liq=%d',
                     quote_sym, '?', fee, ts_raw, hooks[:10], liq)
        return result

    except Exception as ex:
        logger.warning('  V4 pool resolve failed: %s', str(ex)[:80])
        return None


def v4_ok(addr):
    """Check if token has a V4 pool by looking up cached DexScreener pool ID.
    On RH Chain, V4 pool IDs appear as 66-char pair addresses in DexScreener data.
    Uses Initialize event to recover exact PoolKey (currency addresses may differ from DexScreener).
    Returns True and sets TOKEN_ROUTE if a working V4 pool is found."""
    al = addr.lower()

    # Skip if already known
    if al in TOKEN_ROUTE:
        return False

    # Skip recently-failed tokens
    if al in _v3_fail_cache and (time.time() - _v3_fail_cache[al]) < V3_FAIL_TTL:
        return False

    # Check if we have a cached V4 pool ID from scan()
    cached = _pair_data_cache.get(al)
    pair_addr = cached.get('pair_addr', '') if cached else ''

    # V4 pool IDs are 66 chars (0x + 64 hex = 32 bytes), not 42-char contract addresses
    if len(pair_addr) != 66:
        return False  # Not a V4 pool

    # Resolve pool via Initialize event
    pool_data = _resolve_v4_pool(addr, pair_addr)
    if not pool_data:
        return False

    quote_sym = pool_data['quote_sym']
    # Check if this quote token is enabled
    if quote_sym == 'ETH':
        pass  # Always enabled
    elif quote_sym != '?':
        qt_lower = pool_data['quote_addr']
        if not QUOTE_ENABLED.get(qt_lower, False):
            logger.info('  %s: V4 pool found but %s quote not enabled yet', addr[:10], quote_sym)
            return False
    else:
        logger.info('  %s: V4 pool found but unknown quote token', addr[:10])
        return False

    # Verify via V4 Quoter that we can actually swap
    pool_key = pool_data['pool_key']
    quote_dec = pool_data['quote_dec']
    c0, c1 = pool_data['c0'], pool_data['c1']

    # Determine direction for a buy (send quote, receive token)
    # quote is one of c0/c1; the other is the token we're buying
    qt_is_c0 = (pool_data['quote_addr'] == c0.lower())
    buy_zero_for_one = qt_is_c0  # If quote is c0, send c0 to receive c1

    test_amt = int(0.0001 * (10 ** quote_dec))
    try:
        result = v4_quoter.functions.quoteExactInputSingle(
            (pool_key, buy_zero_for_one, test_amt, b'')).call()
        amount_out = result[0]
        if amount_out > 0:
            route_name = f'v4{quote_sym.lower()}_{pool_data["fee"]}_{pool_data["tick_spacing"]}'
            TOKEN_ROUTE[al] = route_name
            logger.info('  %s: V4 %s VERIFIED (output=%d for 0.0001 %s) route=%s',
                        addr[:10], quote_sym, amount_out, quote_sym, route_name)
            _save_v4_cache()  # Finding 6: persist immediately
            return True
    except Exception as ex:
        logger.info('  %s: V4 Quoter failed: %s', addr[:10], str(ex)[:60])

    return False


def _ensure_permit2_approval(token_addr, spender, amount):
    """Ensure Permit2 has approval for token → spender. Two-step:
    1. ERC20 approve token → Permit2 (max)
    2. Permit2 approve token → spender (amount, 30-day expiry)"""
    ca = Web3.to_checksum_address(token_addr)
    spender_ca = Web3.to_checksum_address(spender)
    permit2_ca = Web3.to_checksum_address(PERMIT2)

    # Step 1: ERC20 token → Permit2 (only if needed)
    tok_c = w3.eth.contract(address=ca, abi=E20)
    erc20_allowance = tok_c.functions.allowance(W, permit2_ca).call()
    if erc20_allowance < amount:
        logger.info('  Permit2: ERC20 approve %s → Permit2', ca[:10])
        tx = tok_c.functions.approve(permit2_ca, 2**256-1).build_transaction(
            {'from': W, 'nonce': w3.eth.get_transaction_count(W),
             'gas': 100000, 'gasPrice': int(w3.eth.gas_price * 3), 'chainId': CID})
        s = acct.sign_transaction(tx)
        h = w3.eth.send_raw_transaction(s.raw_transaction)
        rc = w3.eth.wait_for_transaction_receipt(h, timeout=60)
        # Finding 7 (R2): Check receipt status — mined revert must not be silently ignored
        if rc['status'] != 1:
            raise RuntimeError(f'ERC20 approve {ca[:10]}→Permit2 REVERTED (tx={h.hex()[:16]})')

    # Step 2: Permit2 approve token → spender
    p2_allowance = permit2_c.functions.allowance(W, ca, spender_ca).call()
    p2_amount = p2_allowance[0]
    p2_expiry = p2_allowance[1]
    if p2_amount < amount or p2_expiry < int(time.time()) + 3600:
        logger.info('  Permit2: approve %s → %s', ca[:10], spender_ca[:10])
        expiry = int(time.time()) + 30 * 86400  # 30 days
        tx = permit2_c.functions.approve(ca, spender_ca, 2**160 - 1, expiry).build_transaction(
            {'from': W, 'nonce': w3.eth.get_transaction_count(W),
             'gas': 100000, 'gasPrice': int(w3.eth.gas_price * 3), 'chainId': CID})
        s = acct.sign_transaction(tx)
        h = w3.eth.send_raw_transaction(s.raw_transaction)
        rc = w3.eth.wait_for_transaction_receipt(h, timeout=60)
        # Finding 7 (R2): Check receipt status
        if rc['status'] != 1:
            raise RuntimeError(f'Permit2 approve {ca[:10]}→{spender_ca[:10]} REVERTED (tx={h.hex()[:16]})')


def _encode_v4_swap(pool_key, zero_for_one, amount_in, min_out):
    """Encode a V4 swap via Universal Router v2.1.1.
    Command 0x10 = V4_SWAP. Actions: SWAP_EXACT_IN_SINGLE (0x06), SETTLE_ALL (0x0c), TAKE_ALL (0x0f).

    CRITICAL (Codex R2 on-chain verified): RH Chain Universal Router v2.1.1 ExactInputSingleParams
    includes minHopPriceX36 (uint256). Without it, the router bare-reverts on ABI decode.
    Struct: (PoolKey, bool zeroForOne, uint128 amountIn, uint128 amountOutMin, uint256 minHopPriceX36, bytes hookData)
    Returns (commands_bytes, inputs_list) for Universal Router execute()."""
    from eth_abi import encode

    # V4_SWAP command byte
    commands = bytes([0x10])

    # Action 0x06 = SWAP_EXACT_IN_SINGLE
    # ExactInputSingleParams = ((PoolKey), bool, uint128, uint128, uint256 minHopPriceX36, bytes hookData)
    # minHopPriceX36 = 0 means no price limit (accept any price)
    swap_action = encode(
        ['((address,address,uint24,int24,address),bool,uint128,uint128,uint256,bytes)'],
        [(pool_key, zero_for_one, amount_in, min_out, 0, b'')]
    )

    # Action 0x0c = SETTLE_ALL (settle the input currency)
    # Params: (address currency, uint256 maxAmount)
    input_currency = pool_key[0] if zero_for_one else pool_key[1]
    settle_action = encode(['address', 'uint256'], [input_currency, amount_in])

    # Action 0x0f = TAKE_ALL (take the output currency)
    # Params: (address currency, uint256 minAmount) — Codex Ultra: NOT (address, address)!
    output_currency = pool_key[1] if zero_for_one else pool_key[0]
    take_action = encode(['address', 'uint256'], [output_currency, min_out])

    # Combine actions: [SWAP_EXACT_IN_SINGLE, SETTLE_ALL, TAKE_ALL]
    actions = bytes([0x06, 0x0c, 0x0f])
    params_list = [swap_action, settle_action, take_action]

    # Encode the full V4_SWAP input: (bytes actions, bytes[] params)
    v4_input = encode(['bytes', 'bytes[]'], [actions, params_list])

    return commands, [v4_input]


def _parse_v4_route(route_str):
    """Parse V4 route string like 'v4eth_500_10' or 'v4spy_3000_60'.
    Returns (quote_addr, quote_sym, quote_dec, fee, tick_spacing)."""
    parts = route_str.split('_')
    quote_key = parts[0][2:]  # Remove 'v4' prefix → 'eth', 'spy', 'usdg', etc.
    fee = int(parts[1])
    tick_spacing = int(parts[2])

    if quote_key == 'eth':
        return WETH_ADDR, 'ETH', 18, fee, tick_spacing

    # Look up in QUOTE_TOKENS
    for qt_addr, (qt_sym, qt_dec) in QUOTE_TOKENS.items():
        if qt_sym.lower() == quote_key:
            return Web3.to_checksum_address(qt_addr), qt_sym, qt_dec, fee, tick_spacing

    # Fallback
    return WETH_ADDR, 'ETH', 18, fee, tick_spacing


def v4_buy(addr, amount, sym, market_price=0):
    """Buy token via V4 Universal Router + Permit2.
    Uses cached V4 pool data (exact PoolKey from Initialize event).
    amount = ETH amount (for ETH-quoted) or quote token amount (for SPY/USDG-quoted).
    Returns (tokens_received, entry_price_usd)."""
    al = addr.lower()
    route = TOKEN_ROUTE.get(al, '')
    if not route.startswith('v4'):
        logger.error('v4_buy called but route is %s', route)
        return 0, 0

    # Get resolved pool data (has exact PoolKey with correct on-chain addresses)
    pool_data = _v4_pool_cache.get(al)
    if not pool_data:
        logger.error('v4_buy: no cached pool data for %s', addr[:10])
        return 0, 0

    pool_key = pool_data['pool_key']
    quote_sym = pool_data['quote_sym']
    quote_dec = pool_data['quote_dec']
    quote_addr = pool_data['quote_addr']
    c0, c1 = pool_data['c0'], pool_data['c1']
    is_eth = (quote_sym == 'ETH')

    if is_eth:
        wei = Web3.to_wei(amount, 'ether')
        deploy_usd = amount * ETH_USD
    else:
        wei = int(amount * (10 ** quote_dec))
        if quote_sym == 'SPY':
            sb = spy_bal()
            sb_usd = spy_bal_usd()
            deploy_usd = amount / sb * sb_usd if sb > 0 else amount * 750
        elif quote_sym == 'USDG':
            deploy_usd = amount
        else:
            deploy_usd = amount * market_price if market_price > 0 else 0

    logger.info('V4 BUY %s with %.6f %s (~$%.2f) fee=%d tick=%d',
                sym, amount, quote_sym, deploy_usd, pool_data['fee'], pool_data['tick_spacing'])

    # Determine buy direction and token address
    qt_is_c0 = (quote_addr == c0.lower())
    buy_zero_for_one = qt_is_c0
    v4_token_addr = c1 if qt_is_c0 else c0
    try:
        d = w3.eth.contract(
            address=Web3.to_checksum_address(v4_token_addr), abi=E20
        ).functions.decimals().call()
    except Exception:
        d = 18

    try:
        quote_ca = Web3.to_checksum_address(quote_addr) if quote_addr else (c0 if qt_is_c0 else c1)

        if is_eth:
            # Wrap ETH → WETH
            wrap_tx = weth_c.functions.deposit().build_transaction(
                {'from': W, 'value': wei, 'nonce': w3.eth.get_transaction_count(W),
                 'gas': 60000, 'gasPrice': int(w3.eth.gas_price * 3), 'chainId': CID})
            s = acct.sign_transaction(wrap_tx)
            h = w3.eth.send_raw_transaction(s.raw_transaction)
            w3.eth.wait_for_transaction_receipt(h, timeout=60)
            _ensure_permit2_approval(WETH_ADDR, V4_UNIVERSAL_ROUTER, wei)
        else:
            _ensure_permit2_approval(quote_ca, V4_UNIVERSAL_ROUTER, wei)

        # Get real quote from V4 Quoter (includes pool fee + price impact)
        # This replaces the old DexScreener-based min_out which ignored pool fees
        # and caused reverts on high-fee pools (e.g. fee=99000 = 9.9%)
        try:
            quoted_out = int(v4_quoter.functions.quoteExactInputSingle(
                (pool_key, buy_zero_for_one, wei, b'')).call()[0])
        except Exception as qex:
            logger.error('V4 BUY %s: quoter failed (%s) — REJECTING (no unprotected buys)', sym, str(qex)[:60])
            return 0, 0
        if quoted_out <= 0:
            logger.error('V4 BUY %s: quote returned 0 — REJECTING', sym)
            return 0, 0
        slippage_bps = int(round(MAX_SLIPPAGE * 100))
        min_out = quoted_out * (10_000 - slippage_bps) // 10_000
        logger.info('  V4 quote: %.0f tokens; amountOutMin: %.0f (%.1f%% below quote)',
                    quoted_out / (10 ** d), min_out / (10 ** d), MAX_SLIPPAGE)

        commands, inputs = _encode_v4_swap(pool_key, buy_zero_for_one, wei, min_out)
        deadline = int(time.time()) + 300

        tx = v4_router.functions.execute(commands, inputs, deadline).build_transaction(
            {'from': W, 'value': 0, 'nonce': w3.eth.get_transaction_count(W),
             'gas': 500000, 'gasPrice': int(w3.eth.gas_price * 3), 'chainId': CID})
        s = acct.sign_transaction(tx)
        h = w3.eth.send_raw_transaction(s.raw_transaction)
        rc = w3.eth.wait_for_transaction_receipt(h, timeout=120)

        if rc['status'] == 1:
            # Check token balance using the V4 token address
            r, d = bal(v4_token_addr)
            tb = r / (10 ** d)
            if tb <= 0:
                # Try DexScreener address as fallback
                r, d = bal(addr)
                tb = r / (10 ** d)
            if tb <= 0:
                logger.error('V4 BUY %s: swap ok but 0 tokens — BLACKLIST', sym)
                if is_eth:
                    _unwrap_all_weth()
                PONS_BLACKLIST.add(al)
                _save_blacklist()
                return 0, 0
            logger.info('V4 BOUGHT %s: %s tokens', sym, f'{tb:,.0f}')
            # Finding 7: Pre-approve token for sell — wrap in try/except so failure
            # doesn't return (0,0) when we already own tokens. Sell will retry approval.
            try:
                _ensure_permit2_approval(v4_token_addr, V4_UNIVERSAL_ROUTER, r)
            except Exception as pex:
                logger.warning('V4 BUY %s: post-buy Permit2 approval failed: %s — sell will retry', sym, str(pex)[:60])
            entry_usd = deploy_usd / tb if tb > 0 else 0
            # Finding 6: Persist V4 cache after successful buy
            _save_v4_cache()
            return tb, entry_usd

        logger.error('V4 BUY %s REVERTED', sym)
        if is_eth:
            _unwrap_all_weth()
        return 0, 0

    except Exception as ex:
        logger.error('V4 BUY %s ERR: %s', sym, ex)
        if is_eth:
            _unwrap_all_weth()
        return 0, 0


def v4_sell(addr, sym, market_price=0):
    """Sell token via V4 Universal Router + Permit2.
    Uses cached V4 pool data with exact on-chain addresses."""
    al = addr.lower()
    route = TOKEN_ROUTE.get(al, '')
    if not route.startswith('v4'):
        logger.error('v4_sell called but route is %s', route)
        return 0.0

    pool_data = _v4_pool_cache.get(al)
    if not pool_data:
        logger.error('v4_sell: no cached pool data for %s', addr[:10])
        return 0.0

    pool_key = pool_data['pool_key']
    quote_sym = pool_data['quote_sym']
    quote_dec = pool_data['quote_dec']
    quote_addr = pool_data['quote_addr']
    c0, c1 = pool_data['c0'], pool_data['c1']
    is_eth = (quote_sym == 'ETH')

    # Token address in V4 pool (may differ from DexScreener)
    v4_token_addr = c1 if c0.lower() == quote_addr else c0

    r, d = bal(v4_token_addr)
    if r == 0:
        # Fallback: try DexScreener address
        r, d = bal(addr)
    if r == 0:
        return 0.0
    tokens_human = r / (10 ** d)
    logger.info('V4 SELL %s (%s tokens) fee=%d tick=%d → %s',
                sym, f'{tokens_human:,.0f}', pool_data['fee'], pool_data['tick_spacing'], quote_sym)

    # amountOutMin — 50% floor
    min_out = 0
    if market_price > 0 and tokens_human > 0:
        if is_eth:
            expected_out = (tokens_human * market_price) / ETH_USD
            min_eth = expected_out * 0.50
            min_out = Web3.to_wei(min_eth, 'ether')
            logger.info('  V4 SELL amountOutMin: %.6f WETH — 50%% floor', min_eth)
        else:
            token_value_usd = tokens_human * market_price
            if quote_sym == 'USDG':
                expected_quote = token_value_usd
            elif quote_sym == 'SPY':
                spy_price = spy_bal_usd() / spy_bal() if spy_bal() > 0 else 750
                expected_quote = token_value_usd / spy_price
            else:
                expected_quote = token_value_usd
            min_quote = expected_quote * 0.50
            min_out = int(min_quote * (10 ** quote_dec))
            logger.info('  V4 SELL amountOutMin: %.6f %s — 50%% floor', min_quote, quote_sym)

    try:
        _ensure_permit2_approval(v4_token_addr, V4_UNIVERSAL_ROUTER, r)

        # Sell direction: send token, receive quote
        qt_is_c0 = (quote_addr == c0.lower())
        sell_zero_for_one = not qt_is_c0  # If quote is c1, sell c0 to get c1

        # Try sell with 50% floor first, then emergency retry with min_out=0
        attempts = [(min_out, '50% floor'), (0, 'EMERGENCY min_out=0')]
        for attempt_min, attempt_label in attempts:
            # Re-check balance before each attempt (tokens may be gone)
            r_now, d_now = bal(v4_token_addr)
            if r_now == 0:
                r_now, d_now = bal(addr)
            if r_now == 0:
                logger.warning('V4 SELL %s: no tokens left in wallet — already sold?', sym)
                update_bal()
                return 0.0  # _do_sell will detect tokens gone via balance check

            commands, inputs = _encode_v4_swap(pool_key, sell_zero_for_one, r_now, attempt_min)
            deadline = int(time.time()) + 300

            tx = v4_router.functions.execute(commands, inputs, deadline).build_transaction(
                {'from': W, 'value': 0, 'nonce': w3.eth.get_transaction_count(W),
                 'gas': 500000, 'gasPrice': int(w3.eth.gas_price * 5), 'chainId': CID})
            s = acct.sign_transaction(tx)
            try:
                h = w3.eth.send_raw_transaction(s.raw_transaction)
                rc = w3.eth.wait_for_transaction_receipt(h, timeout=120)
            except Exception as tx_ex:
                logger.error('V4 SELL %s tx error (%s): %s', sym, attempt_label, tx_ex)
                continue  # Try next attempt

            if rc['status'] == 1:
                # Codex Ultra: verify tokens are actually gone (receipt success != full sell)
                r_after, d_after = bal(v4_token_addr)
                if r_after == 0:
                    r_after, d_after = bal(addr)
                tokens_remaining = r_after / (10 ** d_after) if d_after > 0 else r_after
                if tokens_remaining > 100:
                    logger.warning('V4 SELL %s: tx succeeded but %.0f tokens STILL IN WALLET — partial fill, retrying',
                                   sym, tokens_remaining)
                    continue  # Try next attempt with remaining tokens

                if is_eth:
                    _unwrap_all_weth()
                    e = eth_bal()
                    logger.info('V4 SOLD %s → %.6f ETH ($%.2f) [%s]', sym, e, e * ETH_USD, attempt_label)
                    update_bal()
                    return e
                elif quote_sym == 'SPY':
                    new_spy = spy_bal()
                    spy_usd = spy_bal_usd()
                    eth_equiv = spy_usd / ETH_USD if ETH_USD > 0 else 0
                    logger.info('V4 SOLD %s → %.6f SPY (~$%.2f) [%s]', sym, new_spy, spy_usd, attempt_label)
                    update_bal()
                    return eth_equiv
                else:
                    qt_ca = Web3.to_checksum_address(quote_addr) if quote_addr else c0
                    qt_c = w3.eth.contract(address=qt_ca, abi=E20)
                    qt_bal = qt_c.functions.balanceOf(W).call() / (10 ** quote_dec)
                    qt_usd = qt_bal if quote_sym == 'USDG' else qt_bal
                    eth_equiv = qt_usd / ETH_USD if ETH_USD > 0 else 0
                    logger.info('V4 SOLD %s → %.6f %s (~$%.2f) [%s]', sym, qt_bal, quote_sym, qt_usd, attempt_label)
                    update_bal()
                    return eth_equiv

            logger.error('V4 SELL %s REVERTED (%s) — %s',
                         sym, attempt_label,
                         'retrying with min_out=0' if attempt_min > 0 else 'BOTH ATTEMPTS FAILED')

        return 0.0

    except Exception as ex:
        logger.error('V4 SELL %s ERR: %s', sym, ex)
        return 0.0


def scan():
    """Find coin that is ACTIVELY PUMPING right now. Optimized for speed.

    Speed optimizations vs v4.0:
    1. Single DexScreener call for ALL RH chain pairs (not profiles+boosts+batch)
    2. Cache pair quote-token data from scan (v3_ok skips re-fetch)
    3. Cache V3 failures for 5min (skip re-testing known-bad tokens)
    4. Batch size 30 (DexScreener limit) instead of 5
    5. No sleep between batches (DexScreener allows burst)
    6. Already-routed tokens skip pons_ok/v3_ok entirely
    """
    now = time.time()
    addrs = set()

    # Fetch profiles + boosts in parallel-ish (still sequential but no sleep)
    profiles = fetch('https://api.dexscreener.com/token-profiles/latest/v1')
    if profiles:
        for t in profiles:
            if t.get('chainId') == 'robinhood':
                addrs.add(t['tokenAddress'])
    boosted = fetch('https://api.dexscreener.com/token-boosts/latest/v1')
    if boosted:
        for t in boosted:
            if t.get('chainId') == 'robinhood':
                addrs.add(t['tokenAddress'])
    if not addrs: return None
    addrs = list(addrs)

    cands = []
    # Batch 30 at a time (DexScreener max), NO sleep between batches
    for i in range(0, len(addrs), 30):
        batch = addrs[i:i+30]
        d = fetch(f"https://api.dexscreener.com/latest/dex/tokens/{','.join(batch)}")
        if not d: continue
        for p in (d.get('pairs') or []):
            if p.get('chainId') != 'robinhood': continue
            a = p.get('baseToken', {}).get('address', '')
            liq = float(p.get('liquidity', {}).get('usd', 0))
            c5 = p.get('priceChange', {}).get('m5', 0) or 0
            c1h = p.get('priceChange', {}).get('h1', 0) or 0
            b5 = p.get('txns', {}).get('m5', {}).get('buys', 0)
            s5 = p.get('txns', {}).get('m5', {}).get('sells', 0)
            sym = p.get('baseToken', {}).get('symbol', '?')

            # Cache pair quote-token info for v3_ok + v4_ok (avoids re-fetch)
            # Finding 3: Don't overwrite V4 (66-char) pair with non-V4 pair
            qt = p.get('quoteToken', {})
            new_pair = {
                'quote_sym': (qt.get('symbol') or '').upper(),
                'quote_addr': (qt.get('address') or '').lower(),
                'pair_addr': p.get('pairAddress', ''),  # V4 pools: 66-char pool ID
                'ts': now,
            }
            existing = _pair_data_cache.get(a.lower())
            if existing and len(existing.get('pair_addr', '')) == 66 and len(new_pair['pair_addr']) != 66:
                pass  # Keep existing V4 pool entry — don't overwrite with non-V4
            else:
                _pair_data_cache[a.lower()] = new_pair

            # Filter: ONLY mid-pump coins with buyers in control
            if liq < MIN_LIQ: continue
            if c5 < MIN_5M_ENTRY: continue
            if c5 > MAX_5M_ENTRY:
                logger.info('SKIP %s — pump already ripped too hard (5m=%+.1f%% > +%.0f%% cap)', sym, c5, MAX_5M_ENTRY)
                continue
            if c1h < MIN_1H_ENTRY: continue
            ratio = b5 / max(s5, 1)
            if ratio < MIN_BS_ENTRY: continue

            score = c5 * 0.5 + min(b5, 50) * 0.3 + min(liq/10000, 5)
            cands.append({'sym': sym, 'addr': a, 'c5': c5, 'c1h': c1h,
                          'b': b5, 's': s5, 'liq': liq, 'score': score})

    cands.sort(key=lambda x: -x['score'])
    logger.info('Pumping candidates: %d', len(cands))

    # Remove blacklisted tokens
    cands = [c for c in cands if c['addr'].lower() not in PONS_BLACKLIST]

    # Prioritize: whitelisted > already-routed > unknown
    wl = [c for c in cands if c['addr'].lower() in PONS_WHITELIST]
    routed = [c for c in cands if c['addr'].lower() not in PONS_WHITELIST and c['addr'].lower() in TOKEN_ROUTE]
    rest = [c for c in cands if c['addr'].lower() not in PONS_WHITELIST and c['addr'].lower() not in TOKEN_ROUTE]

    # Whitelisted = instant pick (no validation needed)
    for c in wl:
        logger.info('PICK (WL): %s 5m=%+.1f%% B/S=%d/%d liq=$%s',
                     c['sym'], c['c5'], c['b'], c['s'], f"{c['liq']:,.0f}")
        return c

    # Already-routed V3 tokens = instant pick (validated before)
    for c in routed:
        logger.info('PICK (cached): %s 5m=%+.1f%% route=%s', c['sym'], c['c5'], TOKEN_ROUTE[c['addr'].lower()])
        return c

    # Unknown tokens = need validation (skip recently-failed)
    for c in rest[:5]:
        al = c['addr'].lower()
        # Skip tokens that failed V3 validation recently
        if al in _v3_fail_cache and (now - _v3_fail_cache[al]) < V3_FAIL_TTL:
            continue
        logger.info('Testing %s 5m=%+.1f%%...', c['sym'], c['c5'])
        if pons_ok(c['addr']):
            PONS_WHITELIST.add(al)
            TOKEN_ROUTE[al] = 'pons'
            logger.info('PICK (new/pons): %s', c['sym'])
            return c
        if v3_ok(c['addr']):
            logger.info('PICK (new/v3): %s fee=%s', c['sym'], TOKEN_ROUTE.get(al))
            return c
        if v4_ok(c['addr']):
            logger.info('PICK (new/v4): %s route=%s', c['sym'], TOKEN_ROUTE.get(al))
            return c
        _v3_fail_cache[al] = now  # Cache failure — don't re-test for 5 min
        logger.info('  %s: not compatible (pons, v3, or v4)', c['sym'])
    return None


def verify_momentum(addr, sym, initial_c5):
    """Take 3 momentum readings over ~6s. Only approve if momentum is STABLE or RISING."""
    readings = [initial_c5]
    logger.info('⏱ PRE-ENTRY: Studying %s momentum... (3 readings, 6s)', sym)
    for i in range(2):
        time.sleep(3)
        info = price(addr)
        if not info or info['p'] <= 0:
            logger.warning('  Reading %d: price unavailable — ABORT', i+2)
            return False, readings
        c5 = info['c5']
        b5 = info['b5']
        s5 = info['s5']
        bs = b5 / max(s5, 1)
        readings.append(c5)
        logger.info('  Reading %d: 5m=%+.1f%% B/S=%d/%d (%.2f)', i+2, c5, b5, s5, bs)

        # If momentum already died during observation, abort
        if c5 < MOMENTUM_DEATH:
            logger.warning('  Momentum DIED during observation (%+.1f%%) — ABORT', c5)
            return False, readings

        # If momentum spiked too high during observation, abort (buying the top)
        if c5 > MAX_5M_ENTRY:
            logger.warning('  Momentum SPIKED too high during observation (%+.1f%% > +%.0f%%) — ABORT (buying the top)', c5, MAX_5M_ENTRY)
            return False, readings

        # If B/S flipped to sellers during observation, abort
        if bs < 0.7:
            logger.warning('  Sellers took over during observation (B/S=%.2f) — ABORT', bs)
            return False, readings

    # Check trend: momentum should NOT be declining steeply
    # Allow small dips (within 30%) but reject clear deceleration
    if len(readings) == 3:
        # If all 3 readings are declining, momentum is fading
        if readings[2] < readings[1] < readings[0]:
            drop_pct = (readings[0] - readings[2]) / max(abs(readings[0]), 1) * 100
            if drop_pct > 30:
                logger.warning('  Momentum DECLINING: %.1f→%.1f→%.1f (-%d%%) — ABORT',
                              readings[0], readings[1], readings[2], drop_pct)
                return False, readings
            else:
                logger.info('  Momentum dipping slightly: %.1f→%.1f→%.1f — OK (<%d%% drop)',
                           readings[0], readings[1], readings[2], drop_pct)

        # If latest reading dropped below entry threshold, don't enter
        if readings[-1] < MIN_5M_ENTRY:
            logger.warning('  Latest reading %+.1f%% below entry threshold %+.1f%% — ABORT',
                          readings[-1], MIN_5M_ENTRY)
            return False, readings

    logger.info('  ✅ Momentum VERIFIED: %.1f→%.1f→%.1f — ENTERING', readings[0], readings[1], readings[2])
    return True, readings


MAX_SLIPPAGE = 2.0  # Maximum acceptable slippage % — reject if fill > 2% worse than market
EXIT_COOLDOWN = {}  # addr -> timestamp of last exit (10 min cooldown on LOSERS only)
EXIT_COOLDOWN_SEC = 60   # 60s — short cooldown on losers. Shaheer directive: if momentum is verified, re-enter (Sep 7)

# ── Session-level loss & retry protection (Sep 7 patch) ──
BUY_FAIL_COUNT = {}      # addr -> int — consecutive reverted buy attempts this session
MAX_BUY_RETRIES = 2      # Max reverted buys before session-blacklisting a token
SESSION_LOSSES = {}      # addr -> int — count of losing exits per token this session
MAX_SESSION_LOSSES = 2   # 2 losing exits on same token → session-blacklist it


# ═══════════════════════════════════════════════════════════
# FAST PRICE MONITOR — sub-second exit detection via eth_getLogs
# Runs in a background daemon thread, polls swap events at ~400ms
# Falls back silently to DexScreener-only if pool discovery or RPC fails
# ═══════════════════════════════════════════════════════════

def _discover_pool(token_addr):
    """Find the V3 pool address for a token/WETH pair.
    Strategy 1: V3 factory lookup (works for V3 tokens).
    Strategy 2: Scan recent blocks for Swap events involving this token (works for Pons tokens too).
    Returns (pool_addr, weth_is_token0, token_decimals) or None."""
    ca = Web3.to_checksum_address(token_addr)
    weth = Web3.to_checksum_address(WETH_ADDR)

    # Strategy 1: V3 Factory lookup
    try:
        factory = w3.eth.contract(address=Web3.to_checksum_address(V3_FACTORY_RH), abi=FACTORY_ABI)
        for fee in V3_FEES:
            try:
                pool_addr = factory.functions.getPool(weth, ca, fee).call()
                if pool_addr and pool_addr != Z:
                    pool_c = w3.eth.contract(address=Web3.to_checksum_address(pool_addr), abi=POOL_SLOT0_ABI)
                    t0 = pool_c.functions.token0().call().lower()
                    weth_is_t0 = (t0 == weth.lower())
                    tc = w3.eth.contract(address=ca, abi=E20)
                    decimals = tc.functions.decimals().call()
                    logger.info('⚡ POOL FOUND (factory): %s fee=%d weth_t0=%s dec=%d',
                                pool_addr[:10], fee, weth_is_t0, decimals)
                    return (pool_addr, weth_is_t0, decimals)
            except Exception:
                continue
    except Exception:
        pass

    # Strategy 2: Scan recent blocks for Swap events, then check which pools contain our token
    try:
        topic = '0x' + Web3.keccak(text='Swap(address,address,int256,int256,uint160,uint128,int24)').hex()
        current = w3.eth.block_number
        # Scan last 500 blocks (~40 seconds of blocks) for any swap events
        logs = w3.eth.get_logs({
            'fromBlock': max(0, current - 500),
            'toBlock': 'latest',
            'topics': [topic],
        })
        # Check each unique pool to see if it pairs our token with WETH
        # 30-second hard cutoff to prevent engine from hanging during position monitoring
        checked_pools = set()
        scan_start = time.time()
        POOL_SCAN_TIMEOUT = 30
        for log in logs:
            if time.time() - scan_start > POOL_SCAN_TIMEOUT:
                logger.warning('⚡ POOL SCAN TIMEOUT after %ds (checked %d pools) — DexScreener-only',
                               POOL_SCAN_TIMEOUT, len(checked_pools))
                return None
            pool_addr = log['address']
            if pool_addr in checked_pools:
                continue
            checked_pools.add(pool_addr)
            try:
                pool_c = w3.eth.contract(address=Web3.to_checksum_address(pool_addr), abi=POOL_SLOT0_ABI)
                t0 = pool_c.functions.token0().call()
                t1 = pool_c.functions.token1().call()
                # Check if this pool pairs our token with WETH
                if t0.lower() == ca.lower() and t1.lower() == weth.lower():
                    tc = w3.eth.contract(address=ca, abi=E20)
                    decimals = tc.functions.decimals().call()
                    logger.info('⚡ POOL FOUND (scan): %s weth_t0=False dec=%d', pool_addr[:10], decimals)
                    return (pool_addr, False, decimals)
                elif t1.lower() == ca.lower() and t0.lower() == weth.lower():
                    tc = w3.eth.contract(address=ca, abi=E20)
                    decimals = tc.functions.decimals().call()
                    logger.info('⚡ POOL FOUND (scan): %s weth_t0=True dec=%d', pool_addr[:10], decimals)
                    return (pool_addr, True, decimals)
            except Exception:
                continue

        logger.info('⚡ POOL NOT FOUND for %s (checked %d pools) — DexScreener-only', token_addr[:10], len(checked_pools))
        return None
    except Exception as ex:
        logger.warning('⚡ Pool discovery failed: %s', ex)
        return None


def _price_from_sqrt(sqrt_price_x96, weth_is_token0, token_decimals):
    """Calculate token USD price from sqrtPriceX96.
    V3 formula: raw = (sqrtPriceX96 / 2^96)^2 = token1_base / token0_base.
    Returns price per token in USD."""
    if sqrt_price_x96 == 0:
        return 0.0
    raw = (sqrt_price_x96 / (2 ** 96)) ** 2
    if weth_is_token0:
        # token0=WETH(18dec), token1=TOKEN(Xdec)
        # raw = TOKEN_base / WETH_base
        # tokens_per_weth_human = raw * 10^(18 - token_decimals)
        # weth_per_token = 1 / tokens_per_weth_human
        tokens_per_weth = raw * (10 ** (18 - token_decimals))
        if tokens_per_weth == 0:
            return 0.0
        return (1.0 / tokens_per_weth) * ETH_USD
    else:
        # token0=TOKEN(Xdec), token1=WETH(18dec)
        # raw = WETH_base / TOKEN_base
        # weth_per_token_human = raw * 10^(token_decimals - 18)
        weth_per_token = raw * (10 ** (token_decimals - 18))
        return weth_per_token * ETH_USD


class PriceMonitor:
    """Background thread that polls eth_getLogs for swap events at ~400ms intervals.
    Detects price crashes faster than DexScreener polling (2s → 400ms).
    Falls back silently if RPC fails — main loop DexScreener polling continues regardless."""

    def __init__(self):
        self._w3 = Web3(Web3.HTTPProvider(RPC, request_kwargs={
            'headers': {'User-Agent': 'fast-monitor', 'Content-Type': 'application/json'},
            'timeout': 5  # Short timeout for fast polling
        }))
        self._thread = None
        self._stop = threading.Event()
        self._lock = threading.Lock()
        self._pool_addr = None
        self._weth_is_token0 = True
        self._token_decimals = 18
        self._latest_price = 0.0
        self._entry_price = 0.0
        self._peak_price = 0.0
        self._sell_signal = threading.Event()
        self._sell_reason = ''
        self._last_block = 0
        self._consecutive_errors = 0
        self._active = False

    def start(self, token_addr, entry_price, pool_info):
        """Start monitoring. pool_info = (pool_addr, weth_is_token0, token_decimals)."""
        self.stop()  # Clean up any previous run
        self._pool_addr = pool_info[0]
        self._weth_is_token0 = pool_info[1]
        self._token_decimals = pool_info[2]
        self._entry_price = entry_price
        self._peak_price = entry_price
        self._latest_price = entry_price
        self._sell_signal.clear()
        self._sell_reason = ''
        self._stop.clear()
        self._consecutive_errors = 0
        self._active = True
        try:
            self._last_block = self._w3.eth.block_number
        except Exception:
            self._last_block = 0
        self._thread = threading.Thread(target=self._poll_loop, daemon=True, name='fast-price')
        self._thread.start()
        logger.info('⚡ FAST MONITOR started (pool=%s, entry=$%.8f, poll=%.0fms)',
                     self._pool_addr[:10], entry_price, FAST_POLL_SEC * 1000)

    def stop(self):
        """Stop the monitoring thread."""
        if self._thread and self._thread.is_alive():
            self._stop.set()
            self._thread.join(timeout=2)
            logger.info('⚡ FAST MONITOR stopped')
        self._active = False
        self._thread = None

    def is_active(self):
        """Check if monitor thread is running."""
        return self._active and self._thread is not None and self._thread.is_alive()

    def get_price(self):
        """Thread-safe read of latest price."""
        with self._lock:
            return self._latest_price

    def should_sell(self):
        """Thread-safe check of sell signal. Returns (triggered: bool, reason: str)."""
        if self._sell_signal.is_set():
            return True, self._sell_reason
        return False, ''

    def clear_sell_signal(self):
        """Reset sell signal after a failed sell attempt."""
        self._sell_signal.clear()
        self._sell_reason = ''

    def _poll_loop(self):
        """Background polling loop. Runs every ~400ms checking for swap events."""
        pool_cs = Web3.to_checksum_address(self._pool_addr)
        topic = '0x' + self._w3.keccak(text='Swap(address,address,int256,int256,uint160,uint128,int24)').hex()

        while not self._stop.is_set():
            try:
                current_block = self._w3.eth.block_number
                from_block = max(self._last_block + 1, current_block - MONITOR_BLOCK_RANGE)

                if from_block > current_block:
                    time.sleep(FAST_POLL_SEC)
                    continue

                # Fetch swap events from the pool
                logs = self._w3.eth.get_logs({
                    'fromBlock': from_block,
                    'toBlock': current_block,
                    'address': pool_cs,
                    'topics': [topic],
                })

                self._last_block = current_block
                self._consecutive_errors = 0  # Reset on success

                if not logs:
                    time.sleep(FAST_POLL_SEC)
                    continue

                # Process the LATEST swap event (most recent price)
                latest_log = logs[-1]
                data = latest_log['data']
                if isinstance(data, str):
                    data = bytes.fromhex(data[2:] if data.startswith('0x') else data)

                # Swap event data layout:
                # [0:32]   int256 amount0
                # [32:64]  int256 amount1
                # [64:96]  uint160 sqrtPriceX96
                # [96:128] uint128 liquidity
                # [128:160] int24 tick
                if len(data) >= 96:
                    sqrt_price = int.from_bytes(data[64:96], 'big')
                    new_price = _price_from_sqrt(sqrt_price, self._weth_is_token0, self._token_decimals)

                    if new_price > 0:
                        with self._lock:
                            self._latest_price = new_price
                            if new_price > self._peak_price:
                                self._peak_price = new_price

                        # Check fast exit conditions
                        pnl = (new_price - self._entry_price) / self._entry_price * 100
                        peak_drop = (self._peak_price - new_price) / self._peak_price * 100 if self._peak_price > 0 else 0

                        if pnl <= FAST_SL_THRESHOLD and not self._sell_signal.is_set():
                            self._sell_reason = f'⚡ FAST SL {pnl:+.1f}% (${new_price:.8f})'
                            self._sell_signal.set()
                            logger.warning('⚡ FAST SL TRIGGERED: %s', self._sell_reason)

                        elif peak_drop >= FAST_PEAK_DROP and not self._sell_signal.is_set():
                            self._sell_reason = f'⚡ FAST PEAK DROP -{peak_drop:.1f}% from peak (${new_price:.8f})'
                            self._sell_signal.set()
                            logger.warning('⚡ FAST PEAK DROP TRIGGERED: %s', self._sell_reason)

            except Exception as ex:
                self._consecutive_errors += 1
                if self._consecutive_errors >= 5:
                    logger.warning('⚡ FAST MONITOR: 5 consecutive errors, falling back to DexScreener-only: %s', ex)
                    self._active = False
                    return  # Thread exits, main loop continues with DexScreener
                elif self._consecutive_errors == 1:
                    logger.debug('⚡ FAST MONITOR poll error: %s', ex)

            time.sleep(FAST_POLL_SEC)


# Global monitor instance
price_monitor = PriceMonitor()


def _pons_sim(ca, wei_amount):
    """Simulate a Pons swap.
    The Pons swap contract returns EMPTY bytes from eth_call, so we CANNOT
    extract the actual token output amount.  Always returns 0 so that callers
    (like check_slippage) fall through to the liquidity-based estimation,
    which is the only reliable slippage check for Pons tokens.
    DO NOT return gas estimates here — callers interpret the return value
    as token count, and gas values produce fabricated 97%+ slippage."""
    return 0


def check_slippage(addr, eth_amt, sym, market_price, liquidity=0):
    """Check if our position size will cause excessive slippage.
    V3: simulate swap with eth_call for exact fill price.
    Pons: TWO-AMOUNT comparison — tiny vs full swap to detect price impact.
    Returns (ok, slippage_pct). Takes ~600ms for Pons, ~300ms for V3."""
    if market_price <= 0:
        return True, 0.0
    route = TOKEN_ROUTE.get(addr.lower(), 'pons')
    wei = Web3.to_wei(eth_amt, 'ether')
    ca = Web3.to_checksum_address(addr)
    deploy_usd = eth_amt * ETH_USD

    try:
        if route.startswith('v4'):
            # V4: use V4 Quoter for exact fill price
            pool_data = _v4_pool_cache.get(addr.lower())
            if not pool_data:
                logger.info('  SLIPPAGE CHECK (V4): no pool data — use liq-based fallback')
                if liquidity >= 10000:
                    est_slip = deploy_usd / liquidity * 1000
                    return est_slip <= MAX_SLIPPAGE, est_slip
                return False, 100.0

            pool_key = pool_data['pool_key']
            quote_dec = pool_data['quote_dec']
            c0 = pool_data['c0']
            qt_is_c0 = (pool_data['quote_addr'] == c0.lower())
            buy_zfo = qt_is_c0

            test_amt = int(eth_amt * (10 ** quote_dec)) if pool_data['quote_sym'] != 'ETH' else wei
            tokens_out_raw = 0
            v4_reduced_amt = test_amt  # Track if we had to reduce the trade size
            try:
                result = v4_quoter.functions.quoteExactInputSingle(
                    (pool_key, buy_zfo, test_amt, b'')).call()
                tokens_out_raw = result[0]
            except Exception as v4_ex:
                # Quoter reverts when swap exhausts pool liquidity in active tick
                # range (error 0x6190b2b0).  Try progressively smaller amounts
                # before giving up — the pool may still be tradeable at a lower size.
                logger.info('  SLIPPAGE CHECK (V4): quoter reverted on full amount (%s) — trying smaller sizes',
                            str(v4_ex)[:60])
                for fraction in [0.5, 0.25, 0.1]:
                    reduced = int(test_amt * fraction)
                    if reduced <= 0:
                        break
                    try:
                        result = v4_quoter.functions.quoteExactInputSingle(
                            (pool_key, buy_zfo, reduced, b'')).call()
                        if result[0] > 0:
                            tokens_out_raw = result[0]
                            v4_reduced_amt = reduced
                            # Scale tokens proportionally to estimate full-amount output
                            # (conservative: real slippage at full size would be worse)
                            tokens_out_raw = int(tokens_out_raw * (test_amt / reduced))
                            logger.info('  SLIPPAGE CHECK (V4): quoter OK at %.0f%% size (%d) — extrapolating',
                                        fraction * 100, reduced)
                            break
                    except Exception:
                        continue

            if tokens_out_raw <= 0:
                # All quoter attempts failed — fall back to liquidity-based estimation
                if liquidity >= 10000:
                    est_slip = deploy_usd / liquidity * 1000
                    logger.info('  SLIPPAGE CHECK (V4): quoter failed, liq-based fallback: %.1f%%', est_slip)
                    return est_slip <= MAX_SLIPPAGE, est_slip
                logger.warning('  SLIPPAGE CHECK (V4): quoter returned 0, no liq fallback — REJECT')
                return False, 100.0

            v4_token = pool_data['c1'] if qt_is_c0 else pool_data['c0']
            try:
                tc = w3.eth.contract(address=Web3.to_checksum_address(v4_token), abi=E20)
                d = tc.functions.decimals().call()
            except Exception:
                d = 18
            tokens_out = tokens_out_raw / (10 ** d)
            fill_price = deploy_usd / tokens_out if tokens_out > 0 else 0
            slippage = (fill_price - market_price) / market_price * 100 if market_price > 0 else 0
            logger.info('  SLIPPAGE CHECK (V4): fill=$%.8f vs market=$%.8f = %+.1f%%',
                        fill_price, market_price, slippage)
            if slippage > MAX_SLIPPAGE:
                logger.warning('  SLIPPAGE %.1f%% > %.1f%% MAX — REJECT %s', slippage, MAX_SLIPPAGE, sym)
                return False, slippage
            return True, slippage

        elif route.startswith('v3'):
            # V3: exact simulation — eth_call returns token output amount
            fee = int(route.split('_')[1])
            weth = Web3.to_checksum_address(WETH_ADDR)
            # SwapRouter02: no deadline in params tuple
            params = (weth, ca, fee, W, wei, 0, 0)
            tx = v3r.functions.exactInputSingle(params).build_transaction(
                {'from': W, 'value': wei, 'nonce': w3.eth.get_transaction_count(W),
                 'gas': 500000, 'gasPrice': int(w3.eth.gas_price*2), 'chainId': CID})
            result = w3.eth.call(tx)
            tokens_out_raw = int.from_bytes(result[:32], 'big') if len(result) >= 32 else 0

            if tokens_out_raw <= 0:
                logger.warning('  SLIPPAGE CHECK (V3): simulation returned 0 tokens — REJECT')
                return False, 100.0

            _, d = bal(addr)
            if d == 0:
                d = 18
            tokens_out = tokens_out_raw / (10 ** d)
            fill_price = deploy_usd / tokens_out
            slippage = (fill_price - market_price) / market_price * 100

            logger.info('  SLIPPAGE CHECK (V3): fill=$%.8f vs market=$%.8f = %+.1f%%',
                        fill_price, market_price, slippage)

            if slippage > MAX_SLIPPAGE:
                logger.warning('  SLIPPAGE %.1f%% > %.1f%% MAX — REJECT %s', slippage, MAX_SLIPPAGE, sym)
                return False, slippage
            return True, slippage

        else:
            # Pons: TWO-AMOUNT simulation — compare tiny vs full swap
            # Tiny swap (0.001 ETH) = minimal slippage = "fair price"
            # Full swap (actual amount) = real price we'd pay
            # If full gives us significantly fewer tokens per ETH, that's slippage
            tiny_wei = Web3.to_wei(0.001, 'ether')
            tiny_out = _pons_sim(ca, tiny_wei)
            full_out = _pons_sim(ca, wei)

            if tiny_out <= 0 or full_out <= 0:
                # Pons eth_call returns 0x since contract upgrade — use liquidity-based estimation
                # BELL trade proved DexScreener liq is inflated vs actual pool depth
                # 10× safety multiplier + position cap (0.15% of pool) prevents BELL-type disasters
                # BELL: reported $122K liq, 12.8% round-trip slip on $277 (was 0.23% of pool)
                if liquidity >= 10000:
                    est_slip = deploy_usd / liquidity * 1000  # 10× safety multiplier
                    logger.info('  SLIPPAGE FALLBACK (liq-based, 10x safety): $%.0f into $%.0f liq → est %.1f%%',
                                deploy_usd, liquidity, est_slip)
                    if est_slip > MAX_SLIPPAGE:
                        logger.warning('  SLIPPAGE est %.1f%% > %.1f%% MAX — REJECT %s',
                                       est_slip, MAX_SLIPPAGE, sym)
                        return False, est_slip
                    logger.info('  SLIPPAGE est %.1f%% OK — proceeding (post-buy -12%% safety active)',
                                est_slip)
                    return True, est_slip
                else:
                    logger.warning('  SLIPPAGE CHECK (Pons): sim=0 + low liq ($%.0f) — REJECT %s',
                                   liquidity, sym)
                    return False, 100.0

            # Price per ETH: tokens_out / eth_in
            tiny_rate = tiny_out / 0.001  # tokens per ETH at zero slippage
            full_rate = full_out / eth_amt  # tokens per ETH at our size
            slippage = (1 - full_rate / tiny_rate) * 100

            logger.info('  SLIPPAGE CHECK (Pons): tiny=%.0f/ETH full=%.0f/ETH slip=%+.1f%%',
                        tiny_rate, full_rate, slippage)

            if slippage > MAX_SLIPPAGE:
                logger.warning('  SLIPPAGE %.1f%% > %.1f%% MAX — REJECT %s', slippage, MAX_SLIPPAGE, sym)
                return False, slippage
            return True, slippage

    except Exception as ex:
        logger.warning('  SLIPPAGE CHECK ERR: %s — REJECT (fail-safe)', ex)
        return False, 100.0  # CHANGED: fail-safe = reject on error, not proceed


def enter():
    """Enter a pumping coin — with pre-entry momentum verification + slippage check."""
    c = scan()
    if not c: return None

    # ═══ COOLDOWN CHECK — don't re-enter same token within 10 min of exit ═══
    al = c['addr'].lower()
    if al in EXIT_COOLDOWN:
        elapsed = time.time() - EXIT_COOLDOWN[al]
        if elapsed < EXIT_COOLDOWN_SEC:
            remaining = int(EXIT_COOLDOWN_SEC - elapsed)
            logger.info('SKIP %s — cooldown (%ds remaining)', c['sym'], remaining)
            return None

    # ═══ SESSION LOSS BLACKLIST — 2 losing exits = stop trading this token ═══
    if SESSION_LOSSES.get(al, 0) >= MAX_SESSION_LOSSES:
        logger.info('SKIP %s — session-blacklisted (%d losing exits)', c['sym'], SESSION_LOSSES[al])
        return None

    # ═══ BUY RETRY LIMIT — max 2 reverted buys before giving up ═══
    if BUY_FAIL_COUNT.get(al, 0) >= MAX_BUY_RETRIES:
        logger.info('SKIP %s — buy reverted %d times, session-blocked', c['sym'], BUY_FAIL_COUNT[al])
        return None

    # ═══ PRE-ENTRY MOMENTUM VERIFICATION (3 readings, 6s, no extra delay) ═══
    # Codex Ultra analysis: restore verification but zero additional delay.
    # 3 readings at 0/3/6s confirm trend + B/S. No confirmation sleep after.
    ok, readings = verify_momentum(c['addr'], c['sym'], c['c5'])
    if not ok:
        logger.info('SKIP %s — momentum not verified', c['sym'])
        return None
    logger.info('⚡ VERIFIED ENTRY: %s 5m=%+.1f%% B/S=%.2f — entering now',
                c['sym'], readings[-1], c['b']/max(c['s'],1))

    route = TOKEN_ROUTE.get(c['addr'].lower(), 'pons')
    is_spy_route = route.startswith('v3spy') or route.startswith('v4spy')
    is_v4_other = route.startswith('v4') and not route.startswith('v4eth') and not route.startswith('v4spy')

    # ═══ PRE-BUY POOL DISCOVERY — find monitor pool BEFORE buying ═══
    # Codex Ultra fix: pool discovery was blocking for 30s AFTER buy,
    # causing SL overshoots (-35% on -3% SL). Now we discover first.
    pre_pool_info = _discover_pool(c['addr'])
    if pre_pool_info:
        logger.info('PRE-BUY: Pool found for %s — fast monitor ready', c['sym'])
    else:
        logger.info('PRE-BUY: No pool for %s — DexScreener-only mode', c['sym'])

    # ═══ BALANCE CHECK — use SPY balance for SPY-paired, ETH for everything else ═══
    if is_v4_other:
        # V4 with non-ETH/SPY quote (USDG, HIMS, NVDA) — check that quote balance
        v4_qa, v4_qs, v4_qd, _, _ = _parse_v4_route(route)
        qt_ca = Web3.to_checksum_address(v4_qa)
        qt_c = w3.eth.contract(address=qt_ca, abi=E20)
        qt_raw = qt_c.functions.balanceOf(W).call()
        qt_human = qt_raw / (10 ** v4_qd)
        deploy_usd_est = qt_human  # Rough: most quote tokens ≈ $1 (USDG) or need price oracle
        if qt_human < 1:
            logger.error('Not enough %s for V4: %.6f', v4_qs, qt_human)
            return None
        deploy = 0  # Not used for V4 other routes
        deploy_spy = 0
    elif is_spy_route:
        sb = spy_bal()
        sb_usd = spy_bal_usd()
        deploy_usd = sb_usd - 5.0  # Keep $5 SPY reserve
        if deploy_usd < 10:
            logger.error('Not enough SPY: %.6f (~$%.2f)', sb, sb_usd)
            return None
        deploy_spy = sb - (5.0 / (sb_usd / sb) if sb > 0 else 0)  # SPY amount to deploy
    else:
        e = eth_bal()
        deploy = e - GAS_RESERVE
        if deploy < 0.002:
            logger.error('Not enough ETH: %.6f', e)
            return None

    # ═══ POSITION SIZING — cap at 0.15% of pool liquidity ═══
    info = price(c['addr'])
    mkt_price = info['p'] if info else 0
    liq = info.get('liq', 0) if info else 0
    if liq > 0:
        max_deploy_usd = liq * 0.0015  # 0.15% of pool liquidity
        if is_v4_other:
            # Finding 4: V4 "other" routes use deploy_usd_est, not deploy (which is 0)
            if deploy_usd_est > max_deploy_usd:
                logger.info('POSITION CAP (V4 %s): $%.0f → $%.0f (0.15%% of $%.0f liq)',
                             v4_qs, deploy_usd_est, max_deploy_usd, liq)
                # Scale down qt_human proportionally
                qt_human = qt_human * (max_deploy_usd / deploy_usd_est)
                deploy_usd_est = max_deploy_usd
            if deploy_usd_est < 20:
                logger.info('SKIP %s — capped position too small ($%.1f < $20)', c['sym'], deploy_usd_est)
                return None
        elif is_spy_route:
            if deploy_usd > max_deploy_usd:
                logger.info('POSITION CAP (SPY): $%.0f → $%.0f (0.15%% of $%.0f liq)',
                             deploy_usd, max_deploy_usd, liq)
                deploy_spy = deploy_spy * (max_deploy_usd / deploy_usd)
                deploy_usd = max_deploy_usd
            if deploy_usd < 20:
                logger.info('SKIP %s — capped position too small ($%.1f < $20)', c['sym'], deploy_usd)
                return None
        else:
            max_deploy_eth = max_deploy_usd / ETH_USD if ETH_USD > 0 else deploy
            if deploy > max_deploy_eth:
                logger.info('POSITION CAP: $%.0f → $%.0f (0.15%% of $%.0f liq)',
                             deploy * ETH_USD, max_deploy_usd, liq)
                deploy = max_deploy_eth
            if deploy * ETH_USD < 20:
                logger.info('SKIP %s — capped position too small ($%.1f < $20)', c['sym'], deploy * ETH_USD)
                return None

    # ═══ SLIPPAGE PRE-CHECK (~300ms) ═══
    # Skip for SPY routes (checked differently) and V4 "other" routes (deploy=0, checked by V4 Quoter)
    if not is_spy_route and not is_v4_other and deploy > 0:
        slip_ok, slip_pct = check_slippage(c['addr'], deploy, c['sym'], mkt_price, liquidity=liq)
        if not slip_ok:
            logger.info('SKIP %s — slippage too high (%.1f%%)', c['sym'], slip_pct)
            return None

    # ═══ HONEYPOT CHECK — simulate buy + sell BEFORE committing real money ═══
    # honeypot_check() handles blacklisting internally for confirmed honeypots.
    # INCONCLUSIVE results return False but do NOT blacklist — token can retry.
    if not honeypot_check(c['addr']):
        logger.warning('🚨 HONEYPOT BLOCKED: %s — cannot sell, skipping', c['sym'])
        return None

    if route.startswith('v4'):
        # V4 route: determine quote token and amount
        v4_quote_addr, v4_quote_sym, v4_quote_dec, _, _ = _parse_v4_route(route)
        if v4_quote_sym == 'ETH':
            tokens, entry_price = v4_buy(c['addr'], deploy, c['sym'], market_price=mkt_price)
        elif v4_quote_sym == 'SPY':
            tokens, entry_price = v4_buy(c['addr'], deploy_spy, c['sym'], market_price=mkt_price)
        else:
            # Other quote tokens (USDG/HIMS/NVDA) — use position-capped qt_human
            # Finding 4: qt_human was already capped by position sizing above
            qt_deploy = qt_human * 0.95  # Keep 5% reserve
            if qt_deploy < 1:
                logger.error('Not enough %s for V4: %.6f', v4_quote_sym, qt_human)
                return None
            tokens, entry_price = v4_buy(c['addr'], qt_deploy, c['sym'], market_price=mkt_price)
    elif is_spy_route:
        tokens, entry_price = v3_buy_spy(c['addr'], deploy_spy, c['sym'], market_price=mkt_price)
    elif route.startswith('v3'):
        tokens, entry_price = v3_buy(c['addr'], deploy, c['sym'], market_price=mkt_price)
    else:
        tokens, entry_price = buy(c['addr'], deploy, c['sym'], market_price=mkt_price)
    if tokens <= 0:
        # Track reverted buys per token — stop after MAX_BUY_RETRIES
        BUY_FAIL_COUNT[al] = BUY_FAIL_COUNT.get(al, 0) + 1
        logger.info('BUY FAILED for %s — attempt %d/%d', c['sym'], BUY_FAIL_COUNT[al], MAX_BUY_RETRIES)
        return None
    # Buy succeeded — reset fail counter
    BUY_FAIL_COUNT.pop(al, None)

    # Post-buy sanity — is market price way below our fill?
    # ═══ FIX: Tightened from -5% to -3% (data: fills at -4% to -6% guarantee losses) ═══
    info = price(c['addr'])
    mkt = info['p'] if info else 0
    if mkt > 0 and entry_price > 0:
        diff = (mkt - entry_price) / entry_price * 100
        logger.info('Fill: $%.8f vs market: $%.8f (%+.1f%%)', entry_price, mkt, diff)
        if diff < -3:
            logger.warning('BAD FILL (%.1f%%) — aborting, selling back. BLACKLISTING %s', diff, c['sym'])
            PONS_BLACKLIST.add(c['addr'].lower())
            _save_blacklist()
            try:
                sell_result = _do_sell(c['addr'], c['sym'], market_price=mkt)
            except Exception as sell_ex:
                logger.error('BAD FILL sell-back EXCEPTION for %s: %s — latching exit', c['sym'], sell_ex)
                sell_result = -1
            if sell_result <= 0:
                # Sell-back failed — return position with exit latch so main loop keeps trying
                logger.error('BAD FILL sell-back FAILED for %s — latching exit to retry', c['sym'])
                return {'addr': c['addr'], 'sym': c['sym'], 'entry': entry_price,
                        'peak': entry_price, 'tick': 0, 'c5_history': [], 'bs_history': [],
                        '_exit_latched': True, '_sell_fails': 1}
            return None

    value = tokens * mkt if mkt > 0 else deploy * ETH_USD
    update_bal(c['sym'], c['addr'], tokens, value)
    logger.info('POSITION: %s %s tokens @ $%.8f', c['sym'], f'{tokens:,.0f}', entry_price)

    # ═══ START FAST PRICE MONITOR (using pre-discovered pool) ═══
    if pre_pool_info:
        price_monitor.start(c['addr'], entry_price, pre_pool_info)
        logger.info('FAST MONITOR: Started immediately (pre-discovered pool)')
    else:
        logger.info('FAST MONITOR: No pool found — DexScreener-only mode for %s', c['sym'])

    return {
        'sym': c['sym'], 'addr': c['addr'], 'entry': entry_price,
        'tokens': tokens, 'peak': entry_price,
        'sc': 0, 'mc': 0, 'tc': 0, 'tick': 0,
        'c5_history': list(readings),  # Pre-load with verification readings
        'bs_history': [],  # Track B/S ratio trend
        'entry_c5': readings[-1],  # Use latest verified reading
    }


def _do_sell(addr, sym, market_price=0):
    """Route sell to correct DEX (Pons, V3-WETH, V3-SPY, or V4).
    Post-sell: verifies tokens are actually gone — catches already-sold, partial fills, etc."""
    route = TOKEN_ROUTE.get(addr.lower(), 'pons')
    if route.startswith('v4'):
        result = v4_sell(addr, sym, market_price=market_price)
    elif route.startswith('v3spy'):
        result = v3_sell_spy(addr, sym, market_price=market_price)
    elif route.startswith('v3'):
        result = v3_sell(addr, sym, market_price=market_price)
    else:
        result = sell(addr, sym, market_price=market_price)

    # Codex Ultra fix: if sell returned 0, verify tokens are actually still held
    # Catches: already-sold tokens (v4 addr mismatch), tx that succeeded but returned 0
    # Check both DexScreener addr AND V4 on-chain token addr
    if result <= 0:
        try:
            r_check, d_check = bal(addr)
            tokens_left = r_check / (10 ** d_check) if d_check > 0 else r_check
            # Also check V4 pool token address (may differ from DexScreener addr)
            if tokens_left < 100 and route.startswith('v4'):
                v4_pd = _v4_pool_cache.get(addr.lower(), {})
                if v4_pd:
                    qa = v4_pd.get('quote_addr', '')
                    v4_token = v4_pd.get('c1', '') if qa == v4_pd.get('c0', '').lower() else v4_pd.get('c0', '')
                    if v4_token and v4_token.lower() != addr.lower():
                        r2, d2 = bal(v4_token)
                        tokens_left = max(tokens_left, r2 / (10 ** d2) if d2 > 0 else r2)
                else:
                    # V4 route but no cache data — fail closed, don't assume tokens are gone
                    logger.warning('_do_sell: V4 route for %s but no cache data — assuming tokens still held', sym)
                    tokens_left = 999999
            if tokens_left < 100:  # Dust or zero at BOTH addresses — tokens are gone
                logger.info('_do_sell: sell fn returned 0 but tokens gone/dust (%.0f left) — treating as success', tokens_left)
                e = eth_bal()
                return e if e > 0 else 0.001  # Fallback positive value to clear position
        except Exception:
            # Fail closed — assume tokens still held if we can't check
            logger.error('_do_sell: balance check failed for %s — assuming tokens still held', sym)

    return result


def main():
    _enforce_single_instance()
    logger.info('=' * 50)
    logger.info('ROTATION ENGINE v6.2 — CODEX ULTRA OPTIMIZED (verified entry + SL fix + single instance)')
    logger.info('Enter: 5m +%.0f%%–+%.0f%% B/S>%.2f | Exit: TP(+%.0f%%)/momentum/SL(-%.0f%%)',
                MIN_5M_ENTRY, MAX_5M_ENTRY, MIN_BS_ENTRY, HARD_TP, HARD_SL)
    e_usd = eth_bal() * ETH_USD
    s_usd = spy_bal_usd()
    logger.info('Wallet: %s | $%.2f ETH + ~$%.0f SPY | Target: $%.0f', W, e_usd, s_usd, COST_BASIS)
    logger.info('=' * 50)

    rot = 0

    pos = None

    # Detect existing positions on startup — scan Pons whitelist + V4 cached tokens
    if pos is None:
        # Finding 6 (R2): Check Pons whitelist + V4 cached tokens + TOKEN_ROUTE entries
        # Build (dex_addr, v4_on_chain_addr) pairs so we can check both for balance
        startup_checks = []  # [(check_addr, dex_addr_for_route)]
        for addr in PONS_WHITELIST:
            startup_checks.append((addr, addr))
        for v4_al, v4_pd in _v4_pool_cache.items():
            # Only recover if this quote token is currently enabled
            qa = v4_pd.get('quote_addr', '')
            qs = v4_pd.get('quote_sym', '?')
            if qs not in ('ETH', '?') and not QUOTE_ENABLED.get(qa, False):
                continue
            v4_token = v4_pd['c1'] if v4_pd['quote_addr'] == v4_pd['c0'].lower() else v4_pd['c0']
            startup_checks.append((v4_token, v4_al))  # Check V4 on-chain addr, route via dex addr
            if v4_al.lower() != v4_token.lower():
                startup_checks.append((v4_al, v4_al))  # Also check DexScreener address
        for check_addr, dex_addr in startup_checks:
            # Skip blacklisted tokens (e.g. IPUNK honeypot — tokens stuck, unsellable)
            if check_addr.lower() in PONS_BLACKLIST or dex_addr.lower() in PONS_BLACKLIST:
                continue
            try:
                r, d = bal(check_addr)
                tamt = r / (10 ** d)
                if tamt > 100:  # Meaningful token balance
                    info = price(check_addr) or price(dex_addr)
                    if info and info['p'] > 0:
                        sym = info.get('sym', '?')
                        # Use cached route if available — don't default to Pons for V4 tokens
                        route = TOKEN_ROUTE.get(dex_addr.lower(), TOKEN_ROUTE.get(check_addr.lower(), ''))
                        if route:
                            logger.info('DETECTED existing position: %s (%s tokens @ $%.8f) route=%s',
                                        sym, f'{tamt:,.0f}', info['p'], route)
                        else:
                            # No known route — skip to avoid sending to wrong seller
                            logger.warning('DETECTED tokens: %s (%s tokens @ $%.8f) but NO ROUTE — skipping (manual sell needed)',
                                           sym, f'{tamt:,.0f}', info['p'])
                            continue
                        pos = {'addr': dex_addr, 'sym': sym, 'entry': info['p'], 'peak': info['p'],
                               'tick': 0, 'c5_history': [], 'bs_history': []}
                        # Start fast monitor for existing position
                        pool_info = _discover_pool(dex_addr) or _discover_pool(check_addr)
                        if pool_info:
                            price_monitor.start(dex_addr, info['p'], pool_info)
                        break
            except Exception:
                pass

    if not pos:
        # Wait for a pump to enter
        pos = enter()
        while not pos:
            logger.info('Waiting for a pump... (scanning every %ds)', SCAN_INTERVAL)
            time.sleep(SCAN_INTERVAL)
            pos = enter()

    while True:
        try:
            # ═══ FAST EXIT CHECK — sub-second, from monitor thread ═══
            if price_monitor.is_active():
                should, reason = price_monitor.should_sell()
                if should:
                    logger.warning('⚡ FAST EXIT: %s on %s — selling NOW', reason, pos['sym'])
                    price_monitor.stop()
                    fast_price = price_monitor.get_price() if price_monitor.get_price() > 0 else pos.get('last_price', 0)
                    # Codex Ultra: wrap _do_sell in try/except so exceptions still count as failures
                    try:
                        e = _do_sell(pos['addr'], pos['sym'], market_price=fast_price)
                    except Exception as sell_ex:
                        logger.error('⚡ FAST EXIT _do_sell EXCEPTION for %s: %s', pos['sym'], sell_ex)
                        e = 0  # Treat exception as failed sell
                    if e > 0:
                        rot += 1
                        total = e * ETH_USD
                        logger.info('⚡ Fast Exit #%d — $%.2f', rot, total)
                        EXIT_COOLDOWN[pos['addr'].lower()] = time.time()  # Fast exit = always a loss → cooldown
                        SESSION_LOSSES[pos['addr'].lower()] = SESSION_LOSSES.get(pos['addr'].lower(), 0) + 1
                        if SESSION_LOSSES[pos['addr'].lower()] >= MAX_SESSION_LOSSES:
                            logger.warning('🚫 SESSION BLACKLIST: %s lost %d times via fast exits', pos['sym'], SESSION_LOSSES[pos['addr'].lower()])
                        if total >= COST_BASIS:
                            logger.info('🏆 PAST $%.0f! $%.2f — KEEP COMPOUNDING', COST_BASIS, total)
                        pos = None
                        while not pos:
                            time.sleep(SCAN_INTERVAL)
                            pos = enter()
                        continue
                    else:
                        # Codex Ultra: count fast-exit failures, latch exit intent
                        sell_fail_count = pos.get('_sell_fails', 0) + 1
                        pos['_sell_fails'] = sell_fail_count
                        pos['_exit_latched'] = True  # Latch: keep trying to exit
                        logger.error('⚡ FAST EXIT SELL FAILED (%d times) for %s — will retry via main loop',
                                     sell_fail_count, pos['sym'])

            info = price(pos['addr'])
            if not info or info['p'] <= 0:
                # If exit is latched, attempt sell even without price data
                if pos.get('_exit_latched'):
                    logger.warning('Price unavailable but exit latched for %s — attempting sell anyway', pos['sym'])
                    sr = _do_sell(pos['addr'], pos['sym'])
                    if sr and sr > 0:
                        logger.info('LATCHED EXIT SELL OK for %s during price outage', pos['sym'])
                        EXIT_COOLDOWN[pos['addr'].lower()] = time.time()
                        pos = None
                        while not pos:
                            time.sleep(SCAN_INTERVAL)
                            pos = enter()
                        continue
                    # Sell failed — fall through to normal sleep+retry
                time.sleep(POLL_SEC)
                continue

            p = info['p']
            c5 = info['c5']
            b5 = info['b5']
            s5 = info['s5']
            bs_ratio = b5 / max(s5, 1)
            pnl = (p - pos['entry']) / pos['entry'] * 100
            pos['last_price'] = p  # Track for fast monitor exit sell

            # Update peak
            if p > pos['peak']:
                pos['peak'] = p

            # Track momentum + B/S history
            pos['c5_history'].append(c5)
            if len(pos['c5_history']) > MOMENTUM_HISTORY:
                pos['c5_history'] = pos['c5_history'][-MOMENTUM_HISTORY:]
            pos['bs_history'].append(bs_ratio)
            if len(pos['bs_history']) > MOMENTUM_HISTORY:
                pos['bs_history'] = pos['bs_history'][-MOMENTUM_HISTORY:]
            pos['tick'] += 1

            # Dynamic trail: wide when pumping hard, tight when cooling
            trail = TRAIL_WIDE if c5 >= MOMENTUM_STRONG else TRAIL_TIGHT
            do_exit = False
            exit_reason = ''
            warmed = pos['tick'] >= WARMUP_TICKS  # Skip exits during warmup

            # ═══ EXIT 0: HARD TAKE-PROFIT (+25%) — INSTANT, NO WARMUP, NO EXCEPTIONS ═══
            # Data across 61 trades: 25% TP turns -62% total PnL into +105% total gain.
            # Fires BEFORE all other exits. Locks profit the instant we hit +25%.
            if pnl >= HARD_TP:
                exit_reason = f'💰 TAKE PROFIT {pnl:+.1f}% ≥ {HARD_TP:+.1f}%'
                do_exit = True
                logger.info('🎯 HARD TP HIT on %s at PnL=%+.1f%% — LOCKING PROFIT', pos['sym'], pnl)

            # ═══ EXIT 1: MOMENTUM SHIFT — INSTANT (1 reading, Shaheer directive) ═══
            # We know the momentum when we entered. ONE reading showing it dropped
            # significantly from the previous reading = sell NOW. Don't wait for 3.
            hist = pos['c5_history']
            if warmed and len(hist) >= 2:
                prev = hist[-2]
                curr = hist[-1]
                # If momentum dropped by more than 30% of previous value in ONE reading
                if prev > 0 and curr < prev * 0.7:
                    exit_reason = f'🔻 SLOWING {prev:+.1f}%→{curr:+.1f}%'
                    do_exit = True

            # ═══ EXIT 2: MOMENTUM DEATH (5m below +3%) ═══
            if not do_exit and warmed and c5 < MOMENTUM_DEATH:
                exit_reason = f'💀 MOMENTUM DEAD 5m={c5:+.1f}%'
                do_exit = True

            # ═══ EXIT 3: SELLERS DOMINANT (1 reading, Shaheer directive) ═══
            # If B/S ratio drops below 0.7 even ONCE, sellers have taken over — exit
            bsh = pos['bs_history']
            if not do_exit and warmed and len(bsh) >= 1:
                if bsh[-1] < 0.7:
                    exit_reason = f'🔴 SELLERS DOMINANT B/S={b5}/{s5} ratio={bsh[-1]:.2f}'
                    do_exit = True

            # ═══ EXIT 4: TRAILING STOP — DISABLED (momentum slowdown is primary exit) ═══
            # Trailing stop causes premature exits on volatile meme tokens.
            # Momentum slowdown (EXIT 1) catches the real top more accurately.

            # ═══ EXIT 6: LATCHED EXIT — Codex Ultra: once exit is triggered, keep trying ═══
            if not do_exit and pos.get('_exit_latched'):
                exit_reason = '🔁 LATCHED EXIT (retrying previous failed sell)'
                do_exit = True

            # ═══ EXIT 5: HARD STOP LOSS (-5%) — always active, even during warmup ═══
            if not do_exit and pnl <= -HARD_SL:
                exit_reason = f'⛔ HARD SL {pnl:+.1f}%'
                do_exit = True

            # ═══ EXECUTE EXIT ═══
            if do_exit:
                logger.warning('%s on %s PnL=%+.1f%%. Selling...', exit_reason, pos['sym'], pnl)
                price_monitor.stop()  # Stop fast monitor before selling
                # Codex Ultra: wrap _do_sell in try/except so exceptions still count as failures
                try:
                    e = _do_sell(pos['addr'], pos['sym'], market_price=p)
                except Exception as sell_ex:
                    logger.error('EXIT _do_sell EXCEPTION for %s: %s', pos['sym'], sell_ex)
                    e = 0  # Treat exception as failed sell
                if e > 0:
                    sell_fail_count = 0  # Reset on success
                    pos.pop('_exit_latched', None)  # Clear exit latch
                    rot += 1
                    total = e * ETH_USD
                    logger.info('Exit #%d — $%.2f (PnL %+.1f%%)', rot, total, pnl)
                    # Smart cooldown — only cooldown on LOSING exits, allow re-entry on winners
                    if pnl < 0:
                        EXIT_COOLDOWN[pos['addr'].lower()] = time.time()
                        # Track session losses — 2 losses = session-blacklist this token
                        SESSION_LOSSES[pos['addr'].lower()] = SESSION_LOSSES.get(pos['addr'].lower(), 0) + 1
                        loss_count = SESSION_LOSSES[pos['addr'].lower()]
                        if loss_count >= MAX_SESSION_LOSSES:
                            logger.warning('🚫 SESSION BLACKLIST: %s lost %d times — no more entries this session', pos['sym'], loss_count)
                        else:
                            logger.info('🔒 Cooldown ON for %s (losing exit — %d/%d session losses)', pos['sym'], loss_count, MAX_SESSION_LOSSES)
                    else:
                        EXIT_COOLDOWN.pop(pos['addr'].lower(), None)  # Clear any old cooldown
                        logger.info('🔓 No cooldown for %s (winning exit — re-entry allowed)', pos['sym'])
                    if total >= COST_BASIS:
                        logger.info('🏆 PAST $%.0f! $%.2f — KEEP COMPOUNDING', COST_BASIS, total)
                    pos = None
                    while not pos:
                        time.sleep(SCAN_INTERVAL)
                        pos = enter()
                    continue
                else:
                    # Sell failed — track consecutive failures + latch exit intent
                    sell_fail_count = pos.get('_sell_fails', 0) + 1
                    pos['_sell_fails'] = sell_fail_count
                    pos['_exit_latched'] = True  # Keep trying to exit on every tick
                    if sell_fail_count >= 5:
                        # Codex Ultra: verify balance before clearing — don't orphan live tokens
                        # Fail CLOSED: if balance check fails, assume tokens still held
                        try:
                            r_check, d_check = bal(pos['addr'])
                            tokens_left = r_check / (10 ** d_check) if d_check > 0 else r_check
                            # Also check V4 alias address (may differ from DexScreener addr)
                            pos_route = TOKEN_ROUTE.get(pos['addr'].lower(), '')
                            if tokens_left < 100 and pos_route.startswith('v4'):
                                v4_pd = _v4_pool_cache.get(pos['addr'].lower(), {})
                                if v4_pd:
                                    qa = v4_pd.get('quote_addr', '')
                                    v4_token = v4_pd.get('c1', '') if qa == v4_pd.get('c0', '').lower() else v4_pd.get('c0', '')
                                    if v4_token and v4_token.lower() != pos['addr'].lower():
                                        r2, d2 = bal(v4_token)
                                        tokens_left = max(tokens_left, r2 / (10 ** d2) if d2 > 0 else r2)
                        except Exception:
                            tokens_left = 999999  # Assume tokens still held on RPC failure
                        if tokens_left < 100:  # Dust or zero — safe to clear
                            logger.error('🚨 SELL FAILED %d TIMES for %s — tokens gone/dust (%.0f left), clearing position',
                                         sell_fail_count, pos['sym'], tokens_left)
                            EXIT_COOLDOWN[pos['addr'].lower()] = time.time()
                            pos = None
                            while not pos:
                                time.sleep(SCAN_INTERVAL)
                                pos = enter()
                            continue
                        else:
                            # Track TOTAL sell failures across retries (not just per-cycle)
                            total_fails = pos.get('_total_sell_fails', 0) + sell_fail_count
                            pos['_total_sell_fails'] = total_fails
                            if total_fails >= 15:
                                # 15+ total failures = unsellable (likely honeypot with
                                # hook-blocked sells). Blacklist and abandon position to
                                # stop infinite retry loop and wasted gas.
                                logger.error('🚨 HONEYPOT ABANDON: %s — %d total sell failures, %.0f tokens STUCK. BLACKLISTING.',
                                             pos['sym'], total_fails, tokens_left)
                                PONS_BLACKLIST.add(pos['addr'].lower())
                                _save_blacklist()
                                EXIT_COOLDOWN[pos['addr'].lower()] = time.time()
                                pos = None
                                while not pos:
                                    time.sleep(SCAN_INTERVAL)
                                    pos = enter()
                                continue
                            # Tokens still in wallet — DON'T clear, halt new buys, back off
                            logger.error('🚨 SELL FAILED %d TIMES for %s — %.0f tokens STILL IN WALLET — EXIT_BLOCKED (halting, will retry in 60s, total=%d)',
                                         sell_fail_count, pos['sym'], tokens_left, total_fails)
                            pos['_sell_fails'] = 0  # Reset per-cycle counter, will retry after backoff
                            time.sleep(60)  # Back off before retrying
                            continue

            # Status every 15 ticks (~30s)
            if pos['tick'] % 15 == 0:
                r, d = bal(pos['addr'])
                tb = r/(10**d)
                tv = tb * p
                e = eth_bal()
                tot = tv + e * ETH_USD
                peak_drop = (pos['peak'] - p) / pos['peak'] * 100 if pos['peak'] > 0 else 0
                update_bal(pos['sym'], pos['addr'], tb, tv)
                logger.info('R%d %s $%.8f PnL=%+.1f%% 5m=%+.1f%% B/S=%d/%d Peak=-%.1f%% Trail=%.0f%% Val=$%.2f Tot=$%.2f',
                            rot, pos['sym'], p, pnl, c5, b5, s5, peak_drop, trail, tv, tot)

        except Exception as ex:
            logger.error('ERR: %s', ex)

        time.sleep(POLL_SEC)


PID_FILE = '/tmp/rh_engine.pid'

def _enforce_single_instance():
    """Prevent multiple engine instances from trading the same wallet."""
    import signal
    if os.path.exists(PID_FILE):
        try:
            with open(PID_FILE) as f:
                old_pid = int(f.read().strip())
            # Check if old process is actually running
            os.kill(old_pid, 0)
            # It's alive — kill it
            logger.warning('KILLING stale engine instance PID %d', old_pid)
            os.kill(old_pid, signal.SIGTERM)
            time.sleep(2)
            try:
                os.kill(old_pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        except (ProcessLookupError, ValueError):
            pass  # Old process already dead
    # Write our PID
    with open(PID_FILE, 'w') as f:
        f.write(str(os.getpid()))

if __name__ == '__main__':
    if '--status' in sys.argv:
        e = eth_bal()
        sb = spy_bal()
        sb_usd = spy_bal_usd()
        print(f'ETH: {e:.6f} (${e*ETH_USD:.2f})')
        print(f'SPY: {sb:.6f} (~${sb_usd:.2f})')
        print(f'Total: ~${e*ETH_USD + sb_usd:.2f}')
    else:
        main()
