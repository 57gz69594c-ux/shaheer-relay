"""
Gas guard and loss control for Reaper Drone execution.

Thread-safe risk management with persistent state tracking.
Enforces per-chain and global spending limits, auto-pauses
on consecutive failures, and resets at month boundaries.

Accounting model:
  - reserve_and_check() reserves ESTIMATED gas upfront (deducted from budget).
  - settle() records ACTUAL gas spent and profit earned, adjusting the delta.
  - Net loss = total_actual_gas - total_profit (never mixes estimated with actual).
  - Unsettled reservations remain charged at their estimated amount.
"""

import copy
import fcntl
import json
import logging
import math
import os
import re
import shutil
import threading
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Optional

logger = logging.getLogger(__name__)

STATE_FILE = os.path.join(os.path.dirname(__file__), "risk_state.json")

# -- Limits -------------------------------------------------------------------
MAX_GAS_PER_TX_USD = 0.50
MAX_MONTHLY_PER_CHAIN_USD = 25.0
MAX_CONSECUTIVE_FAILURES = 3
MAX_GLOBAL_MONTHLY_LOSSES_USD = 100.0
AUTO_PAUSE_SECONDS = 3600  # 1 hour

# Submission state machine — only forward transitions allowed.
VALID_TRANSITIONS = {
    "pending": {"broadcasting"},      # cancelled only via cancel_reservation()
    "broadcasting": {"submitted", "nonce_consumed_unresolved", "confirmed", "receipt_known"},
    "submitted": {"confirmed", "nonce_consumed_unresolved", "receipt_known"},
    "nonce_consumed_unresolved": {"confirmed", "receipt_known"},
    "receipt_known": {"confirmed", "nonce_consumed_unresolved", "receipt_known"},   # settlement retry / reorg recovery / metadata refresh
    "confirmed": set(),   # terminal
    "cancelled": set(),   # terminal
}


@dataclass(frozen=True)
class ReservationResult:
    """Returned by reserve_and_check(). If approved, use reservation_id in settle()."""
    approved: bool
    reservation_id: str
    reason: str = ""


def _validate_amount(value: float, name: str = "amount") -> None:
    """Raise ValueError if value is not a finite, non-negative float."""
    if isinstance(value, bool):
        raise ValueError(f"Boolean not accepted as monetary amount: {value}")
    if not isinstance(value, (int, float)):
        raise ValueError(f"{name} must be a number, got {type(value).__name__}")
    if math.isnan(value) or math.isinf(value):
        raise ValueError(f"{name} must be finite, got {value}")
    if value < 0:
        raise ValueError(f"{name} must be non-negative, got {value}")


def _empty_chain_state() -> dict:
    return {
        "monthly_gas_estimated": 0.0,
        "monthly_gas_actual": 0.0,
        "monthly_profit": 0.0,
        "consecutive_failures": 0,
        "last_failure_time": 0.0,
        "recent_outcomes": [],  # ordered list of {"seq": int, "ok": bool}
        "total_attempts": 0,
        "total_successes": 0,
    }


def _empty_global_state() -> dict:
    return {
        "month": datetime.now(timezone.utc).strftime("%Y-%m"),
        "monthly_total_gas_estimated": 0.0,
        "monthly_total_gas_actual": 0.0,
        "monthly_total_profit": 0.0,
        "kill_switch_active": False,
        "chains": {},
        "reservations": {},
        "reservation_sequence": 0,
        "initialized_at": datetime.now(timezone.utc).isoformat(),
    }


def _fail_closed_state() -> dict:
    """Return a locked-down state with kill switch active and zero budgets.

    Used when persistent state is corrupt. Fail-closed: no execution until
    an operator manually reviews risk_state.json and deactivates the kill switch.
    """
    return {
        "month": datetime.now(timezone.utc).strftime("%Y-%m"),
        "monthly_total_gas_estimated": 0.0,
        "monthly_total_gas_actual": 0.0,
        "monthly_total_profit": 0.0,
        "kill_switch_active": True,
        "chains": {},
        "reservations": {},
        "initialized_at": time.time(),
    }


class GasGuard:
    """
    Thread-safe gas and loss guard for multi-chain liquidation execution.

    Tracks per-chain and global spend, enforces hard limits, auto-pauses
    chains after consecutive failures, and persists state to disk.

    Designed to be shared by multiple MorphoDrone instances in one process.
    All public methods acquire the internal lock and are safe for concurrent use.

    Usage:
        guard = GasGuard()
        result = guard.reserve_and_check("base", estimated_gas_usd=0.12)
        if result.approved:
            # ... submit TX ...
            guard.settle(result.reservation_id, actual_gas_usd=0.11,
                         profit_usd=0.50, success=True)
        # On TX failure:
            guard.settle(result.reservation_id, actual_gas_usd=0.11,
                         profit_usd=0.0, success=False)
    """

    def __init__(self, state_file: str = STATE_FILE):
        self._state_file = state_file
        self._lock = threading.Lock()
        self._lock_fd = None
        self._closed = False
        self._persistence_failed = False  # A41: blocks ops after uncertain commit
        # P2-13: Track monotonic time at init + last failure for pause checks
        # that can't be fooled by forward wall-clock jumps.
        self._mono_init = time.monotonic()
        self._wall_init = time.time()
        self._mono_last_failure: dict[str, float] = {}  # chain_key → monotonic time
        # Gate/dispatch race fix: external lock that serializes safety
        # state changes (kill switch, pause) with relay dispatch.
        # Set by SafeMorphoExecutor via set_dispatch_lock().
        self._dispatch_lock: Optional[threading.Lock] = None
        self._enforce_single_owner()
        self._state = self._load_state()

    def _enforce_single_owner(self) -> None:
        """Ensure only one process owns the state file at a time.

        Uses fcntl.flock for an exclusive advisory lock held for the
        lifetime of the process.  If another process already holds the
        lock, initialization fails immediately with a clear error.

        This prevents the lost-update problem where separate chain
        processes load independent snapshots and overwrite each other's
        accounting.  Run all chains in a single process, or use separate
        state files per chain.
        """
        lock_path = self._state_file + ".lock"
        self._lock_fd = open(lock_path, "w")
        try:
            fcntl.flock(self._lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except (IOError, OSError):
            self._lock_fd.close()
            self._lock_fd = None
            raise RuntimeError(
                f"Another process already owns {self._state_file}. "
                f"Only one GasGuard instance may operate per state file. "
                f"Run all chains in a single process, or use separate "
                f"state files (state_file='risk_state_base.json')."
            )
        # Write PID for diagnostics
        self._lock_fd.seek(0)
        self._lock_fd.truncate()
        self._lock_fd.write(str(os.getpid()))
        self._lock_fd.flush()

    def close(self) -> None:
        """Release the process-level file lock and mark guard as closed.

        After close(), all mutating operations (reserve_and_check, settle,
        cancel_reservation, etc.) will raise RuntimeError.  This prevents
        a closed guard from silently overwriting state owned by a new guard.

        Synchronized: acquires the lock before setting _closed, so any
        in-progress operation that already passed _check_open() will finish
        its disk write before the lock is released.
        """
        with self._lock:
            self._closed = True
        if self._lock_fd is not None:
            try:
                fcntl.flock(self._lock_fd, fcntl.LOCK_UN)
                self._lock_fd.close()
            except Exception:
                pass
            self._lock_fd = None

    def _check_open(self) -> None:
        """Raise if the guard has been closed or persistence is uncertain.

        MUST be called inside self._lock to prevent TOCTOU with close().
        """
        if self._closed:
            raise RuntimeError(
                "GasGuard is closed — cannot perform operations. "
                "Create a new instance if needed."
            )
        if self._persistence_failed:
            raise RuntimeError(
                "GasGuard persistence failed — state may be stale. "
                "Cannot perform operations until restarted."
            )

    def __del__(self):
        self.close()

    # -- Persistence ----------------------------------------------------------

    def _load_state(self) -> dict:
        """Load state from disk, return empty state if missing or corrupt."""
        try:
            with open(self._state_file, "r") as f:
                raw = f.read()
            state = json.loads(raw)
            # P2-14: Validate root type and container types before traversal
            if not isinstance(state, dict):
                logger.critical("CORRUPT STATE: root is %s, not dict", type(state).__name__)
                self._backup_corrupt(raw)
                return _fail_closed_state()
            # Validate structure
            if "month" not in state or "chains" not in state:
                logger.critical(
                    "CORRUPT STATE: risk_state.json missing required keys. "
                    "Creating backup and activating kill switch. "
                    "EXECUTION HALTED — kill switch activated. Manual review required."
                )
                self._backup_corrupt(raw)
                return _fail_closed_state()
            # P2-14: Validate container types — must be dicts, not lists/etc.
            if not isinstance(state.get("chains"), dict):
                logger.critical("CORRUPT STATE: 'chains' is %s, not dict",
                                type(state.get("chains")).__name__)
                self._backup_corrupt(raw)
                return _fail_closed_state()
            if "reservations" in state and not isinstance(state["reservations"], dict):
                logger.critical("CORRUPT STATE: 'reservations' is %s, not dict",
                                type(state["reservations"]).__name__)
                self._backup_corrupt(raw)
                return _fail_closed_state()
            # Validate month field — null/None or non-YYYY-MM is corrupt
            month = state.get("month")
            if not isinstance(month, str) or not re.match(r'^\d{4}-(0[1-9]|1[0-2])$', month):
                logger.critical("CORRUPT STATE: invalid month field: %s", month)
                self._backup_corrupt(raw)
                return _fail_closed_state()
            # Ensure reservations dict exists (migration from older format)
            # A30: If reservations map is missing but accounting shows unsettled
            # gas (estimated > actual), live TXs were silently discarded.
            # Fail-closed to prevent stuck holds and missing settlements.
            if "reservations" not in state:
                total_est = state.get("monthly_total_gas_estimated", 0)
                total_act = state.get("monthly_total_gas_actual", 0)
                if isinstance(total_est, (int, float)) and isinstance(total_act, (int, float)):
                    unsettled_gap = total_est - total_act
                    if unsettled_gap > 0.001:
                        logger.critical(
                            "MISSING RESERVATIONS: estimated=$%.4f > actual=$%.4f "
                            "(gap=$%.4f) implies live TXs were lost — fail-closed",
                            total_est, total_act, unsettled_gap,
                        )
                        self._backup_corrupt(raw)
                        return _fail_closed_state()
                state["reservations"] = {}
            # Validate initialized_at: if missing, this is an older-format or
            # manually-created file — treat as corrupt (fail-closed).
            if "initialized_at" not in state:
                logger.critical(
                    "CORRUPT STATE: risk_state.json missing initialized_at "
                    "(older format or manually created). "
                    "Creating backup and activating kill switch. "
                    "EXECUTION HALTED — manual review required."
                )
                self._backup_corrupt(raw)
                return _fail_closed_state()
            # Fail-closed if critical accounting fields are missing BEFORE
            # migration — _migrate_legacy_keys may legitimately fill them via
            # renames, but setdefault must NOT silently mask truly absent data.
            # Check for both current AND legacy key names: if neither is
            # present, the file is corrupt.
            _global_key_pairs = [
                ('monthly_total_gas_estimated', 'monthly_total_spent'),
                ('monthly_total_gas_actual', None),
                ('monthly_total_profit', None),
            ]
            for current_key, legacy_key in _global_key_pairs:
                if current_key not in state and (legacy_key is None or legacy_key not in state):
                    logger.critical("CORRUPT STATE: missing required field '%s'", current_key)
                    self._backup_corrupt(raw)
                    return _fail_closed_state()
            # Fail-closed if critical chain-level accounting fields are missing
            _chain_key_pairs = [
                ('monthly_gas_estimated', 'monthly_spent'),
                ('monthly_gas_actual', None),
                ('monthly_profit', None),
            ]
            for chain_name, chain_data in state.get("chains", {}).items():
                # P2-06: Each chain record must be a dict
                if not isinstance(chain_data, dict):
                    logger.critical(
                        "CORRUPT STATE: chains.%s is %s, not dict",
                        chain_name, type(chain_data).__name__,
                    )
                    self._backup_corrupt(raw)
                    return _fail_closed_state()
                for current_key, legacy_key in _chain_key_pairs:
                    if current_key not in chain_data and (legacy_key is None or legacy_key not in chain_data):
                        logger.critical(
                            "CORRUPT STATE: chains.%s missing required field '%s'",
                            chain_name, current_key,
                        )
                        self._backup_corrupt(raw)
                        return _fail_closed_state()
            # Migration: rename legacy keys if present (AFTER validation)
            self._migrate_legacy_keys(state)
            # Validate no NaN/Inf in accounting values
            for key in ('monthly_total_gas_estimated', 'monthly_total_gas_actual', 'monthly_total_profit'):
                val = state.get(key, 0.0)
                if isinstance(val, bool) or not isinstance(val, (int, float)) or (isinstance(val, float) and not math.isfinite(val)) or val < 0:
                    logger.critical("CORRUPT STATE: %s has invalid value %s", key, val)
                    self._backup_corrupt(raw)
                    return _fail_closed_state()
            # Also validate chain-level accounting values
            for chain_name, chain_data in state.get("chains", {}).items():
                for ckey in ('monthly_gas_estimated', 'monthly_gas_actual', 'monthly_profit'):
                    cval = chain_data.get(ckey, 0.0)
                    if isinstance(cval, bool) or not isinstance(cval, (int, float)) or (isinstance(cval, float) and not math.isfinite(cval)) or cval < 0:
                        logger.critical("CORRUPT STATE: chains.%s.%s has invalid value %s", chain_name, ckey, cval)
                        self._backup_corrupt(raw)
                        return _fail_closed_state()
            # Validate reservation estimated_gas_usd values
            # A30: Missing field is also invalid (default-0 hides the hold)
            for rid, rdata in state.get("reservations", {}).items():
                # P2-06: Each reservation must be a dict
                if not isinstance(rdata, dict):
                    logger.critical(
                        "CORRUPT STATE: reservation %s is %s, not dict",
                        rid, type(rdata).__name__,
                    )
                    self._backup_corrupt(raw)
                    return _fail_closed_state()
                if "estimated_gas_usd" not in rdata:
                    logger.critical("CORRUPT STATE: reservation %s missing estimated_gas_usd", rid)
                    self._backup_corrupt(raw)
                    return _fail_closed_state()
                rval = rdata["estimated_gas_usd"]
                if isinstance(rval, bool) or not isinstance(rval, (int, float)) or (isinstance(rval, float) and not math.isfinite(rval)) or rval < 0:
                    logger.critical("CORRUPT STATE: reservation %s estimated_gas_usd has invalid value %s", rid, rval)
                    self._backup_corrupt(raw)
                    return _fail_closed_state()
            # Accounting consistency: estimated >= actual (can't spend more than estimated)
            # This catches states like $25 actual but $0 estimated
            total_estimated = state.get("monthly_total_gas_estimated", 0)
            total_actual = state.get("monthly_total_gas_actual", 0)
            if total_actual > total_estimated + 0.01:  # small tolerance for rounding
                logger.critical(
                    "ACCOUNTING INCONSISTENCY: actual ($%.2f) > estimated ($%.2f). "
                    "Creating backup and activating kill switch. "
                    "EXECUTION HALTED — manual review required.",
                    total_actual, total_estimated,
                )
                self._backup_corrupt(raw)
                return _fail_closed_state()
            # Fail-closed: if kill_switch key is missing, None, or non-bool, default to True (halt execution)
            ks_val = state.get("kill_switch_active")
            if ks_val is None or not isinstance(ks_val, bool):
                logger.warning("kill_switch_active missing or invalid type (%s) — defaulting to True (fail-closed)", type(ks_val).__name__)
                state["kill_switch_active"] = True

            # Chain-level accounting: actual <= estimated per chain
            for chain_name, chain_data in state.get("chains", {}).items():
                chain_actual = chain_data.get("monthly_gas_actual", 0)
                chain_estimated = chain_data.get("monthly_gas_estimated", 0)
                if chain_actual > chain_estimated + 0.01:
                    logger.critical(
                        "CHAIN ACCOUNTING INCONSISTENCY [%s]: actual ($%.2f) > estimated ($%.2f)",
                        chain_name, chain_actual, chain_estimated,
                    )
                    self._backup_corrupt(raw)
                    return _fail_closed_state()

            # Cross-check: sum of chain actuals ≈ global actual
            chain_actual_sum = sum(
                cd.get("monthly_gas_actual", 0)
                for cd in state.get("chains", {}).values()
            )
            if abs(chain_actual_sum - total_actual) > 0.01:
                logger.critical(
                    "GLOBAL/CHAIN TOTAL MISMATCH: chains=$%.2f, global=$%.2f",
                    chain_actual_sum, total_actual,
                )
                self._backup_corrupt(raw)
                return _fail_closed_state()

            # Cross-check: sum of chain profits ≈ global profit
            chain_profit_sum = sum(
                cd.get("monthly_profit", 0)
                for cd in state.get("chains", {}).values()
            )
            total_profit = state.get("monthly_total_profit", 0)
            if abs(chain_profit_sum - total_profit) > 0.01:
                logger.critical(
                    "GLOBAL/CHAIN PROFIT MISMATCH: chains=$%.2f, global=$%.2f",
                    chain_profit_sum, total_profit,
                )
                self._backup_corrupt(raw)
                return _fail_closed_state()

            # Validate: estimated >= actual + sum(unsettled reservation amounts)
            unsettled_sum = sum(
                r.get("estimated_gas_usd", 0)
                for r in state.get("reservations", {}).values()
                if not r.get("settled")
            )
            expected_estimated = round(total_actual + unsettled_sum, 6)
            if abs(state["monthly_total_gas_estimated"] - expected_estimated) > 0.02:
                logger.critical(
                    "ACCOUNTING INVARIANT VIOLATED: estimated=$%.4f != actual($%.4f) + unsettled($%.4f) = $%.4f",
                    state["monthly_total_gas_estimated"], total_actual, unsettled_sum, expected_estimated,
                )
                self._backup_corrupt(raw)
                return _fail_closed_state()

            # Per-chain: estimated >= actual + chain's unsettled reservations
            for chain_name, chain_data in state.get("chains", {}).items():
                chain_actual = chain_data.get("monthly_gas_actual", 0)
                chain_estimated = chain_data.get("monthly_gas_estimated", 0)
                chain_unsettled = sum(
                    r.get("estimated_gas_usd", 0)
                    for r in state.get("reservations", {}).values()
                    if not r.get("settled") and r.get("chain_key") == chain_name
                )
                expected_chain_estimated = round(chain_actual + chain_unsettled, 6)
                if abs(chain_estimated - expected_chain_estimated) > 0.02:
                    logger.critical(
                        "CHAIN ACCOUNTING INVARIANT [%s]: estimated=$%.4f != actual($%.4f) + unsettled($%.4f)",
                        chain_name, chain_estimated, chain_actual, chain_unsettled,
                    )
                    self._backup_corrupt(raw)
                    return _fail_closed_state()

            # F10: Validate that unsettled reservations reference known chain keys.
            # Orphaned reservations (chain removed but reservation persists) are
            # budget leaks — they hold estimated gas that can never settle.
            known_chains = set(state.get("chains", {}).keys())
            for rid, rdata in list(state.get("reservations", {}).items()):
                if rdata.get("settled"):
                    continue
                rchain = rdata.get("chain_key")
                # F27: Missing or empty chain_key is also orphaned
                if not rchain or not isinstance(rchain, str):
                    logger.critical(
                        "Reservation %s has missing/empty chain_key (%r) — fail-closed",
                        rid, rchain,
                    )
                    self._backup_corrupt(raw)
                    return _fail_closed_state()
                if rchain not in known_chains:
                    logger.critical(
                        "Orphaned reservation %s references unknown chain '%s' — fail-closed",
                        rid, rchain,
                    )
                    self._backup_corrupt(raw)
                    return _fail_closed_state()

            # Phase 1: Sanitize recent_outcomes FIRST (before failure reconstruction)
            for chain_name, chain_data in state.get("chains", {}).items():
                ro = chain_data.get("recent_outcomes")
                if not isinstance(ro, list):
                    # A23+A21: null/non-list → seed with stored failure count
                    # so settle() computes correct streak from history.
                    if ro is not None:
                        logger.warning(
                            "Sanitizing invalid recent_outcomes (%s) for chain %s",
                            type(ro).__name__, chain_name,
                        )
                    cf_raw = chain_data.get("consecutive_failures", 0)
                    seed_failures = cf_raw if isinstance(cf_raw, int) and not isinstance(cf_raw, bool) and cf_raw > 0 else 0
                    if seed_failures > 0:
                        # P2-05: Use sequences ABOVE all existing reservation
                        # sequences to avoid collisions that let stale successes
                        # sort after synthetic failures and reset the streak.
                        all_res_seqs = [
                            r.get("sequence", 0)
                            for r in state.get("reservations", {}).values()
                        ]
                        max_any_seq = max(all_res_seqs, default=0)
                        chain_data["recent_outcomes"] = [
                            {"seq": max_any_seq + 1 + i, "ok": False}
                            for i in range(seed_failures)
                        ]
                        logger.warning(
                            "Seeded %d synthetic failures (seq %d+) for chain %s",
                            seed_failures, max_any_seq + 1, chain_name,
                        )
                    else:
                        chain_data["recent_outcomes"] = []
                else:
                    # Strip invalid entries (null, non-dict, missing seq/ok)
                    valid = []
                    for entry in ro:
                        if (isinstance(entry, dict)
                                and isinstance(entry.get("seq"), int)
                                and not isinstance(entry.get("seq"), bool)
                                and isinstance(entry.get("ok"), bool)):
                            valid.append(entry)
                    if len(valid) != len(ro):
                        logger.warning(
                            "Stripped %d invalid recent_outcomes entries for chain %s",
                            len(ro) - len(valid), chain_name,
                        )
                    # Sort FIRST so trailing-failure count is accurate
                    valid.sort(key=lambda x: x["seq"])
                    # A21: If valid outcomes have fewer trailing failures than
                    # consecutive_failures, append synthetic entries AFTER all
                    # existing outcomes AND all reservation sequences.
                    cf_raw = chain_data.get("consecutive_failures", 0)
                    stored_cf = cf_raw if isinstance(cf_raw, int) and not isinstance(cf_raw, bool) and cf_raw > 0 else 0
                    if stored_cf > 0:
                        # Count trailing failures in SORTED outcomes
                        trailing = 0
                        for entry in reversed(valid):
                            if entry.get("ok") is False:
                                trailing += 1
                            else:
                                break
                        if trailing < stored_cf:
                            seed_count = stored_cf - trailing
                            # Use max of ALL sequences (outcomes + reservations)
                            # to avoid collisions with outstanding reservations
                            all_res_seqs = [
                                r.get("sequence", 0)
                                for r in state.get("reservations", {}).values()
                            ]
                            max_any_seq = max(
                                [e["seq"] for e in valid] + all_res_seqs,
                                default=0,
                            )
                            synthetic = [
                                {"seq": max_any_seq + 1 + i, "ok": False}
                                for i in range(seed_count)
                            ]
                            valid = valid + synthetic
                            logger.warning(
                                "Appended %d synthetic failures (had %d trailing, need %d) for chain %s",
                                seed_count, trailing, stored_cf, chain_name,
                            )
                    chain_data["recent_outcomes"] = valid
                # A23: Ensure operational integer fields default correctly
                for ifield in ("total_attempts", "total_successes"):
                    iv = chain_data.get(ifield)
                    if iv is None or isinstance(iv, bool) or not isinstance(iv, int):
                        chain_data[ifield] = 0

            # Phase 2: Reconstruct consecutive_failures from SANITIZED outcomes.
            # A23: Always ensure the key exists after this phase.
            for chain_name, chain_data in state.get("chains", {}).items():
                cf = chain_data.get("consecutive_failures")
                ro = chain_data.get("recent_outcomes", [])
                reconstructed = 0
                for entry in reversed(ro):
                    if entry.get("ok") is False:
                        reconstructed += 1
                    else:
                        break
                if cf is None or isinstance(cf, bool) or not isinstance(cf, int) or cf < 0:
                    logger.warning(
                        "Sanitizing consecutive_failures (%r) for chain %s → %d",
                        cf, chain_name, reconstructed,
                    )
                    chain_data["consecutive_failures"] = reconstructed
                elif cf < reconstructed:
                    logger.warning(
                        "consecutive_failures=%d < reconstructed=%d for chain %s — correcting",
                        cf, reconstructed, chain_name,
                    )
                    chain_data["consecutive_failures"] = reconstructed

            # F41+F26: Validate reservation timestamps — reject missing,
            # bool, non-numeric, NaN, Inf.  Any of these block age computation.
            for rid, rdata in state.get("reservations", {}).items():
                ts = rdata.get("timestamp")
                if (ts is None or isinstance(ts, bool)
                        or not isinstance(ts, (int, float))
                        or (isinstance(ts, float) and not math.isfinite(ts))):
                    logger.critical(
                        "Reservation %s has invalid/missing timestamp (%r) — fail-closed",
                        rid, ts,
                    )
                    self._backup_corrupt(raw)
                    return _fail_closed_state()

            # A29: Validate settled field type — must be bool or absent.
            # Truthy non-bool (e.g. "false") hides live reservations.
            for rid, rdata in state.get("reservations", {}).items():
                settled_val = rdata.get("settled")
                if settled_val is not None and not isinstance(settled_val, bool):
                    logger.critical(
                        "Reservation %s has non-bool settled=%r — fail-closed",
                        rid, settled_val,
                    )
                    self._backup_corrupt(raw)
                    return _fail_closed_state()

            # F28: Validate submission_state values and consistency.
            _VALID_STATES = set(VALID_TRANSITIONS.keys()) | {None}
            for rid, rdata in state.get("reservations", {}).items():
                if rdata.get("settled"):
                    continue
                ss = rdata.get("submission_state")
                if ss not in _VALID_STATES:
                    logger.critical(
                        "Reservation %s has invalid submission_state %r — fail-closed",
                        rid, ss,
                    )
                    self._backup_corrupt(raw)
                    return _fail_closed_state()
                # A22: Terminal states without settled=True are stranded
                if ss in ("confirmed", "cancelled"):
                    logger.critical(
                        "Reservation %s is %s but not settled — fail-closed",
                        rid, ss,
                    )
                    self._backup_corrupt(raw)
                    return _fail_closed_state()
                # A22: Pending with tx_hash means state tracking missed the
                # transition — promote to broadcasting so reconcilers process it.
                # A34: Only promote if nonce is also present — without nonce,
                # nonce-based recovery is impossible and reconcilers can't process it.
                if ss in ("pending", None) and rdata.get("tx_hash"):
                    pn_promo = rdata.get("nonce")
                    if pn_promo is not None and isinstance(pn_promo, int) and not isinstance(pn_promo, bool) and pn_promo >= 0:
                        logger.warning(
                            "Reservation %s is pending but has tx_hash — promoting to broadcasting",
                            rid,
                        )
                        rdata["submission_state"] = "broadcasting"
                    else:
                        logger.critical(
                            "Reservation %s has tx_hash but no valid nonce (%r) — fail-closed",
                            rid, pn_promo,
                        )
                        self._backup_corrupt(raw)
                        return _fail_closed_state()
                # Submitted/broadcasting without tx_hash is unreconcilable
                if rdata.get("submission_state") in ("broadcasting", "submitted", "nonce_consumed_unresolved", "receipt_known"):
                    th = rdata.get("tx_hash")
                    if not th or not isinstance(th, str):
                        logger.critical(
                            "Reservation %s in state %s has invalid tx_hash %r — fail-closed",
                            rid, rdata.get("submission_state"), th,
                        )
                        self._backup_corrupt(raw)
                        return _fail_closed_state()
                    # A38: Normalize bare hex to 0x-prefixed before validation
                    if re.fullmatch(r'[0-9a-fA-F]{64}', th):
                        th = "0x" + th
                        rdata["tx_hash"] = th
                        logger.info("Normalized bare-hex tx_hash for reservation %s", rid)
                    # A31: tx_hash must be valid hex format (0x + 64 hex chars)
                    if not re.fullmatch(r'0x[0-9a-fA-F]{64}', th):
                        logger.critical(
                            "Reservation %s has malformed tx_hash %r — fail-closed",
                            rid, th,
                        )
                        self._backup_corrupt(raw)
                        return _fail_closed_state()
                    # A24+A25: Validate persisted nonce — must be non-negative int.
                    # Missing nonce on active states prevents nonce-based recovery.
                    pn = rdata.get("nonce")
                    if pn is None:
                        logger.critical(
                            "Reservation %s in state %s has no nonce — fail-closed",
                            rid, rdata.get("submission_state"),
                        )
                        self._backup_corrupt(raw)
                        return _fail_closed_state()
                    if isinstance(pn, bool) or not isinstance(pn, int) or pn < 0:
                        logger.critical(
                            "Reservation %s has invalid nonce %r — fail-closed",
                            rid, pn,
                        )
                        self._backup_corrupt(raw)
                        return _fail_closed_state()
                # A26: Validate persisted valuation metadata
                for vf in ("loan_price_usd", "loan_decimals"):
                    vv = rdata.get(vf)
                    if vv is not None:
                        if (isinstance(vv, bool) or not isinstance(vv, (int, float))
                                or (isinstance(vv, float) and not math.isfinite(vv))
                                or vv < 0
                                or (vf == "loan_price_usd" and vv == 0)
                                or (vf == "loan_decimals" and not isinstance(vv, int))):
                            logger.critical(
                                "Reservation %s has invalid %s=%r — fail-closed",
                                rid, vf, vv,
                            )
                            self._backup_corrupt(raw)
                            return _fail_closed_state()
                # A36: Active reservations MUST have valuation metadata.
                # Without loan_price_usd/loan_decimals, profit decoding returns
                # $0 and settlement permanently records zero for real profit.
                # Broadcasting included: relay may have accepted the TX.
                if rdata.get("submission_state") in ("broadcasting", "submitted", "receipt_known", "nonce_consumed_unresolved"):
                    for vf in ("loan_price_usd", "loan_decimals"):
                        if rdata.get(vf) is None:
                            logger.critical(
                                "Reservation %s in state %s missing %s — fail-closed "
                                "(profit decoding would permanently record $0)",
                                rid, rdata.get("submission_state"), vf,
                            )
                            self._backup_corrupt(raw)
                            return _fail_closed_state()
                # A37: Active reservations MUST have sender metadata.
                # Without sender, nonce recovery queries the wrong account
                # after key rotation, permanently recording false gas costs.
                if rdata.get("submission_state") in ("broadcasting", "submitted", "nonce_consumed_unresolved", "receipt_known"):
                    sender_val = rdata.get("sender")
                    if not sender_val or not isinstance(sender_val, str):
                        logger.critical(
                            "Reservation %s in state %s missing sender — fail-closed "
                            "(nonce recovery would query wrong account)",
                            rid, rdata.get("submission_state"),
                        )
                        self._backup_corrupt(raw)
                        return _fail_closed_state()
                    # A31: sender must be valid Ethereum address format
                    if not re.fullmatch(r'0x[0-9a-fA-F]{40}', sender_val):
                        logger.critical(
                            "Reservation %s has malformed sender %r — fail-closed",
                            rid, sender_val,
                        )
                        self._backup_corrupt(raw)
                        return _fail_closed_state()
                # A31: Validate flash_liquidator_addr format if present
                # Also catch non-string types (int, bool, etc.)
                fla = rdata.get("flash_liquidator_addr")
                if fla is not None:
                    if not isinstance(fla, str) or not re.fullmatch(r'0x[0-9a-fA-F]{40}', fla):
                        logger.critical(
                            "Reservation %s has malformed flash_liquidator_addr %r — fail-closed",
                            rid, fla,
                        )
                        self._backup_corrupt(raw)
                        return _fail_closed_state()

            # Migrate legacy reservations: assign sequence numbers based on
            # timestamp ordering so the ordered-outcomes logic handles them
            # correctly.  Legacy entries get sequences far below any seeded
            # failure history (which uses -n, -n+1, ..., -1).  Using -1000
            # base ensures a legacy success settling later cannot reset a
            # pre-existing failure streak by sorting after seeded failures.
            needs_seq = [
                r for r in state.get("reservations", {}).values()
                if "sequence" not in r
            ]
            if needs_seq:
                needs_seq.sort(key=lambda r: r.get("timestamp", 0))
                for i, r in enumerate(needs_seq):
                    r["sequence"] = -1000 - len(needs_seq) + i
                state.setdefault("reservation_sequence", 0)
                logger.info(
                    "Migrated %d legacy reservations with sequence numbers",
                    len(needs_seq),
                )

            # A28: Validate reservation sequence values — must be int (not float/bool).
            # Coercing float→int creates collisions (1.1,1.2→both 1) that erase streaks.
            for rid, rdata in state.get("reservations", {}).items():
                seq = rdata.get("sequence")
                if seq is not None:
                    if isinstance(seq, bool) or not isinstance(seq, int):
                        logger.critical(
                            "Reservation %s has invalid sequence %r — fail-closed",
                            rid, seq,
                        )
                        self._backup_corrupt(raw)
                        return _fail_closed_state()

            # A28: De-duplicate reservation sequences — collisions let old
            # successes sort after newer failures and clear streaks.
            seen_seqs = {}
            for rid, rdata in state.get("reservations", {}).items():
                seq = rdata.get("sequence")
                if seq is not None and seq in seen_seqs:
                    # Assign a unique sequence based on timestamp ordering
                    logger.warning(
                        "Duplicate sequence %d: reservations %s and %s — will re-sequence",
                        seq, seen_seqs[seq], rid,
                    )
                seen_seqs.setdefault(seq, rid)
            if len(seen_seqs) < sum(1 for r in state.get("reservations", {}).values() if r.get("sequence") is not None):
                # Re-assign sequences by timestamp to break ties
                seqd = [(r.get("timestamp", 0), rid, r) for rid, r in state.get("reservations", {}).items() if r.get("sequence") is not None]
                seqd.sort()
                # A35: Build old→new mapping so we can remap recent_outcomes too.
                # Multiple reservations may share the same old sequence (that's
                # why we're re-sequencing). Collect ALL old seqs with their new
                # values; for outcomes, use the LOWEST new seq for a given old
                # seq to preserve chronological ordering.
                old_to_new_seq: dict[int, int] = {}
                for i, (_, rid_s, r) in enumerate(seqd):
                    old_seq = r.get("sequence")
                    if old_seq not in old_to_new_seq:
                        old_to_new_seq[old_seq] = i
                    else:
                        # Multiple reservations shared this old seq — keep
                        # the lowest new value so outcomes sort earliest.
                        old_to_new_seq[old_seq] = min(old_to_new_seq[old_seq], i)
                    r["sequence"] = i
                # A35: Remap recent_outcomes seq values using the same mapping.
                # If outcomes reference sequences NOT in the mapping (from
                # pruned reservations), their relative ordering with surviving
                # reservations is unknowable. If there's a failure streak,
                # manufacturing chronology could let a stale success reset it.
                # Fail-closed if unmapped outcomes exist with an active pause.
                for chain_data in state.get("chains", {}).values():
                    ro = chain_data.get("recent_outcomes")
                    if isinstance(ro, list):
                        mapped_entries = []
                        unmapped_entries = []
                        for entry in ro:
                            if isinstance(entry, dict) and isinstance(entry.get("seq"), int):
                                if entry["seq"] in old_to_new_seq:
                                    entry["seq"] = old_to_new_seq[entry["seq"]]
                                    mapped_entries.append(entry)
                                else:
                                    unmapped_entries.append(entry)
                            else:
                                unmapped_entries.append(entry)
                        if unmapped_entries:
                            # P2-06: Any unmapped failures are potentially part
                            # of a streak. Dropping them could hide failures and
                            # let execution continue unsafely. Fail-closed if
                            # ANY unmapped entry is a failure OR stored streak > 0.
                            cf = chain_data.get("consecutive_failures", 0)
                            has_unmapped_failures = any(
                                isinstance(e, dict) and e.get("ok") is False
                                for e in unmapped_entries
                            )
                            if has_unmapped_failures or (isinstance(cf, int) and cf > 0):
                                logger.critical(
                                    "Cannot safely re-sequence: %d unmapped outcomes "
                                    "(%d failures) with consecutive_failures=%r — fail-closed",
                                    len(unmapped_entries),
                                    sum(1 for e in unmapped_entries if isinstance(e, dict) and e.get("ok") is False),
                                    cf,
                                )
                                self._backup_corrupt(raw)
                                return _fail_closed_state()
                            # Only unmapped successes with no failure streak — safe to drop
                            logger.warning(
                                "Dropped %d unmapped success outcomes during re-sequencing",
                                len(unmapped_entries),
                            )
                        # Only keep explicitly mapped entries
                        ro[:] = mapped_entries
                        # Re-sort outcomes after remapping
                        ro.sort(key=lambda e: e.get("seq", 0) if isinstance(e, dict) else 0)
                        # P2-F: After remapping, verify the failure streak was not
                        # weakened compared to the stored value. Timestamp-based
                        # resequencing can manufacture wrong chronology (e.g., a
                        # success with a later timestamp sorts after failures that
                        # actually occurred before it).
                        cf = chain_data.get("consecutive_failures", 0)
                        if isinstance(cf, int) and cf > 0:
                            new_streak = 0
                            for entry in reversed(ro):
                                if isinstance(entry, dict) and entry.get("ok") is False:
                                    new_streak += 1
                                else:
                                    break
                            if new_streak < cf:
                                logger.critical(
                                    "Re-sequencing weakened failure streak %d → %d — "
                                    "fail-closed (timestamp ordering unreliable)",
                                    cf, new_streak,
                                )
                                self._backup_corrupt(raw)
                                return _fail_closed_state()
                            # P2-03: Check outstanding reservations on this chain.
                            # If any unsettled reservation has a sequence that
                            # falls within or after the failure streak range,
                            # settling it as success could weaken the pause.
                            # With resequenced timestamps, we can't establish
                            # safe chronology for outstanding outcomes.
                            chain_key_for_check = None
                            for ck, cd in state.get("chains", {}).items():
                                if cd is chain_data:
                                    chain_key_for_check = ck
                                    break
                            if chain_key_for_check:
                                # Collect ALL failure sequences in the trailing streak
                                failure_seqs_in_streak = set()
                                for entry in reversed(ro):
                                    if isinstance(entry, dict) and entry.get("ok") is False:
                                        failure_seqs_in_streak.add(entry.get("seq", 0))
                                    else:
                                        break
                                if failure_seqs_in_streak:
                                    min_failure_seq = min(failure_seqs_in_streak)
                                    for rid, rdata in state.get("reservations", {}).items():
                                        r_seq = rdata.get("sequence", 0)
                                        if (not rdata.get("settled")
                                                and rdata.get("chain_key") == chain_key_for_check
                                                and r_seq >= min_failure_seq):
                                            logger.critical(
                                                "Re-sequencing placed outstanding reservation %s "
                                                "(seq %d) within/after failure streak (min_fail_seq %d) — "
                                                "fail-closed",
                                                rid, r_seq, min_failure_seq,
                                            )
                                            self._backup_corrupt(raw)
                                            return _fail_closed_state()
                logger.warning("Re-sequenced %d reservations to eliminate duplicates", len(seqd))

            # Ensure reservation_sequence is present AND ahead of all existing
            # sequences.  F34+F13: both missing and stale counters cause
            # sequence reuse that suppresses failure streaks.
            # Also consider recent_outcomes sequences (survive month rollover).
            all_seqs = [r.get("sequence", 0) for r in state.get("reservations", {}).values()]
            for chain_data in state.get("chains", {}).values():
                for entry in (chain_data.get("recent_outcomes") or []):
                    if isinstance(entry, dict) and isinstance(entry.get("seq"), int):
                        all_seqs.append(entry["seq"])
            max_seq = max(all_seqs, default=0)
            current_counter = state.get("reservation_sequence", 0)
            if not isinstance(current_counter, int) or current_counter <= max_seq:
                state["reservation_sequence"] = max(max_seq + 1, 0)
                logger.warning(
                    "Repaired reservation_sequence: %r → %d (max existing=%d)",
                    current_counter, state["reservation_sequence"], max_seq,
                )

            # Ensure state-file-specific initialization marker exists
            # (so future state-file deletion triggers fail-closed).
            # Also create legacy marker for backward compatibility.
            state_dir = os.path.dirname(self._state_file) or "."
            state_basename = os.path.basename(self._state_file)
            new_marker = os.path.join(state_dir, f".risk_initialized_{state_basename}")
            legacy_marker = os.path.join(state_dir, ".risk_initialized")
            for mp in (new_marker, legacy_marker):
                if not os.path.exists(mp):
                    with open(mp, "w") as f:
                        f.write(str(time.time()))

            return state
        except FileNotFoundError:
            # Use a state-file-specific marker so independent state files
            # (e.g., risk_base.json and risk_ethereum.json) don't collide.
            state_basename = os.path.basename(self._state_file)
            marker_name = f".risk_initialized_{state_basename}"
            marker_path = os.path.join(os.path.dirname(self._state_file), marker_name)
            legacy_marker_path = os.path.join(
                os.path.dirname(self._state_file) or ".", ".risk_initialized",
            )
            # Only check legacy marker for the default state file name.
            # Independent state files (risk_base.json, risk_eth.json) should
            # NOT be blocked by a legacy marker created for a different file.
            _DEFAULT_NAMES = {"risk_state.json", "gas_guard_state.json"}
            legacy_applies = (
                state_basename in _DEFAULT_NAMES
                and os.path.exists(legacy_marker_path)
            )
            if os.path.exists(marker_path) or legacy_applies:
                # We were previously initialized — state file was lost!
                logger.critical(
                    "STATE FILE MISSING but initialization marker exists at %s — "
                    "state was LOST. EXECUTION HALTED — kill switch activated. "
                    "Manual review required.",
                    marker_path if os.path.exists(marker_path) else legacy_marker_path,
                )
                return _fail_closed_state()
            else:
                # Genuine first-time initialization
                state = _empty_global_state()
                self._save_state(state)
                # Create state-file-specific marker
                with open(marker_path, "w") as f:
                    f.write(str(time.time()))
                logger.info("First-time initialization — fresh state created (%s)", state_basename)
                return state
        except (json.JSONDecodeError, KeyError, TypeError) as exc:
            logger.critical(
                "CORRUPT STATE: risk_state.json failed to parse (%s: %s). "
                "Creating backup and activating kill switch. "
                "EXECUTION HALTED — kill switch activated. Manual review required.",
                type(exc).__name__, exc,
            )
            try:
                with open(self._state_file, "r") as f:
                    raw = f.read()
                self._backup_corrupt(raw)
            except Exception:
                pass
            return _fail_closed_state()

    @staticmethod
    def _migrate_legacy_keys(state: dict) -> None:
        """Migrate old single-counter keys to new estimated/actual split.

        Only renames legacy keys — does NOT fill in missing fields with
        defaults. Missing-field detection is handled by the caller BEFORE
        this method runs.
        """
        # Global level: rename monthly_total_spent → monthly_total_gas_estimated
        if "monthly_total_spent" in state and "monthly_total_gas_estimated" not in state:
            state["monthly_total_gas_estimated"] = state.pop("monthly_total_spent")

        # Chain level: rename monthly_spent → monthly_gas_estimated
        for chain_data in state.get("chains", {}).values():
            if "monthly_spent" in chain_data and "monthly_gas_estimated" not in chain_data:
                chain_data["monthly_gas_estimated"] = chain_data.pop("monthly_spent")

    def _backup_corrupt(self, raw_content: str) -> None:
        """Save a backup of corrupt state for forensics."""
        ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        backup_path = self._state_file + f".corrupt.{ts}"
        try:
            with open(backup_path, "w") as f:
                f.write(raw_content)
            logger.warning("Corrupt state backed up to %s", backup_path)
        except Exception as exc:
            logger.error("Failed to write corrupt backup: %s", exc)

    def _save_state(self, state: dict | None = None) -> None:
        """Persist state to disk. Caller must hold the lock.

        If *state* is provided, writes that dict instead of self._state.
        This supports copy-on-write: callers mutate a deepcopy, pass it
        here, and only assign to self._state after this returns successfully.

        On ANY I/O failure, sets _persistence_failed=True to block all
        subsequent operations. This prevents execution with stale counters
        after an unrecorded on-chain outcome.
        """
        data = state if state is not None else self._state
        tmp = self._state_file + ".tmp"
        try:
            with open(tmp, "w") as f:
                json.dump(data, f, indent=2)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, self._state_file)
        except Exception as e:
            logger.critical(
                "State persistence FAILED (write/fsync/replace) — "
                "blocking all operations: %s", e,
            )
            self._persistence_failed = True
            raise
        # A41: dirname("risk.json") returns "" — use "." as fallback.
        dir_path = os.path.dirname(self._state_file) or "."
        try:
            dir_fd = os.open(dir_path, os.O_RDONLY)
            try:
                os.fsync(dir_fd)
            finally:
                os.close(dir_fd)
        except OSError as e:
            logger.critical(
                "Directory fsync FAILED for %s — persistence uncertain, "
                "blocking all operations: %s", dir_path, e,
            )
            self._persistence_failed = True
            raise

    def _ensure_chain(self, state: dict, chain_key: str) -> dict:
        """Ensure chain entry exists in the given state dict. Caller must hold the lock.

        Works on a passed-in state dict rather than self._state to avoid
        mutating live state outside copy-on-write.
        """
        if "chains" not in state:
            state["chains"] = {}
        if chain_key not in state["chains"]:
            state["chains"][chain_key] = _empty_chain_state()
        return state["chains"][chain_key]

    def _check_month_boundary(self) -> None:
        """Reset monthly counters if we've crossed into a new month.
        Caller must hold the lock."""
        current_month = datetime.now(timezone.utc).strftime("%Y-%m")
        stored_month = self._state.get("month", "")
        if stored_month and current_month < stored_month:
            logger.critical(
                "Month went BACKWARD: %s → %s — activating kill switch",
                stored_month, current_month,
            )
            state = copy.deepcopy(self._state)
            state["kill_switch_active"] = True
            self._save_state(state)
            self._state = state
            return  # kill switch will block subsequent operations
        if stored_month != current_month:
            # P2-01: If a clock anomaly was previously detected and persisted,
            # block the reset until we can verify clock recovery.
            if self._state.get("clock_anomaly_detected"):
                logger.critical(
                    "Month change %s → %s BLOCKED: persisted clock anomaly "
                    "flag active — requires manual review or clock recovery",
                    stored_month, current_month,
                )
                return  # Do NOT reset — anomaly flag survives restart
            # P2-01/P2-12: Cross-check wall-clock vs monotonic elapsed time.
            # A forward clock jump would show large wall-clock elapsed with
            # small monotonic elapsed. Compare the two: if wall time advanced
            # much more than monotonic time, the month change is suspicious.
            mono_elapsed = time.monotonic() - self._mono_init
            wall_elapsed = time.time() - self._wall_init
            if stored_month:
                # Wall-to-monotonic divergence: how much extra wall time elapsed
                # beyond real elapsed time. Legitimate NTP drift is small (< 1h).
                divergence = wall_elapsed - mono_elapsed
                if divergence > 3600:
                    # Wall clock jumped forward by more than 1 hour beyond
                    # monotonic time — this is a clock adjustment, not real
                    # elapsed time. Block the reset AND persist the anomaly.
                    logger.critical(
                        "Month change %s → %s BLOCKED: wall-clock divergence "
                        "%.0fs (wall_elapsed=%.0fs, mono_elapsed=%.0fs) — "
                        "clock jump suspected, persisting anomaly flag",
                        stored_month, current_month, divergence,
                        wall_elapsed, mono_elapsed,
                    )
                    # P2-01: Persist the anomaly so restart can't erase it
                    state = copy.deepcopy(self._state)
                    state["clock_anomaly_detected"] = True
                    state["clock_anomaly_detail"] = (
                        f"Blocked month reset {stored_month}→{current_month}: "
                        f"divergence={divergence:.0f}s"
                    )
                    self._save_state(state)
                    self._state = state
                    return  # Do NOT reset — budgets preserved
            self._reset_monthly_locked()

    # -- Pause logic (internal, caller must hold lock) ------------------------

    def _is_paused_locked(self, chain_key: str) -> bool:
        """Check and potentially clear expired auto-pause. Caller must hold lock."""
        chain = self._state.get("chains", {}).get(chain_key)
        if chain is None:
            return False
        if chain["consecutive_failures"] < MAX_CONSECUTIVE_FAILURES:
            return False
        # P2-13: Use monotonic time when available (in-process failure).
        # Falls back to wall-clock for persisted timestamps from previous runs.
        mono_lft = self._mono_last_failure.get(chain_key)
        if mono_lft is not None:
            # In-process failure — use monotonic elapsed (immune to clock jumps)
            elapsed = time.monotonic() - mono_lft
        else:
            # Persisted from a previous run — use wall clock with safeguards
            lft = chain.get("last_failure_time")
            if isinstance(lft, bool) or not isinstance(lft, (int, float)) or lft <= 0:
                return True  # Invalid timestamp — keep paused
            elapsed = time.time() - lft
            # A33: Negative elapsed means clock went backward — keep pause active.
            if elapsed < 0:
                return True
            # P2-13: Cross-check: if wall-clock says expired but we just started,
            # the clock may have jumped. Use process uptime as sanity check.
            process_uptime = time.monotonic() - self._mono_init
            if elapsed >= AUTO_PAUSE_SECONDS and process_uptime < AUTO_PAUSE_SECONDS:
                # Process hasn't been running long enough for a real hour to pass
                # This could be a clock jump — keep paused conservatively
                logger.warning(
                    "Pause for %s: wall-clock says %.0fs elapsed but process "
                    "uptime only %.0fs — keeping paused (possible clock jump)",
                    chain_key, elapsed, process_uptime,
                )
                return True
        if elapsed >= AUTO_PAUSE_SECONDS:
            # Pause expired -- reset consecutive failures (copy-on-write)
            state = copy.deepcopy(self._state)
            state["chains"][chain_key]["consecutive_failures"] = 0
            state["chains"][chain_key]["recent_outcomes"] = []
            self._save_state(state)
            self._state = state
            self._mono_last_failure.pop(chain_key, None)
            return False
        return True

    # -- Public API -----------------------------------------------------------

    def reserve_and_check(
        self, chain_key: str, estimated_gas_usd: float
    ) -> ReservationResult:
        """
        Atomically check budget and reserve estimated gas in one locked operation.

        Returns ReservationResult with approved=True and a reservation_id if allowed.
        The estimated gas is immediately deducted from chain and global budgets.
        Call settle() with the reservation_id once the TX completes or fails.

        P1-12: Acquires dispatch_lock before self._lock to serialize any
        potential _save_state failure with dispatch authorization.

        This eliminates the race condition between can_execute() and record_attempt().
        """
        _validate_amount(estimated_gas_usd, "estimated_gas_usd")
        estimated_gas_usd = round(estimated_gas_usd, 6)
        # P2-10: Validate chain_key at runtime (same rules as load-time)
        if not chain_key or not isinstance(chain_key, str):
            raise ValueError(f"Invalid chain_key: {chain_key!r}")

        if self._dispatch_lock is not None:
            self._dispatch_lock.acquire()
        try:
          with self._lock:
            self._check_open()
            self._check_month_boundary()

            # Kill switch
            if self._state.get("kill_switch_active", False):
                return ReservationResult(
                    approved=False, reservation_id="", reason="kill_switch_active"
                )

            # Per-TX gas limit
            if estimated_gas_usd > MAX_GAS_PER_TX_USD:
                return ReservationResult(
                    approved=False,
                    reservation_id="",
                    reason=f"estimated_gas {estimated_gas_usd:.4f} > per-TX limit {MAX_GAS_PER_TX_USD}",
                )

            # Global monthly net-loss check (actual gas - profit > limit)
            # Use estimated for unsettled + actual for settled
            effective_gas = max(
                self._state["monthly_total_gas_actual"],
                self._state["monthly_total_gas_estimated"],
            )
            net_loss = effective_gas - self._state["monthly_total_profit"]
            if net_loss + estimated_gas_usd > MAX_GLOBAL_MONTHLY_LOSSES_USD:
                return ReservationResult(
                    approved=False,
                    reservation_id="",
                    reason=f"global net loss {net_loss:.2f} + est {estimated_gas_usd:.4f} > limit {MAX_GLOBAL_MONTHLY_LOSSES_USD}",
                )

            # Read chain data without mutating live state
            chain = self._state.get("chains", {}).get(chain_key, _empty_chain_state())

            # Per-chain monthly spend limit (use estimated as budget ceiling)
            if chain["monthly_gas_estimated"] + estimated_gas_usd > MAX_MONTHLY_PER_CHAIN_USD:
                return ReservationResult(
                    approved=False,
                    reservation_id="",
                    reason=f"chain {chain_key} monthly gas {chain['monthly_gas_estimated']:.2f} + {estimated_gas_usd:.4f} > {MAX_MONTHLY_PER_CHAIN_USD}",
                )

            # Check is_paused FIRST (clears expired pauses),
            # THEN check consecutive_failures.
            if self._is_paused_locked(chain_key):
                return ReservationResult(
                    approved=False,
                    reservation_id="",
                    reason=f"chain {chain_key} auto-paused",
                )

            # _is_paused_locked may have done copy-on-write, replacing
            # self._state. Refresh local references so we don't use stale data.
            state = copy.deepcopy(self._state)
            chain = state.get("chains", {}).get(chain_key, _empty_chain_state())

            # After pause check (which may have cleared failures), re-check
            if chain["consecutive_failures"] >= MAX_CONSECUTIVE_FAILURES:
                return ReservationResult(
                    approved=False,
                    reservation_id="",
                    reason=f"chain {chain_key} has {chain['consecutive_failures']} consecutive failures",
                )

            # --- All checks passed. Reserve atomically on the copy. ---
            # `state` is already a deepcopy from above (post-pause refresh).
            reservation_id = uuid.uuid4().hex[:16]

            # Ensure chain exists in our copy (may be absent if _empty_chain_state
            # was returned from .get() above).
            if chain_key not in state["chains"]:
                state["chains"][chain_key] = _empty_chain_state()
            s_chain = state["chains"][chain_key]
            s_chain["total_attempts"] += 1
            s_chain["monthly_gas_estimated"] = round(s_chain["monthly_gas_estimated"] + estimated_gas_usd, 6)
            state["monthly_total_gas_estimated"] = round(state["monthly_total_gas_estimated"] + estimated_gas_usd, 6)

            # Assign monotonic sequence number for submission ordering.
            # Used by settle() to compute the trailing failure streak
            # correctly regardless of settlement order.
            seq = state.get("reservation_sequence", 0) + 1
            state["reservation_sequence"] = seq

            # Store reservation for settlement
            state["reservations"][reservation_id] = {
                "chain_key": chain_key,
                "estimated_gas_usd": estimated_gas_usd,
                "timestamp": time.time(),
                "sequence": seq,
                "settled": False,
                "tx_hash": None,
                "nonce": None,
                "submission_state": "pending",
            }

            self._save_state(state)
            self._state = state  # commit to memory only after disk write

            return ReservationResult(
                approved=True, reservation_id=reservation_id
            )
        finally:
            if self._dispatch_lock is not None:
                self._dispatch_lock.release()

    def settle(
        self,
        reservation_id: str,
        actual_gas_usd: float,
        profit_usd: float,
        success: bool,
    ) -> None:
        """
        Settle a previously reserved transaction with actual results.

        - Adjusts accounting: replaces estimated gas with actual gas spent.
        - Records profit if any.
        - Tracks success/failure for consecutive-failure counting.

        Must be called exactly once per reservation_id.

        Acquires the dispatch lock (if registered) to prevent the race where
        a settlement changes safety state between a concurrent thread's gate
        check and dispatch. Both success and failure settlements can affect
        safety: failures trigger pause, successes can exceed budgets or trigger
        _persistence_failed. Lock ordering: dispatch_lock → self._lock
        (same as activate_kill_switch).
        """
        # Acquire dispatch lock for ALL settlements — any settlement can
        # change safety state (budget overrun, persistence failure, pause).
        if self._dispatch_lock is not None:
            self._dispatch_lock.acquire()
        try:
          with self._lock:
            self._check_open()

            # P2-C+P2-08: Wrap the ENTIRE settlement path including validation
            # so ANY exception after confirming the reservation exists latches
            # _persistence_failed — a known on-chain outcome that fails to
            # record is an accounting failure.
            reservation = self._state.get("reservations", {}).get(reservation_id)
            if reservation is None:
                logger.error(
                    "settle() called with unknown reservation_id=%s", reservation_id
                )
                return
            if reservation.get("settled"):
                logger.warning(
                    "settle() called twice for reservation_id=%s — ignoring",
                    reservation_id,
                )
                return

            try:
                # P2-08: Validation inside protected path — if an outstanding
                # reservation has a known on-chain outcome but invalid arguments
                # prevent recording it, we must latch _persistence_failed.
                _validate_amount(actual_gas_usd, "actual_gas_usd")
                _validate_amount(profit_usd, "profit_usd")
                if not isinstance(success, bool):
                    raise ValueError(f"success must be bool, got {type(success).__name__}: {success!r}")

                self._check_month_boundary()

                # Work on a deep copy — only commit to memory after disk write
                state = copy.deepcopy(self._state)
            except Exception as e:
                self._persistence_failed = True
                raise RuntimeError(
                    f"Cannot record settlement — pre-copy/validation failed: {e}. "
                    "Blocking all operations."
                ) from e

            try:
                s_reservation = state["reservations"][reservation_id]

                chain_key = s_reservation["chain_key"]
                estimated = s_reservation["estimated_gas_usd"]
                if chain_key not in state["chains"]:
                    state["chains"][chain_key] = _empty_chain_state()
                s_chain = state["chains"][chain_key]

                # Adjust gas accounting: remove estimated, add actual
                gas_delta = actual_gas_usd - estimated
                s_chain["monthly_gas_estimated"] = round(s_chain["monthly_gas_estimated"] + gas_delta, 6)
                s_chain["monthly_gas_actual"] = round(s_chain["monthly_gas_actual"] + actual_gas_usd, 6)
                state["monthly_total_gas_estimated"] = round(state["monthly_total_gas_estimated"] + gas_delta, 6)
                state["monthly_total_gas_actual"] = round(state["monthly_total_gas_actual"] + actual_gas_usd, 6)
                # P2-07/P2-H: Clamp estimated counters — load tolerance may have
                # accepted small discrepancies that become negative after settlement.
                if s_chain["monthly_gas_estimated"] < 0:
                    s_chain["monthly_gas_estimated"] = 0.0
                if state["monthly_total_gas_estimated"] < 0:
                    state["monthly_total_gas_estimated"] = 0.0

                # Record profit
                if profit_usd > 0:
                    s_chain["monthly_profit"] = round(s_chain["monthly_profit"] + profit_usd, 6)
                    state["monthly_total_profit"] = round(state["monthly_total_profit"] + profit_usd, 6)

                # Track success/failure with submission-order awareness.
                # Outcomes are recorded in an ordered list sorted by sequence
                # number (assigned at reservation time).  The trailing failure
                # streak is recomputed from this ordered list each time, so
                # out-of-order settlement, delayed reconciliation, and clock
                # adjustments cannot produce incorrect consecutive_failures.
                if success:
                    s_chain["total_successes"] += 1
                else:
                    s_chain["last_failure_time"] = time.time()
                    # P2-13: Record monotonic time for in-process pause checks
                    self._mono_last_failure[chain_key] = time.monotonic()

                tx_seq = s_reservation.get("sequence", 0)

                # Migration: if recent_outcomes is missing (pre-sequence state),
                # seed it from existing consecutive_failures so existing failure
                # streaks are preserved through the upgrade.
                if "recent_outcomes" not in s_chain:
                    n = s_chain.get("consecutive_failures", 0)
                    s_chain["recent_outcomes"] = [
                        {"seq": -n + i, "ok": False} for i in range(n)
                    ]

                # Legacy reservation fix: reservations without a sequence field
                # were created before the ordering system.  Assign them a
                # sequence WELL BEFORE all seeded failures so they cannot reset
                # a pre-existing failure streak by sorting into a later position.
                # Use min - 100 to guarantee placement before seeded entries
                # (which start at -n, -n+1, ..., -1).
                if "sequence" not in s_reservation:
                    existing_seqs = [e["seq"] for e in s_chain["recent_outcomes"]] if s_chain["recent_outcomes"] else [0]
                    tx_seq = min(existing_seqs) - 100
                    s_reservation["sequence"] = tx_seq

                outcomes = s_chain["recent_outcomes"]
                outcomes.append({"seq": tx_seq, "ok": success})
                outcomes.sort(key=lambda x: x["seq"])
                # Keep bounded (10 most recent — well above MAX_CONSECUTIVE_FAILURES)
                if len(outcomes) > 10:
                    outcomes[:] = outcomes[-10:]

                # Recompute trailing failure streak from submission order
                streak = 0
                for entry in reversed(outcomes):
                    if not entry["ok"]:
                        streak += 1
                    else:
                        break
                s_chain["consecutive_failures"] = streak

                # Mark reservation settled and terminal
                s_reservation["settled"] = True
                s_reservation["submission_state"] = "confirmed"  # F30: settle is the only path to terminal
                s_reservation["actual_gas_usd"] = actual_gas_usd
                s_reservation["profit_usd"] = profit_usd
                s_reservation["success"] = success

                # P2-07: Validate aggregates before commit — reject nonfinite results
                for agg_key in ("monthly_total_gas_actual", "monthly_total_gas_estimated",
                                "monthly_total_profit"):
                    agg_val = state.get(agg_key, 0)
                    if isinstance(agg_val, float) and not math.isfinite(agg_val):
                        self._persistence_failed = True
                        raise ValueError(
                            f"Aggregate {agg_key} became {agg_val} after settlement — "
                            "blocking all operations"
                        )

                self._save_state(state)
                self._state = state  # commit to memory only after disk write
            except Exception as e:
                # P2-C: Any failure to record a known on-chain outcome is an
                # accounting failure — latch _persistence_failed to block
                # all subsequent operations.
                if not self._persistence_failed:
                    self._persistence_failed = True
                    logger.critical(
                        "Settlement recording failed for %s: %s — "
                        "blocking all operations", reservation_id, e,
                    )
                raise
        finally:
            if self._dispatch_lock is not None:
                self._dispatch_lock.release()

    def update_reservation(
        self, reservation_id: str, new_estimated_gas_usd: float
    ) -> bool:
        """Update reservation's gas estimate with more accurate post-estimation value.

        Called after gas estimation produces a real cost but before the TX is
        submitted, so the budget reflects the signed TX gas rather than the
        rough pre-estimate.

        P1-12: Acquires dispatch_lock before self._lock — consistent with
        settle(), update_reservation_metadata(), and activate_kill_switch().
        Any _save_state() failure that sets _persistence_failed is serialized
        with dispatch authorization.

        Returns True if the updated reservation is still within limits,
        False if it exceeds them (reservation is NOT modified on failure).
        """
        _validate_amount(new_estimated_gas_usd, "new_estimated_gas_usd")
        new_estimated_gas_usd = round(new_estimated_gas_usd, 6)

        if self._dispatch_lock is not None:
            self._dispatch_lock.acquire()
        try:
          with self._lock:
            self._check_open()
            self._check_month_boundary()

            reservation = self._state.get("reservations", {}).get(reservation_id)
            if reservation is None or reservation.get("settled"):
                return False

            # Fix 5+F26: only allow gas estimate updates for pending TXs.
            # Broadcasting is excluded — the relay may already have the TX,
            # so reducing the budget hold could under-account actual spend.
            if reservation.get("submission_state") not in ("pending", None):
                logger.warning(
                    "Cannot update reservation %s — TX already at relay or beyond (state=%s)",
                    reservation_id, reservation.get("submission_state"),
                )
                return False
            # F26: never allow reducing to zero — that would release the
            # entire budget hold on a potentially executable transaction.
            if new_estimated_gas_usd == 0:
                logger.warning(
                    "Cannot update reservation %s to $0 — use cancel_reservation instead",
                    reservation_id,
                )
                return False

            old_estimate = reservation["estimated_gas_usd"]
            delta = new_estimated_gas_usd - old_estimate
            chain_key = reservation["chain_key"]
            # Read chain data without mutating live state
            chain = self._state.get("chains", {}).get(chain_key, _empty_chain_state())

            # Full policy revalidation (not just per-chain)
            if self._state.get("kill_switch_active", False):
                return False
            if self._is_paused_locked(chain_key):
                return False
            if new_estimated_gas_usd > MAX_GAS_PER_TX_USD:
                return False
            if chain["monthly_gas_estimated"] + delta > MAX_MONTHLY_PER_CHAIN_USD:
                return False
            # Global monthly check
            effective_gas = max(
                self._state["monthly_total_gas_actual"],
                self._state["monthly_total_gas_estimated"],
            )
            net_loss = effective_gas - self._state["monthly_total_profit"]
            if net_loss + delta > MAX_GLOBAL_MONTHLY_LOSSES_USD:
                return False

            # Work on a deep copy — only commit to memory after disk write
            state = copy.deepcopy(self._state)
            s_reservation = state["reservations"][reservation_id]
            self._ensure_chain(state, chain_key)
            s_chain = state["chains"][chain_key]

            s_reservation["estimated_gas_usd"] = new_estimated_gas_usd
            s_chain["monthly_gas_estimated"] = round(s_chain["monthly_gas_estimated"] + delta, 6)
            state["monthly_total_gas_estimated"] = round(state["monthly_total_gas_estimated"] + delta, 6)
            # P2-07: Clamp to zero for load-tolerance discrepancies
            if s_chain["monthly_gas_estimated"] < 0:
                s_chain["monthly_gas_estimated"] = 0.0
            if state["monthly_total_gas_estimated"] < 0:
                state["monthly_total_gas_estimated"] = 0.0

            self._save_state(state)
            self._state = state  # commit to memory only after disk write
            return True
        finally:
            if self._dispatch_lock is not None:
                self._dispatch_lock.release()

    def update_reservation_metadata(
        self,
        reservation_id: str,
        tx_hash: str | None = None,
        nonce: int | None = None,
        submission_state: str | None = None,
        borrower: str | None = None,
        market_id: str | None = None,
        receipt_status: int | None = None,
        settle_amount_known: float | None = None,
        profit_known: float | None = None,
        **extra_fields,
    ) -> bool:
        """Update metadata fields on an existing reservation.

        Used by callers to record tx_hash, nonce, submission_state,
        borrower, market_id, receipt outcome, and additional context
        (sender, loan_decimals, loan_price_usd, receipt_block, etc.)
        after a transaction is submitted, confirmed, or when settlement
        persistence fails.

        P1-12: Acquires dispatch_lock before self._lock — same ordering as
        settle() and activate_kill_switch(). This ensures that if _save_state()
        fails and sets _persistence_failed, the dispatch lock is already held,
        preventing any concurrent thread from dispatching between its safety
        gate check and relay submission.

        Returns True if the reservation was found and updated, False otherwise.
        """
        if self._dispatch_lock is not None:
            self._dispatch_lock.acquire()
        try:
          with self._lock:
            self._check_open()
            reservation = self._state.get("reservations", {}).get(reservation_id)
            if reservation is None:
                logger.error(
                    "update_reservation_metadata() called with unknown "
                    "reservation_id=%s",
                    reservation_id,
                )
                return False

            # Fix 3: enforce state machine — only forward transitions allowed
            # "confirmed" is terminal and must only be reached via settle(),
            # never via metadata updates.
            if submission_state is not None:
                if submission_state == "confirmed":
                    logger.warning(
                        "Cannot set submission_state to 'confirmed' via metadata — "
                        "use settle() instead (reservation %s)", reservation_id,
                    )
                    return False
                current_state = reservation.get("submission_state", "pending")
                allowed = VALID_TRANSITIONS.get(current_state, set())
                if submission_state not in allowed:
                    logger.warning(
                        "Invalid state transition %s → %s for reservation %s",
                        current_state, submission_state, reservation_id,
                    )
                    return False
                # F50+F29: Transitioning to broadcasting/submitted requires
                # both tx_hash AND nonce (either already stored or being set).
                # Without nonce, nonce-based recovery is impossible.
                if submission_state in ("broadcasting", "submitted"):
                    effective_hash = tx_hash or reservation.get("tx_hash")
                    effective_nonce = nonce if nonce is not None else reservation.get("nonce")
                    if not effective_hash:
                        logger.warning(
                            "Cannot transition to %s without tx_hash for reservation %s",
                            submission_state, reservation_id,
                        )
                        return False
                    if effective_nonce is None:
                        logger.warning(
                            "Cannot transition to %s without nonce for reservation %s",
                            submission_state, reservation_id,
                        )
                        return False

            # Block metadata updates on settled reservations (F52)
            if reservation.get("settled"):
                logger.warning(
                    "update_reservation_metadata() called on settled reservation_id=%s — ignoring",
                    reservation_id,
                )
                return False

            # Work on a deep copy — only commit to memory after disk write
            state = copy.deepcopy(self._state)
            s_reservation = state["reservations"][reservation_id]
            # A31+A38: Validate and normalize tx_hash.
            # web3/HexBytes may return bare hex (no 0x prefix) — normalize first.
            if tx_hash is not None:
                if not isinstance(tx_hash, str) or not tx_hash:
                    logger.warning(
                        "Invalid tx_hash type %s=%r for reservation %s",
                        type(tx_hash).__name__, tx_hash, reservation_id,
                    )
                    return False
                # A38: Normalize bare hex to 0x-prefixed
                if re.fullmatch(r'[0-9a-fA-F]{64}', tx_hash):
                    tx_hash = "0x" + tx_hash
                if not re.fullmatch(r'0x[0-9a-fA-F]{64}', tx_hash):
                    logger.warning(
                        "Invalid tx_hash format %r for reservation %s — expected 0x + 64 hex chars",
                        tx_hash, reservation_id,
                    )
                    return False
            # A25: Validate nonce — must be non-negative int, not bool/str/negative.
            if nonce is not None:
                if isinstance(nonce, bool) or not isinstance(nonce, int) or nonce < 0:
                    logger.warning(
                        "Invalid nonce %s=%r for reservation %s",
                        type(nonce).__name__, nonce, reservation_id,
                    )
                    return False
            # A39: Setting tx_hash requires nonce in the same call or already stored.
            # Without nonce, the reservation stays pending and becomes cancellable
            # despite representing a possibly-live transaction.
            if tx_hash is not None and s_reservation.get("tx_hash") is None:
                effective_nonce_for_hash = nonce if nonce is not None else s_reservation.get("nonce")
                if effective_nonce_for_hash is None:
                    logger.warning(
                        "Rejecting tx_hash without nonce for reservation %s — "
                        "would leave hash-bearing TX cancellable",
                        reservation_id,
                    )
                    return False
            # F44: tx_hash and nonce are immutable once set — prevent overwrites
            # that could create phantom TXs or orphan the real one.
            # R08: Canonicalize both sides before comparison to accept equivalent
            # representations (bare hex vs 0x-prefixed).
            if tx_hash is not None:
                if "tx_hash" in s_reservation and s_reservation["tx_hash"] is not None:
                    stored_canon = s_reservation["tx_hash"].lower().removeprefix("0x")
                    new_canon = tx_hash.lower().removeprefix("0x")
                    if stored_canon != new_canon:
                        logger.warning(
                            "Refusing tx_hash overwrite %s → %s for reservation %s",
                            s_reservation["tx_hash"], tx_hash, reservation_id,
                        )
                        return False
                s_reservation["tx_hash"] = tx_hash
            if nonce is not None:
                if "nonce" in s_reservation and s_reservation["nonce"] is not None:
                    if s_reservation["nonce"] != nonce:
                        logger.warning(
                            "Refusing nonce overwrite %s → %s for reservation %s",
                            s_reservation["nonce"], nonce, reservation_id,
                        )
                        return False
                s_reservation["nonce"] = nonce
            if submission_state is not None:
                s_reservation["submission_state"] = submission_state
            # A22: If tx_hash was set/provided but state is still pending/null,
            # auto-promote to broadcasting to prevent orphan-cleanup cancellation.
            # A34: Auto-promotion requires BOTH tx_hash AND nonce — without nonce,
            # nonce-based recovery is impossible and restart triggers kill switch.
            effective_state = s_reservation.get("submission_state")
            if effective_state in ("pending", None) and s_reservation.get("tx_hash"):
                effective_nonce = s_reservation.get("nonce")
                if effective_nonce is not None and isinstance(effective_nonce, int) and not isinstance(effective_nonce, bool) and effective_nonce >= 0:
                    s_reservation["submission_state"] = "broadcasting"
                else:
                    logger.warning(
                        "Cannot auto-promote to broadcasting without valid nonce for reservation %s (nonce=%r)",
                        reservation_id, effective_nonce,
                    )
            # F15: borrower and market_id are immutable once set — changing
            # borrower after broadcast lets the original be submitted again;
            # changing market_id corrupts accounting attribution.
            # P2-E: Validate borrower/market_id type before storing — non-string
            # values would crash duplicate checks (.lower() on list, etc.)
            if borrower is not None:
                if not isinstance(borrower, str) or not borrower:
                    logger.warning(
                        "Invalid borrower type %s=%r for reservation %s",
                        type(borrower).__name__, borrower, reservation_id,
                    )
                    return False
                if "borrower" in s_reservation and s_reservation["borrower"] is not None:
                    if s_reservation["borrower"].lower() != borrower.lower():
                        logger.warning(
                            "Refusing borrower overwrite for reservation %s",
                            reservation_id,
                        )
                        return False
                s_reservation["borrower"] = borrower
            if market_id is not None:
                if not isinstance(market_id, str) or not market_id:
                    logger.warning(
                        "Invalid market_id type %s=%r for reservation %s",
                        type(market_id).__name__, market_id, reservation_id,
                    )
                    return False
                if "market_id" in s_reservation and s_reservation["market_id"] is not None:
                    if s_reservation["market_id"].lower() != market_id.lower():
                        logger.warning(
                            "Refusing market_id overwrite for reservation %s",
                            reservation_id,
                        )
                        return False
                s_reservation["market_id"] = market_id
            # P2-02: Validate and deep-copy named receipt metadata to prevent
            # aliasing and type confusion.
            if receipt_status is not None:
                if not isinstance(receipt_status, int) or isinstance(receipt_status, bool):
                    logger.warning(
                        "Invalid receipt_status type %s=%r for reservation %s",
                        type(receipt_status).__name__, receipt_status, reservation_id,
                    )
                    return False
                s_reservation["receipt_status"] = receipt_status
            if settle_amount_known is not None:
                if (isinstance(settle_amount_known, bool)
                        or not isinstance(settle_amount_known, (int, float))
                        or (isinstance(settle_amount_known, float) and not math.isfinite(settle_amount_known))
                        or settle_amount_known < 0):
                    logger.warning(
                        "Invalid settle_amount_known=%r for reservation %s",
                        settle_amount_known, reservation_id,
                    )
                    return False
                s_reservation["settle_amount_known"] = float(settle_amount_known)
            if profit_known is not None:
                if (isinstance(profit_known, bool)
                        or not isinstance(profit_known, (int, float))
                        or (isinstance(profit_known, float) and not math.isfinite(profit_known))
                        or profit_known < 0):
                    logger.warning(
                        "Invalid profit_known=%r for reservation %s",
                        profit_known, reservation_id,
                    )
                    return False
                s_reservation["profit_known"] = float(profit_known)
            # Store any additional metadata fields (sender, loan_decimals,
            # receipt_block, etc.)
            # NEVER allow overwriting accounting-critical fields via metadata.
            _PROTECTED_FIELDS = frozenset({
                "estimated_gas_usd", "chain", "chain_key", "id",
                "reservation_id", "created_at", "amount", "settled",
                "sequence", "timestamp", "age_seconds",
                "tx_hash", "nonce", "borrower", "market_id",  # handled above
            })
            # F15+A24: Critical valuation/identity fields are immutable once set.
            # loan_price_usd/loan_decimals: prevent profit inflation.
            # sender: prevents nonce-recovery misdirection.
            # flash_liquidator_addr: prevents event authentication hijack.
            _IMMUTABLE_EXTRA = {"loan_price_usd", "loan_decimals", "sender", "flash_liquidator_addr", "chain_id",
                                "tx_type", "max_fee_per_gas", "max_priority_fee_per_gas", "gas_limit"}
            # A31: Address fields must be valid Ethereum addresses (0x + 40 hex).
            _ADDRESS_FIELDS = {"sender", "flash_liquidator_addr"}
            # A26: Validate valuation fields before storing
            _NUMERIC_FIELDS = {"loan_price_usd", "loan_decimals"}
            # P1-10: chain_id must be a positive int, not bool/float/negative
            _CHAIN_ID_FIELD = "chain_id"
            for key, value in extra_fields.items():
                if value is not None and key not in _PROTECTED_FIELDS:
                    # P1-10: Validate chain_id — must be a positive integer
                    if key == _CHAIN_ID_FIELD:
                        if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
                            logger.warning(
                                "Rejecting invalid chain_id=%r for reservation %s",
                                value, reservation_id,
                            )
                            return False
                    # A31: Validate address format for identity fields
                    if key in _ADDRESS_FIELDS:
                        if not isinstance(value, str) or not re.fullmatch(r'0x[0-9a-fA-F]{40}', value):
                            logger.warning(
                                "Rejecting invalid %s=%r for reservation %s — expected 0x + 40 hex chars",
                                key, value, reservation_id,
                            )
                            return False
                    # Validate numeric metadata
                    if key in _NUMERIC_FIELDS:
                        if (isinstance(value, bool) or not isinstance(value, (int, float))
                                or (isinstance(value, float) and not math.isfinite(value))
                                or value < 0):
                            logger.warning(
                                "Rejecting invalid %s=%r for reservation %s",
                                key, value, reservation_id,
                            )
                            return False
                        # A26: loan_price_usd=0 causes zero profit; loan_decimals must be int
                        if key == "loan_price_usd" and value == 0:
                            logger.warning(
                                "Rejecting zero loan_price_usd for reservation %s", reservation_id,
                            )
                            return False
                        if key == "loan_decimals" and not isinstance(value, int):
                            logger.warning(
                                "Rejecting non-integer loan_decimals=%r for reservation %s",
                                value, reservation_id,
                            )
                            return False
                    if key in _IMMUTABLE_EXTRA and key in s_reservation and s_reservation[key] is not None:
                        if s_reservation[key] != value:
                            logger.warning(
                                "Refusing %s overwrite %r → %r for reservation %s",
                                key, s_reservation[key], value, reservation_id,
                            )
                            return False
                    # P2-08: Deep-copy mutable values to prevent aliasing
                    s_reservation[key] = copy.deepcopy(value)

            # A36+A37: Validate required fields for active states at runtime.
            # Same rules as load-time: active reservations need valuation
            # metadata and sender to prevent permanent zero-profit and
            # nonce-recovery misdirection.
            final_state = s_reservation.get("submission_state")
            if final_state in ("broadcasting", "submitted", "nonce_consumed_unresolved", "receipt_known"):
                for req_field in ("loan_price_usd", "loan_decimals"):
                    if s_reservation.get(req_field) is None:
                        logger.warning(
                            "Reservation %s in state %s missing %s — "
                            "rejecting update (would cause permanent $0 profit)",
                            reservation_id, final_state, req_field,
                        )
                        return False
                if not s_reservation.get("sender") or not isinstance(s_reservation.get("sender"), str):
                    logger.warning(
                        "Reservation %s in state %s missing sender — "
                        "rejecting update (would misdirect nonce recovery)",
                        reservation_id, final_state,
                    )
                    return False

            self._save_state(state)
            self._state = state  # commit to memory only after disk write
            return True
        finally:
            if self._dispatch_lock is not None:
                self._dispatch_lock.release()

    def is_paused(self, chain_key: str) -> bool:
        """
        Check if a chain is auto-paused due to recent failures.
        Auto-pause lasts 1 hour after the last failure when 3+ consecutive
        failures have occurred. Clears the pause if expired.
        """
        with self._lock:
            self._check_open()
            return self._is_paused_locked(chain_key)

    def pre_submission_safe(self, chain_key: str) -> tuple[bool, str]:
        """Atomic pre-submission safety gate: kill switch + chain pause + budget in one lock.

        Returns (safe, reason).  safe=True means OK to submit.
        Acquiring the lock once prevents TOCTOU between separate
        get_status() and is_paused() calls.  Also re-checks global
        budget (F36) — another settlement may have pushed actuals
        past the limit while we were signing.
        """
        with self._lock:
            self._check_open()
            self._check_month_boundary()
            if self._state.get("kill_switch_active", False):
                return False, "kill_switch_active"
            if self._is_paused_locked(chain_key):
                return False, "chain_paused"
            # F36: re-check global budget — actuals may have grown
            effective_gas = max(
                self._state.get("monthly_total_gas_actual", 0),
                self._state.get("monthly_total_gas_estimated", 0),
            )
            net_loss = effective_gas - self._state.get("monthly_total_profit", 0)
            # P2-11: Use > (not >=) — this reservation's hold is already
            # included in estimated gas, so equality means exactly at limit.
            if net_loss > MAX_GLOBAL_MONTHLY_LOSSES_USD:
                return False, "global_budget_exceeded"
            # Per-chain budget
            chain = self._state.get("chains", {}).get(chain_key)
            if chain and chain.get("monthly_gas_estimated", 0) > MAX_MONTHLY_PER_CHAIN_USD:
                return False, "chain_budget_exceeded"
            return True, ""

    def _reset_monthly_locked(self) -> None:
        """Reset all monthly counters. Caller MUST hold the lock."""
        state = copy.deepcopy(self._state)
        current_month = datetime.now(timezone.utc).strftime("%Y-%m")
        state["month"] = current_month
        state["monthly_total_gas_estimated"] = 0.0
        state["monthly_total_gas_actual"] = 0.0
        state["monthly_total_profit"] = 0.0
        for chain_data in state.get("chains", {}).values():
            chain_data["monthly_gas_estimated"] = 0.0
            chain_data["monthly_gas_actual"] = 0.0
            chain_data["monthly_profit"] = 0.0
            # NOTE: Do NOT clear recent_outcomes or consecutive_failures here.
            # The circuit breaker tracks operational health independently of
            # monthly financial counters.  A failure streak must persist across
            # month boundaries to prevent unsafe execution.
        # Preserve unsettled reservations across month boundary —
        # they represent potentially live transactions whose gas must
        # still be accounted for. Only remove settled ones.
        unsettled = {
            rid: r for rid, r in state.get("reservations", {}).items()
            if not r.get("settled")
        }
        if unsettled:
            logger.warning(
                "Month rollover: %d unsettled reservations preserved "
                "(potential pending transactions)",
                len(unsettled),
            )
            # Re-add their estimated gas to the new month's budget
            for r in unsettled.values():
                chain_key = r.get("chain_key", "")
                est = r.get("estimated_gas_usd", 0.0)
                if chain_key:
                    if chain_key not in state["chains"]:
                        state["chains"][chain_key] = _empty_chain_state()
                    s_chain = state["chains"][chain_key]
                    s_chain["monthly_gas_estimated"] = round(s_chain["monthly_gas_estimated"] + est, 6)
                state["monthly_total_gas_estimated"] = round(state["monthly_total_gas_estimated"] + est, 6)
        state["reservations"] = unsettled
        self._save_state(state)
        self._state = state

    def reset_monthly(self) -> None:
        """
        Public reset of all monthly counters. Acquires the lock.
        Called automatically at month boundary, or manually by operator.

        P1-12: Acquires dispatch_lock for consistent lock ordering.
        """
        if self._dispatch_lock is not None:
            self._dispatch_lock.acquire()
        try:
            with self._lock:
                self._check_open()
                self._reset_monthly_locked()
        finally:
            if self._dispatch_lock is not None:
                self._dispatch_lock.release()

    def set_dispatch_lock(self, lock: threading.Lock) -> None:
        """Register an external dispatch lock for gate/dispatch serialization.

        This lock is acquired by activate_kill_switch() and pause_chain()
        to prevent the race where a safety state change occurs between
        pre_submission_safe() and relay dispatch. SafeMorphoExecutor holds
        this same lock during dispatch, making the gate check and relay
        submission atomic with respect to safety state changes.
        """
        self._dispatch_lock = lock

    def activate_kill_switch(self) -> None:
        """Activate the global kill switch. All reserve_and_check() calls will be denied.

        Acquires the dispatch lock (if registered) to prevent racing with
        in-flight relay submissions that have already passed the safety gate.
        """
        # Acquire dispatch lock FIRST (outer) to block any concurrent dispatch
        if self._dispatch_lock is not None:
            self._dispatch_lock.acquire()
        try:
            with self._lock:
                self._check_open()
                # Set in-memory FIRST so the switch is active even if disk write fails.
                self._state["kill_switch_active"] = True
                state = copy.deepcopy(self._state)
                try:
                    self._save_state(state)
                    self._state = state
                except Exception:
                    # In-memory switch is already active — log and re-raise
                    logger.critical("KILL SWITCH ACTIVATED in memory but disk write failed!")
                    raise
                logger.warning("KILL SWITCH ACTIVATED — all execution halted")
        finally:
            if self._dispatch_lock is not None:
                self._dispatch_lock.release()

    def deactivate_kill_switch(self) -> None:
        """Deactivate the global kill switch. Execution resumes.

        P1-12: Acquires dispatch_lock for consistent lock ordering.
        """
        if self._dispatch_lock is not None:
            self._dispatch_lock.acquire()
        try:
            with self._lock:
                self._check_open()
                state = copy.deepcopy(self._state)
                state["kill_switch_active"] = False
                self._save_state(state)
                self._state = state
                logger.info("Kill switch deactivated — execution resumed")
        finally:
            if self._dispatch_lock is not None:
                self._dispatch_lock.release()

    def get_status(self) -> dict[str, Any]:
        """Return a snapshot of all chain statuses and global state."""
        with self._lock:
            self._check_open()
            self._check_month_boundary()
            effective_gas = max(
                self._state["monthly_total_gas_actual"],
                self._state["monthly_total_gas_estimated"],
            )
            net_loss = effective_gas - self._state["monthly_total_profit"]
            now = time.time()
            # Expose ALL reservation fields (including dynamically-added
            # metadata like sender, loan_decimals, loan_price_usd,
            # receipt_block) so reconcilers have full context.
            pending_reservation_details = []
            for rid, r in self._state.get("reservations", {}).items():
                if r.get("settled"):
                    continue
                # Copy metadata fields FIRST, then overlay computed fields
                # so computed values always win over any stale metadata (F51).
                _skip = {"chain_key", "estimated_gas_usd", "timestamp",
                         "settled", "sequence", "actual_gas_usd", "profit_usd"}
                # P2-D: Deep-copy to prevent external mutation of live state
                detail = {}
                for k, v in r.items():
                    if k not in _skip:
                        detail[k] = copy.deepcopy(v)
                # Computed fields — ALWAYS override any legacy metadata values
                detail["id"] = rid
                detail["chain"] = r["chain_key"]
                detail["amount"] = r["estimated_gas_usd"]
                detail["age_seconds"] = now - r["timestamp"]
                pending_reservation_details.append(detail)
            # P1-09: Collect settled tx hashes so SettlementDeduplicator
            # can be restored after restart. Only the (chain_id, tx_hash) pairs
            # are needed — full settlement details stay internal.
            settled_tx_hashes = []
            for rid, r in self._state.get("reservations", {}).items():
                if r.get("settled") and r.get("tx_hash"):
                    settled_tx_hashes.append({
                        "chain_id": r.get("chain_id"),
                        "tx_hash": r["tx_hash"],
                    })
            return {
                "month": self._state["month"],
                "monthly_total_gas_estimated": self._state["monthly_total_gas_estimated"],
                "monthly_total_gas_actual": self._state["monthly_total_gas_actual"],
                "monthly_total_profit": self._state["monthly_total_profit"],
                "monthly_net_loss": net_loss,
                "kill_switch_active": self._state.get("kill_switch_active", False),
                "pending_reservation_count": len(pending_reservation_details),
                "pending_reservations": pending_reservation_details,
                "settled_tx_hashes": settled_tx_hashes,
                "chains": {
                    k: copy.deepcopy(v) for k, v in self._state.get("chains", {}).items()
                },
            }

    def cancel_reservation(self, reservation_id: str) -> bool:
        """Cancel a reservation that was never broadcast. Releases budget, no failure recorded.

        Use this for pre-broadcast / preflight failures. The existing settle()
        with success=False is for MINED reverts only — it correctly increments
        consecutive_failures.

        P1-12: Acquires dispatch_lock before self._lock to serialize any
        potential _save_state failure with dispatch authorization.

        Returns True if the reservation was found and cancelled, False otherwise.
        """
        if self._dispatch_lock is not None:
            self._dispatch_lock.acquire()
        try:
          with self._lock:
            self._check_open()
            self._check_month_boundary()

            reservation = self._state.get("reservations", {}).get(reservation_id)
            if reservation is None:
                logger.error(
                    "cancel_reservation() called with unknown reservation_id=%s",
                    reservation_id,
                )
                return False
            if reservation.get("settled"):
                logger.warning(
                    "cancel_reservation() called on already-settled reservation_id=%s — ignoring",
                    reservation_id,
                )
                return False

            # Fix 4: allowlist — only cancel from explicitly safe states.
            # "broadcasting" is NOT included: once metadata says broadcasting,
            # the relay may have already received the TX (e.g., accepted but
            # response timed out). Use abandon_reservation for broadcasting.
            safe_cancel_states = {"pending", None}
            if reservation.get("submission_state") not in safe_cancel_states:
                logger.warning(
                    "Cannot cancel reservation %s — state is '%s'",
                    reservation_id, reservation.get("submission_state"),
                )
                return False
            # A39: Prohibit cancellation when tx_hash exists — the transaction
            # may have been broadcast even if state tracking missed the transition.
            if reservation.get("tx_hash"):
                logger.warning(
                    "Cannot cancel reservation %s — tx_hash exists (%s), TX may be live",
                    reservation_id, reservation["tx_hash"][:18] + "...",
                )
                return False

            chain_key = reservation["chain_key"]
            estimated = reservation["estimated_gas_usd"]

            # Work on a deep copy — only commit to memory after disk write
            state = copy.deepcopy(self._state)
            s_reservation = state["reservations"][reservation_id]
            if chain_key not in state["chains"]:
                state["chains"][chain_key] = _empty_chain_state()
            s_chain = state["chains"][chain_key]

            # Release estimated gas back — no actual gas was spent
            s_chain["monthly_gas_estimated"] = round(s_chain["monthly_gas_estimated"] - estimated, 6)
            state["monthly_total_gas_estimated"] = round(state["monthly_total_gas_estimated"] - estimated, 6)
            # P2-H: Clamp to zero — load tolerance may have accepted small
            # discrepancies that become negative after release.
            if s_chain["monthly_gas_estimated"] < 0:
                s_chain["monthly_gas_estimated"] = 0.0
            if state["monthly_total_gas_estimated"] < 0:
                state["monthly_total_gas_estimated"] = 0.0

            # Mark as settled/cancelled — no failure counters touched
            s_reservation["settled"] = True
            s_reservation["submission_state"] = "cancelled"

            self._save_state(state)
            self._state = state  # commit to memory only after disk write
            return True
        finally:
            if self._dispatch_lock is not None:
                self._dispatch_lock.release()

    def abandon_reservation(self, reservation_id: str) -> bool:
        """Abandon a reservation whose TX was provably never broadcast.

        Unlike cancel_reservation (pending-only) and settle (records outcome),
        this releases budget and marks the reservation terminal WITHOUT
        touching the failure streak or success counters.  Used when startup
        or periodic reconciliation confirms via pending-nonce check that
        a 'broadcasting' reservation never made it to the mempool.

        P1-12: Acquires dispatch_lock before self._lock to serialize any
        potential _save_state failure with dispatch authorization.

        Atomic: transitions directly to confirmed+settled in one disk write.

        Returns True if the reservation was found and abandoned.
        """
        if self._dispatch_lock is not None:
            self._dispatch_lock.acquire()
        try:
          with self._lock:
            self._check_open()
            self._check_month_boundary()

            reservation = self._state.get("reservations", {}).get(reservation_id)
            if reservation is None:
                return False
            if reservation.get("settled"):
                return False

            # Allow abandon from broadcasting, submitted, or nonce_consumed_unresolved.
            # 'submitted' is needed for bundles accepted by the relay but never
            # included (all target blocks passed without inclusion).
            allowed_states = {"broadcasting", "submitted", "nonce_consumed_unresolved", "receipt_known"}
            if reservation.get("submission_state") not in allowed_states:
                logger.warning(
                    "Cannot abandon reservation %s — state is '%s'",
                    reservation_id, reservation.get("submission_state"),
                )
                return False

            chain_key = reservation["chain_key"]
            estimated = reservation["estimated_gas_usd"]

            state = copy.deepcopy(self._state)
            s_reservation = state["reservations"][reservation_id]
            if chain_key not in state["chains"]:
                state["chains"][chain_key] = _empty_chain_state()
            s_chain = state["chains"][chain_key]

            # Release budget — no actual gas was spent on-chain
            s_chain["monthly_gas_estimated"] = round(s_chain["monthly_gas_estimated"] - estimated, 6)
            state["monthly_total_gas_estimated"] = round(state["monthly_total_gas_estimated"] - estimated, 6)
            # P2-H: Clamp to zero — load tolerance may have accepted small discrepancies
            if s_chain["monthly_gas_estimated"] < 0:
                s_chain["monthly_gas_estimated"] = 0.0
            if state["monthly_total_gas_estimated"] < 0:
                state["monthly_total_gas_estimated"] = 0.0

            # Mark terminal — NO outcome recorded (no success, no failure)
            s_reservation["settled"] = True
            s_reservation["actual_gas_usd"] = 0.0
            s_reservation["profit_usd"] = 0.0
            s_reservation["submission_state"] = "confirmed"

            self._save_state(state)
            self._state = state
            logger.info(
                "Abandoned reservation %s (state was '%s') — budget released, "
                "no outcome recorded",
                reservation_id, reservation.get("submission_state", "?"),
            )
            return True
        finally:
            if self._dispatch_lock is not None:
                self._dispatch_lock.release()

    # -- Legacy compatibility -------------------------------------------------
    # These methods broke the new accounting invariant (reserve -> settle).
    # Callers MUST migrate to reserve_and_check() + settle().

    def can_execute(self, chain_key: str, estimated_gas_usd: float) -> bool:
        raise NotImplementedError("DEPRECATED: Use reserve_and_check() instead")

    def record_attempt(self, chain_key: str, gas_cost_usd: float) -> None:
        raise NotImplementedError("DEPRECATED: Use reserve_and_check() instead")

    def record_success(self, chain_key: str, profit_usd: float) -> None:
        raise NotImplementedError("DEPRECATED: Use settle() instead")

    def record_failure(self, chain_key: str, gas_cost_usd: float) -> None:
        raise NotImplementedError("DEPRECATED: Use settle() instead")
