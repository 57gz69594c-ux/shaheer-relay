"""Process-wide execution claims, owned nonce allocations and settlement routing.

Durable transaction ownership lives in GasGuard's reservation journal. Temporary
claims and nonce tokens are process-local; reconstruct them before admission.
"""

import logging
import threading
from typing import Optional, Set, Tuple

logger = logging.getLogger(__name__)
_global_generation = 0
_global_gen_lock = threading.Lock()


def _next_generation() -> int:
    global _global_generation
    with _global_gen_lock:
        _global_generation += 1
        return _global_generation


class ConcurrencyManager:
    """Temporary claims and durable reservation ownership are separate holds."""

    def __init__(self):
        self._lock = threading.RLock()
        self._active_claims = {}
        self._reservations = {}
        self._durable = {}

    @staticmethod
    def _key(chain_key, borrower, market_id):
        return chain_key, borrower.lower(), market_id.lower()

    def try_claim(self, chain_key: str, borrower: str, market_id: str):
        key = self._key(chain_key, borrower, market_id)
        with self._lock:
            if key in self._active_claims or key in self._durable.values():
                return None
            generation = _next_generation()
            self._active_claims[key] = generation
            return (*key, generation)

    def bind(self, claim, reservation_id: str) -> None:
        with self._lock:
            if self._active_claims.get(claim[:3]) != claim[3]:
                raise RuntimeError("Execution claim is no longer owned")
            self._reservations[reservation_id] = claim

    def has_live_claim(self, reservation_id: str) -> bool:
        with self._lock:
            claim = self._reservations.get(reservation_id)
            return bool(claim and self._active_claims.get(claim[:3]) == claim[3])

    def retain(self, claim, reservation_id: str) -> None:
        with self._lock:
            self.bind(claim, reservation_id)
            self._durable[reservation_id] = claim[:3]

    def restore(self, chain_key, borrower, market_id, reservation_id) -> None:
        with self._lock:
            self._durable[reservation_id] = self._key(chain_key, borrower, market_id)

    def resolve(self, reservation_id: str) -> None:
        """Call only after durable final outcome or proven pre-dispatch abort."""
        with self._lock:
            self._durable.pop(reservation_id, None)

    def release(self, claim: Tuple[str, str, str, int]) -> None:
        if claim is None:
            return
        with self._lock:
            if self._active_claims.get(claim[:3]) == claim[3]:
                del self._active_claims[claim[:3]]
            for rid, owner in list(self._reservations.items()):
                if owner == claim:
                    del self._reservations[rid]

    def active_count(self) -> int:
        with self._lock:
            return len(set(self._active_claims) | set(self._durable.values()))


class NonceAllocation:
    """An immutable identity with a manager-controlled, single-use lifecycle."""

    __slots__ = ("_identity", "_consumed")

    def __init__(self, chain_id: int, sender: str, nonce: int, generation: int):
        self._identity = (chain_id, sender.lower(), nonce, generation)
        self._consumed = False

    chain_id = property(lambda self: self._identity[0])
    sender = property(lambda self: self._identity[1])
    nonce = property(lambda self: self._identity[2])
    generation = property(lambda self: self._identity[3])


class NonceManager:
    """Exclusive-sender nonce journal with recoverable gaps.

    Call reconstruct() once per sender before allocate(). A failed reconstruction
    leaves that sender blocked. RPC pending state never releases a durable nonce.
    resync() preserves ownership, including tokens held by active builders.
    """

    def __init__(self):
        self._lock = threading.RLock()
        self._next_nonce = {}
        self._outstanding = {}
        self._durable = {}
        self._gaps = {}
        self._ready = set()

    @staticmethod
    def _nonce(value):
        if type(value) is not int or not 0 <= value < 2**64 - 1:
            raise ValueError("Invalid account nonce")
        return value

    def reconstruct(self, chain_id, sender, nonces, w3, finalized_nonces=()) -> None:
        key = (chain_id, sender.lower())
        with self._lock:
            if key in self._ready:
                return
            pending = self._nonce(w3.eth.get_transaction_count(sender, "pending"))
            finalized = [self._nonce(nonce) for nonce in finalized_nonces]
            if finalized:
                pending = max(pending, max(finalized) + 1)
            self._next_nonce[key] = pending
            self._outstanding[key] = {}
            self._durable[key] = set()
            self._gaps[key] = []
            for nonce in nonces:
                self.ensure_past(chain_id, sender, nonce, w3)
            # Complete journal + exclusive sender ownership proves these gaps
            # were never dispatched by this engine. Represent intervals compactly.
            cursor = pending
            for nonce in sorted(n for n in self._durable[key] if n >= pending):
                if cursor < nonce:
                    self._gaps[key].append((cursor, nonce))
                cursor = nonce + 1
            self._ready.add(key)

    def ensure_past(self, chain_id: int, sender: str, nonce: int, w3) -> None:
        nonce = self._nonce(nonce)
        key = (chain_id, sender.lower())
        with self._lock:
            if key not in self._next_nonce:
                pending = self._nonce(w3.eth.get_transaction_count(sender, "pending"))
                self._next_nonce[key] = pending
                self._outstanding[key] = {}
                self._durable[key] = set()
                self._gaps[key] = []
            self._durable[key].add(nonce)
            self._next_nonce[key] = max(self._next_nonce[key], nonce + 1)
            gaps = []
            for lo, hi in self._gaps[key]:
                if lo <= nonce < hi:
                    if lo < nonce:
                        gaps.append((lo, nonce))
                    if nonce + 1 < hi:
                        gaps.append((nonce + 1, hi))
                else:
                    gaps.append((lo, hi))
            self._gaps[key] = gaps

    def allocate(self, chain_id: int, sender: str, w3) -> NonceAllocation:
        key = (chain_id, sender.lower())
        with self._lock:
            if key not in self._ready:
                raise RuntimeError("Nonce reconstruction has not completed")
            gaps = self._gaps[key]
            if gaps:
                lo, hi = gaps.pop(0)
                nonce = lo
                if lo + 1 < hi:
                    gaps.insert(0, (lo + 1, hi))
            else:
                nonce = self._nonce(self._next_nonce[key])
                self._next_nonce[key] = nonce + 1
            if nonce in self._outstanding[key] or nonce in self._durable[key]:
                self._ready.discard(key)
                raise RuntimeError("Nonce ownership invariant failed")
            allocation = NonceAllocation(chain_id, sender, nonce, _next_generation())
            self._outstanding[key][nonce] = allocation
            return allocation

    def _consume(self, allocation, broadcast):
        if allocation is None:
            return
        key = (allocation.chain_id, allocation.sender)
        with self._lock:
            current = self._outstanding.get(key, {}).get(allocation.nonce)
            if allocation._consumed or current is not allocation:
                return
            if current.generation != allocation.generation:
                return
            del self._outstanding[key][allocation.nonce]
            allocation._consumed = True
            if broadcast:
                self._durable[key].add(allocation.nonce)
            else:
                self._gaps[key].append((allocation.nonce, allocation.nonce + 1))
                self._gaps[key].sort()

    def confirm(self, alloc: NonceAllocation) -> None:
        self._consume(alloc, True)

    def release(self, alloc: NonceAllocation) -> None:
        """Only the owner may release, and only before dispatch was attempted."""
        self._consume(alloc, False)

    def confirm_nonce_value(self, chain_id: int, sender: str, nonce: int) -> None:
        raise RuntimeError("NonceAllocation ownership token required; use confirm()")

    def resync(self, chain_id: int, sender: str, w3) -> int:
        key = (chain_id, sender.lower())
        with self._lock:
            if key not in self._ready:
                raise RuntimeError("Nonce reconstruction has not completed")
            pending = self._nonce(w3.eth.get_transaction_count(sender, "pending"))
            self._next_nonce[key] = max(pending, self._next_nonce[key])
            # A pending nonce is not proof of final consumption. Keep every
            # known gap and all allocation tokens; never clear either on resync.
            return self._gaps[key][0][0] if self._gaps[key] else self._next_nonce[key]


class SettlementDeduplicator:
    """Serialize accounting revisions and attach duplicate reservations.

    The durable guard transaction is authoritative. Even an already-complete
    hash must visit it so a second reservation can release its redundant hold.
    """

    def __init__(self):
        self._lock = threading.RLock()
        self._settled: Set[Tuple[int, str]] = set()
        self._settling: Set[Tuple[int, str]] = set()

    @staticmethod
    def _canonical_hash(tx_hash: str) -> str:
        if isinstance(tx_hash, (bytes, bytearray)):
            tx_hash = bytes(tx_hash).hex()
        if not isinstance(tx_hash, str):
            raise ValueError("Transaction hash must be hex or bytes")
        value = tx_hash.lower()
        if value.startswith("0x"):
            value = value[2:]
        if len(value) != 64 or any(c not in "0123456789abcdef" for c in value):
            raise ValueError("Transaction hash must contain exactly 32 bytes")
        return value

    def settle(self, risk, chain_id, tx_hash, reservation_id,
               actual_gas_usd, profit_usd, success, **evidence) -> dict:
        key = (chain_id, self._canonical_hash(tx_hash))
        # All code uses this ordering, including concurrent gate/dispatch work.
        with risk.dispatch_lock:
            with self._lock:
                result = risk.settle(
                    reservation_id, actual_gas_usd, profit_usd, success,
                    chain_id=chain_id, tx_hash=key[1], **evidence,
                )
                if result["complete"]:
                    self._settled.add(key)
                return result

    def try_claim_settlement(self, chain_id: int, tx_hash: str) -> bool:
        key = (chain_id, self._canonical_hash(tx_hash))
        with self._lock:
            if key in self._settled or key in self._settling:
                return False
            self._settling.add(key)
            return True

    def confirm_settlement(self, chain_id: int, tx_hash: str) -> None:
        key = (chain_id, self._canonical_hash(tx_hash))
        with self._lock:
            self._settling.discard(key)
            self._settled.add(key)

    def release_settlement(self, chain_id: int, tx_hash: str) -> None:
        with self._lock:
            self._settling.discard((chain_id, self._canonical_hash(tx_hash)))

    def is_settled(self, chain_id: int, tx_hash: str) -> bool:
        with self._lock:
            return (chain_id, self._canonical_hash(tx_hash)) in self._settled

    def load_settled(self, settled_set: Set[Tuple[int, str]]) -> None:
        validated = set()
        for chain_id, tx_hash in settled_set:
            if type(chain_id) is not int or chain_id <= 0:
                raise ValueError("Invalid persisted chain ID")
            validated.add((chain_id, self._canonical_hash(tx_hash)))
        with self._lock:
            self._settled.update(validated)
