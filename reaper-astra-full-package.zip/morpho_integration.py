"""Morpho execution with durable, revisable transaction accounting.

Deployment prerequisite: LiquidateParams must append uint256 deadline, and
liquidate() must enforce block.timestamp <= deadline before the flash loan.
Pin the audited, non-proxy runtime bytecode in DEADLINE_CONTRACT_CODE_HASHES.
The legacy eight-field contract cannot enforce this property and is rejected.

OP fee stress budgets are admission limits, not consensus-enforced fee caps.
A Solidity deadline prevents stale liquidation but does not prevent a late
transaction from being included, reverting, and charging gas. Consequently
neither expiry, relay rejection nor node-local absence releases liability.

GasGuard's persistence and policy implementation is retained through the local
subclass below. It adds an atomic transaction-outcome journal and ensures every
inherited state writer takes dispatch_lock before its internal lock.
"""

import copy
import logging
import threading
import time
import traceback
import uuid
from decimal import Decimal, ROUND_CEILING
from typing import Any, Optional

from web3 import Web3
from web3.exceptions import ContractLogicError, TransactionNotFound

from executor.simulator import ProfitSimulator, SimulationResult
from executor.risk import GasGuard
from executor.concurrency import (
    ConcurrencyManager, NonceManager, NonceAllocation, SettlementDeduplicator,
)

logger = logging.getLogger("reaper.morpho.integration")
MAX_INFLIGHT_AGE_SECONDS = 1800  # diagnostic threshold; never a release condition
MIN_CONFIRMATIONS = 15
TRANSACTION_TTL_SECONDS = 120
MAX_PREPARATION_SECONDS = 30
OP_FEE_STRESS_MULTIPLIER = Decimal("2")
MAX_L1_FEE_STRESS_USD = Decimal("0.20")
MAX_OPERATOR_FEE_STRESS_USD = Decimal("0.10")
# {(chain_id, lowercased_contract_address): canonical keccak256(runtime_code)}
DEADLINE_CONTRACT_CODE_HASHES = {}
_DISPATCH_LOCK = threading.RLock()
_PROCESS_ID = uuid.uuid4().hex
# R01: Canonical chain identity mapping. Used to migrate mismatched
# chain_key labels and enforce consistent budget/claims identity.
_CHAIN_ID_TO_KEY = {1: "ethereum", 8453: "base", 10: "optimism", 34443: "mode", 7777777: "zora"}


def _uint(value, bits=256):
    if type(value) is int:
        result = value
    elif isinstance(value, str) and value and len(value) <= 80:
        body = value[2:] if value.startswith(("0x", "0X")) else value
        alphabet = "0123456789abcdefABCDEF" if value.startswith(("0x", "0X")) else "0123456789"
        if not body or any(c not in alphabet for c in body):
            raise ValueError("Malformed unsigned integer")
        result = int(body, 16 if value.startswith(("0x", "0X")) else 10)
    else:
        raise ValueError("Unsigned integer required")
    if not 0 <= result < 2**bits:
        raise ValueError(f"Integer exceeds uint{bits}")
    return result


def _money(value, positive=False):
    if isinstance(value, bool) or not isinstance(value, (int, float, Decimal)):
        raise ValueError("Numeric monetary value required")
    number = Decimal(str(value))
    if not number.is_finite() or number < 0 or (positive and number == 0):
        raise ValueError("Invalid monetary value")
    # GasGuard persists JSON floats; reject values that cannot round-trip finitely.
    result = float(number)
    if not Decimal(str(result)).is_finite():
        raise ValueError("Monetary value exceeds storage range")
    return result


def _hash(value):
    return SettlementDeduplicator._canonical_hash(value)


def _budget(value):
    """Round admission holds upward to GasGuard's six-decimal precision."""
    return _money(Decimal(str(value)).quantize(Decimal("0.000001"), rounding=ROUND_CEILING))


def _bytes(value):
    if isinstance(value, (bytes, bytearray)):
        return bytes(value)
    if isinstance(value, str) and value.startswith("0x"):
        return bytes.fromhex(value[2:])
    raise ValueError("Hex bytes required")


class _OrderedLock:
    """Every inherited 'with self._lock' also enters the dispatch barrier."""

    def __init__(self):
        self.inner = threading.RLock()

    def acquire(self):
        _DISPATCH_LOCK.acquire()
        try:
            return self.inner.acquire()
        except BaseException:
            _DISPATCH_LOCK.release()
            raise

    def release(self):
        self.inner.release()
        _DISPATCH_LOCK.release()

    def __enter__(self):
        self.acquire()
        return self

    def __exit__(self, *exc):
        self.release()


class _DurableGasGuard(GasGuard):
    """Extend the existing file-locked, fsynced guard without a second database.

    'settled' means accounting complete. 'outcome_finalized' independently means
    transaction execution is resolved. Unknown monetary values are None in the
    outcome journal; they are never recorded as actual estimates or final zero.
    """

    dispatch_lock = _DISPATCH_LOCK

    def _load_state(self):
        # Base __init__ calls this before publishing the object.
        self._lock = _OrderedLock()
        self._dispatch_lock = _DISPATCH_LOCK
        with self._lock:
            state = super()._load_state()
            ledger = state.get("transaction_outcomes")
            if state.get("outcome_schema") == 1 and not isinstance(ledger, dict):
                raise RuntimeError("Durable outcome journal is missing or malformed")
            state.setdefault("transaction_outcomes", {})
            for key, outcome in state["transaction_outcomes"].items():
                if not isinstance(outcome, dict):
                    raise RuntimeError("Invalid outcome journal entry")
                expected = self._tx_key(outcome["chain_id"], outcome["tx_hash"])
                if key != expected or type(outcome["success"]) is not bool:
                    raise RuntimeError("Invalid outcome identity")
                for field in ("actual_gas_usd", "profit_usd"):
                    if outcome[field] is not None:
                        _money(outcome[field])
                complete = all(outcome[f] is not None for f in ("actual_gas_usd", "profit_usd"))
                if type(outcome.get("complete")) is not bool or outcome["complete"] != complete:
                    raise RuntimeError("Invalid accounting completeness in outcome journal")
                if not isinstance(outcome.get("reservation"), dict) or not outcome.get("canonical_id"):
                    raise RuntimeError("Outcome journal lost its canonical reservation")
            # R05: Backfill associated_ids for outcomes loaded from legacy
            # journals that lack the field. Match reservations by chain_id + tx_hash.
            for key, outcome in state["transaction_outcomes"].items():
                if "associated_ids" not in outcome:
                    associated = []
                    for rid, reservation in state.get("reservations", {}).items():
                        if (reservation.get("chain_id") == outcome["chain_id"]
                                and reservation.get("tx_hash")
                                and _hash(reservation["tx_hash"]) == _hash(outcome["tx_hash"])):
                            associated.append(rid)
                    outcome["associated_ids"] = associated
            # R01: Migrate persisted chain_key labels to canonical keys based on
            # chain_id. Ensures budgets, claims and reconciliation use consistent
            # identity even when historical data used a different label.
            migration_moves = {}  # old_key → canonical_key
            for rid, reservation in state.get("reservations", {}).items():
                r_chain_id = reservation.get("chain_id")
                if r_chain_id is None or type(r_chain_id) is not int:
                    continue
                canonical_key = _CHAIN_ID_TO_KEY.get(r_chain_id)
                if canonical_key is None:
                    continue
                stored_key = reservation.get("chain_key")
                if stored_key is not None and stored_key != canonical_key:
                    if stored_key not in migration_moves:
                        migration_moves[stored_key] = canonical_key
                    reservation["chain_key"] = canonical_key
                    reservation["chain"] = canonical_key
            # Move chain budget data from old keys to canonical keys
            chains = state.setdefault("chains", {})
            for old_key, new_key in migration_moves.items():
                if old_key in chains:
                    from executor.risk import _empty_chain_state
                    old_chain = chains[old_key]
                    new_chain = chains.setdefault(new_key, _empty_chain_state())
                    for counter in ("monthly_gas_actual", "monthly_profit"):
                        new_chain[counter] = _money(
                            Decimal(str(new_chain[counter])) + Decimal(str(old_chain.get(counter, 0.0))))
                    new_outcomes = new_chain.setdefault("recent_outcomes", [])
                    new_outcomes.extend(old_chain.get("recent_outcomes", []))
                    new_outcomes.sort(key=lambda e: e.get("seq", 0))
                    new_chain["total_successes"] = (
                        new_chain.get("total_successes", 0) + old_chain.get("total_successes", 0))
                    new_chain["consecutive_failures"] = max(
                        new_chain.get("consecutive_failures", 0),
                        old_chain.get("consecutive_failures", 0))
                    if old_chain.get("last_failure_time"):
                        new_chain["last_failure_time"] = max(
                            new_chain.get("last_failure_time", 0), old_chain["last_failure_time"])
                    del chains[old_key]
                    logger.warning("R01: Migrated chain budget %r → %r", old_key, new_key)
            # Also migrate outcome journal chain_key
            for key, outcome in state["transaction_outcomes"].items():
                oc_chain_id = outcome.get("chain_id")
                if oc_chain_id is not None:
                    canonical_key = _CHAIN_ID_TO_KEY.get(oc_chain_id)
                    if canonical_key and outcome.get("chain_key") != canonical_key:
                        outcome["chain_key"] = canonical_key
            # R10: Validate ALL reservations with outcome_finalized against the
            # journal. A finalized reservation with a missing journal entry
            # indicates corruption (e.g. deleted outcome entry), regardless of
            # whether settled is True or False.
            for rid, reservation in state.get("reservations", {}).items():
                if not reservation.get("outcome_finalized"):
                    continue
                if not reservation.get("tx_hash"):
                    continue
                key = self._tx_key(reservation["chain_id"], reservation["tx_hash"])
                if key not in state["transaction_outcomes"]:
                    raise RuntimeError(
                        f"Reservation {rid} claims finalized outcome but "
                        f"journal entry {key} is missing — possible corruption"
                    )
            # Migrate retained, genuinely settled records. Abandonment records
            # lack a success outcome and must not become deduplication evidence.
            for rid, reservation in state.get("reservations", {}).items():
                if not (reservation.get("settled") and reservation.get("tx_hash")
                        and type(reservation.get("success")) is bool):
                    continue
                key = self._tx_key(reservation["chain_id"], reservation["tx_hash"])
                if key not in state["transaction_outcomes"]:
                    state["transaction_outcomes"][key] = {
                        "chain_id": reservation["chain_id"],
                        "tx_hash": _hash(reservation["tx_hash"]),
                        "canonical_id": rid, "chain_key": reservation["chain_key"],
                        "success": reservation["success"],
                        "actual_gas_usd": _money(reservation["actual_gas_usd"]),
                        "profit_usd": _money(reservation["profit_usd"]),
                        "receipt_block_hash": reservation.get("receipt_block_hash"),
                        "complete": True,
                        "reservation": copy.deepcopy(reservation),
                    }
            state["outcome_schema"] = 1
            self._not_dispatched = set()
            self._save_state(state)
            return state

    def set_dispatch_lock(self, lock):
        if lock is not _DISPATCH_LOCK:
            raise ValueError("The dispatch barrier cannot be replaced on a live guard")

    @staticmethod
    def _tx_key(chain_id, tx_hash):
        if type(chain_id) is not int or chain_id <= 0:
            raise ValueError("Invalid chain ID")
        return f"{chain_id}:{_hash(tx_hash)}"

    def _save_state(self, state=None):
        with self._lock:
            try:
                state = self._state if state is None else state
                old_reservations = getattr(self, "_state", {}).get("reservations", {})
                for rid, reservation in state.get("reservations", {}).items():
                    if rid not in old_reservations and reservation.get("submission_state") == "pending":
                        # Reservation creation is not execution ordering.
                        reservation.pop("sequence", None)
                        reservation.setdefault("owner_process", _PROCESS_ID)
                    if reservation.get("tx_hash"):
                        reservation["tx_hash"] = _hash(reservation["tx_hash"])
                # Rebuild the invariant from authoritative actual counters and
                # outstanding holds. Never zero-clamp an incremental subtraction.
                for name, chain in state.get("chains", {}).items():
                    held = sum((Decimal(str(r["estimated_gas_usd"]))
                                for r in state.get("reservations", {}).values()
                                if not r.get("settled") and r["chain_key"] == name), Decimal(0))
                    chain["monthly_gas_estimated"] = _money(
                        Decimal(str(chain["monthly_gas_actual"])) + held)
                state["monthly_total_gas_estimated"] = _money(sum(
                    (Decimal(str(c["monthly_gas_estimated"]))
                     for c in state.get("chains", {}).values()), Decimal(0)))
                super()._save_state(state)
            except BaseException:
                self._persistence_failed = True
                raise

    def get_reservation(self, reservation_id):
        with self._lock:
            self._check_open()
            reservation = self._state["reservations"].get(reservation_id)
            if reservation is None:
                raise KeyError(reservation_id)
            return self._detail(reservation_id, reservation)

    @staticmethod
    def _detail(rid, reservation):
        result = copy.deepcopy(reservation)
        result.update(id=rid, chain=reservation["chain_key"],
                      amount=reservation["estimated_gas_usd"])
        return result

    def canonical_reservation(self, reservation_id):
        with self._lock:
            self._check_open()
            reservation = self._state["reservations"].get(reservation_id)
            if reservation is None:
                # R05: Reservation may have been pruned by month rollover.
                # Check the outcome journal for a durable record.
                for outcome in self._state.get("transaction_outcomes", {}).values():
                    if outcome.get("canonical_id") == reservation_id:
                        return self._detail(reservation_id, outcome["reservation"])
                    for rid in outcome.get("associated_ids", []):
                        if rid == reservation_id:
                            return self._detail(outcome["canonical_id"], outcome["reservation"])
                raise KeyError(f"Reservation {reservation_id} not found in state or journal")
            reservation = self._detail(reservation_id, reservation)
            key = self._tx_key(reservation["chain_id"], reservation["tx_hash"])
            outcome = self._state["transaction_outcomes"].get(key)
            if outcome:
                return self._detail(outcome["canonical_id"], outcome["reservation"])
            candidates = [(r.get("sequence", -1), rid, r)
                          for rid, r in self._state["reservations"].items()
                          if r.get("chain_id") == reservation["chain_id"]
                          and r.get("tx_hash") and _hash(r["tx_hash"]) == _hash(reservation["tx_hash"])
                          and r.get("submission_state") != "cancelled"]
            _, rid, canonical = min(candidates, key=lambda item: (item[0], item[1]))
            return self._detail(rid, canonical)

    def get_status(self):
        with self._lock:
            status = super().get_status()
            # Journal entries survive the base guard's monthly reservation pruning.
            status["settled_tx_hashes"] = [
                {"chain_id": o["chain_id"], "tx_hash": o["tx_hash"]}
                for o in self._state["transaction_outcomes"].values() if o["complete"]]
            status["nonce_ownership"] = [
                {"chain": o["chain_key"], "chain_id": o["chain_id"],
                 "sender": o["reservation"].get("sender"),
                 "nonce": o["reservation"].get("nonce"),
                 "finalized": o.get("receipt_block_hash") is not None}
                for o in self._state["transaction_outcomes"].values()]
            return status

    def update_reservation_metadata(self, reservation_id, *args, **kwargs):
        with self._lock:
            current = self.get_reservation(reservation_id)
            # Protect the additional journal and valuation fields from metadata.
            # R02: Include signed fee fields — they are authenticated at dispatch
            # and must remain immutable to prevent fee-validation bypass.
            protected = {"outcome_finalized", "fee_incomplete", "profit_incomplete",
                         "fee_valid", "actual_gas_usd", "profit_usd", "success",
                         "canonical_id", "reserved_gas_usd", "dispatch_started",
                         "tx_type", "max_fee_per_gas", "max_priority_fee_per_gas",
                         "gas_limit"}
            if protected.intersection(kwargs):
                raise ValueError("Accounting fields require settle()")
            if "native_price_usd" in kwargs:
                value = _money(kwargs["native_price_usd"], positive=True)
                if current.get("native_price_usd") not in (None, value):
                    raise ValueError("Submission valuation is immutable")
                kwargs["native_price_usd"] = value
            return super().update_reservation_metadata(reservation_id, *args, **kwargs)

    def begin_dispatch(self, reservation_id, **metadata):
        with self._lock:
            self._check_open()
            if self.get_reservation(reservation_id)["submission_state"] != "pending":
                raise RuntimeError("Reservation already dispatched")
            self._not_dispatched.add(reservation_id)
            # The metadata validation and sequence change become durable before
            # the relay call while the caller still holds dispatch_lock.
            if not self.update_reservation_metadata(
                    reservation_id, submission_state="broadcasting", **metadata):
                raise RuntimeError("Cannot persist dispatch metadata")
            state = copy.deepcopy(self._state)
            sequences = [r.get("sequence", 0) for r in state["reservations"].values()]
            sequences += [e["seq"] for c in state["chains"].values()
                          for e in c.get("recent_outcomes", [])]
            sequence = max([state.get("reservation_sequence", 0)] + sequences) + 1
            state["reservation_sequence"] = sequence
            state["reservations"][reservation_id].update(
                sequence=sequence, dispatch_started=True, dispatched_at=time.time())
            self._save_state(state)
            self._state = state

    def mark_dispatch_attempted(self, reservation_id):
        with self._lock:
            self._check_open()
            if reservation_id not in self._not_dispatched:
                raise RuntimeError("Dispatch ownership already consumed")
            self._not_dispatched.remove(reservation_id)

    def abort_before_dispatch(self, reservation_id):
        """Consume a process-local proof that the relay was never invoked."""
        with self._lock:
            self._check_open()
            if reservation_id not in self._not_dispatched:
                return False
            state = copy.deepcopy(self._state)
            reservation = state["reservations"][reservation_id]
            if reservation.get("owner_process") != _PROCESS_ID:
                raise RuntimeError("Pre-dispatch abort ownership mismatch")
            reservation.update(settled=True, submission_state="cancelled")
            self._save_state(state)
            self._state = state
            self._not_dispatched.remove(reservation_id)
            return True

    def abandon_reservation(self, reservation_id):
        # No RPC absence/nonce/relay response is an unbroadcast proof.
        return self.cancel_reservation(reservation_id)

    def settle(self, reservation_id, actual_gas_usd, profit_usd, success,
               *, chain_id, tx_hash, receipt_block_hash,
               receipt_block_number=None, receipt_tx_index=None,
               fee_incomplete=False, profit_incomplete=False, fee_valid=True):
        with self._lock:
            self._check_open()
            try:
                if type(success) is not bool:
                    raise ValueError("Validated transaction outcome required")
                if any(type(v) is not bool for v in (fee_incomplete, profit_incomplete, fee_valid)):
                    raise ValueError("Completeness flags must be booleans")
                if fee_incomplete or not fee_valid:
                    actual_gas_usd = None
                else:
                    actual_gas_usd = _money(actual_gas_usd)
                profit_usd = None if profit_incomplete else _money(profit_usd)
                receipt_block_hash = _hash(receipt_block_hash)
                self._check_month_boundary()
                canonical = self.canonical_reservation(reservation_id)
                if canonical["chain_id"] != chain_id or _hash(canonical["tx_hash"]) != _hash(tx_hash):
                    raise ValueError("Settlement identity mismatch")
                state = copy.deepcopy(self._state)
                key = self._tx_key(chain_id, tx_hash)
                ledger = state["transaction_outcomes"]
                new_outcome = key not in ledger
                outcome = ledger.get(key)
                if outcome is None:
                    outcome = {
                        "chain_id": chain_id, "tx_hash": _hash(tx_hash),
                        "canonical_id": canonical["id"], "chain_key": canonical["chain"],
                        "success": success, "actual_gas_usd": None, "profit_usd": None,
                        "receipt_block_hash": receipt_block_hash,
                        "reservation": copy.deepcopy(canonical), "complete": False,
                    }
                    ledger[key] = outcome
                if outcome["success"] != success or outcome.get("receipt_block_hash") not in (None, receipt_block_hash):
                    raise RuntimeError("Conflicting finalized receipt evidence")
                outcome["receipt_block_hash"] = receipt_block_hash
                chain = state["chains"][outcome["chain_key"]]
                gas_delta = profit_delta = 0.0
                revised = False
                for field, value, chain_counter, global_counter in (
                    ("actual_gas_usd", actual_gas_usd, "monthly_gas_actual", "monthly_total_gas_actual"),
                    ("profit_usd", profit_usd, "monthly_profit", "monthly_total_profit"),
                ):
                    previous = outcome[field]
                    if value is None:
                        continue
                    if previous is not None and previous != value:
                        raise RuntimeError(f"Conflicting complete {field} evidence")
                    if previous is None:
                        revised = True
                        outcome[field] = value
                        outcome[field + "_month"] = state["month"]
                        chain[chain_counter] = _money(Decimal(str(chain[chain_counter])) + Decimal(str(value)))
                        state[global_counter] = _money(Decimal(str(state[global_counter])) + Decimal(str(value)))
                        if field == "actual_gas_usd":
                            gas_delta = value
                        else:
                            profit_delta = value
                if new_outcome:
                    if success:
                        chain["total_successes"] += 1
                    else:
                        chain["last_failure_time"] = time.time()
                        self._mono_last_failure[outcome["chain_key"]] = time.monotonic()
                    events = chain.setdefault("recent_outcomes", [])
                    # R09: Derive a plain integer ordering key from block position
                    # when available. This is monotonic and compatible with legacy
                    # integer sequences. block_number * 100000 + tx_index gives
                    # unique ordering across all practical block sizes.
                    if (receipt_block_number is not None and type(receipt_block_number) is int
                            and receipt_tx_index is not None and type(receipt_tx_index) is int):
                        sequence = receipt_block_number * 100000 + receipt_tx_index
                    else:
                        sequence = canonical.get("sequence")
                        if type(sequence) is not int:
                            sequence = min([e.get("seq", 0) for e in events] + [0]) - 1
                    events.append({"seq": sequence, "ok": success})
                    events.sort(key=lambda e: e.get("seq", 0))
                    streak = 0
                    for event in reversed(events):
                        if event["ok"]:
                            break
                        streak += 1
                    # Preserve an already activated pause until its normal expiry.
                    from executor.risk import MAX_CONSECUTIVE_FAILURES
                    old_streak = chain["consecutive_failures"]
                    chain["consecutive_failures"] = (
                        max(old_streak, streak) if old_streak >= MAX_CONSECUTIVE_FAILURES else streak)
                outcome["complete"] = all(outcome[f] is not None for f in ("actual_gas_usd", "profit_usd"))
                associated = list(outcome.get("associated_ids", []))
                for rid, reservation in state["reservations"].items():
                    if reservation.get("chain_id") != chain_id or not reservation.get("tx_hash"):
                        continue
                    if _hash(reservation["tx_hash"]) != _hash(tx_hash):
                        continue
                    if rid not in associated:
                        associated.append(rid)
                    duplicate = rid != outcome["canonical_id"]
                    reservation.setdefault("reserved_gas_usd", reservation["estimated_gas_usd"])
                    reservation.update(
                        canonical_id=outcome["canonical_id"], outcome_finalized=True,
                        fee_incomplete=outcome["actual_gas_usd"] is None,
                        profit_incomplete=outcome["profit_usd"] is None,
                        fee_valid=outcome["actual_gas_usd"] is not None,
                        success=success, receipt_block_hash=receipt_block_hash,
                        settled=duplicate or outcome["complete"],
                        submission_state="confirmed" if duplicate or outcome["complete"] else "receipt_known",
                    )
                    if duplicate or outcome["actual_gas_usd"] is not None:
                        reservation["estimated_gas_usd"] = 0.0
                    if not duplicate:
                        reservation["actual_gas_usd"] = outcome["actual_gas_usd"]
                        reservation["profit_usd"] = outcome["profit_usd"]
                # R05: Persist associated IDs in the outcome journal so they
                # survive reservation pruning during month rollover.
                outcome["associated_ids"] = associated
                self._save_state(state)
                self._state = state
                return {
                    "status": "recorded" if new_outcome else (
                        "revised" if revised else "duplicate"),
                    "complete": outcome["complete"], "new_outcome": new_outcome,
                    "canonical_id": outcome["canonical_id"], "associated_ids": associated,
                    "gas_delta": gas_delta, "profit_delta": profit_delta,
                    "outcome": copy.deepcopy(outcome),
                }
            except BaseException:
                # Includes failed validation/copying, not just failed disk writes.
                self._persistence_failed = True
                raise


_MARKET_COMPONENTS = [
    {"name": name, "type": typ} for name, typ in (
        ("loanToken", "address"), ("collateralToken", "address"),
        ("oracle", "address"), ("irm", "address"), ("lltv", "uint256"))]
FLASH_LIQUIDATOR_ABI = [
    {"name": "liquidate", "type": "function", "stateMutability": "nonpayable",
     "outputs": [], "inputs": [{"name": "params", "type": "tuple", "components": [
         {"name": "marketParams", "type": "tuple", "components": _MARKET_COMPONENTS},
         *[{"name": name, "type": typ} for name, typ in (
             ("borrower", "address"), ("seizedAssets", "uint256"), ("repaidShares", "uint256"),
             ("swapMode", "uint8"), ("swapData", "bytes"), ("flashAmount", "uint256"),
             ("minAmountOut", "uint256"), ("deadline", "uint256"))]]}]},
    {"name": "Liquidated", "type": "event", "anonymous": False, "inputs": [
        {"name": name, "type": typ, "indexed": indexed} for name, typ, indexed in (
            ("borrower", "address", True), ("collateralToken", "address", True),
            ("seizedCollateral", "uint256", False), ("repaidDebt", "uint256", False),
            ("swapOutput", "uint256", False), ("profit", "uint256", False))]},
]


def _function_abi(name, output, inputs=()):
    return {"name": name, "type": "function", "stateMutability": "view",
            "inputs": [{"name": f"arg{i}", "type": typ} for i, typ in enumerate(inputs)],
            "outputs": [{"name": "", "type": output}]}


class SafeMorphoExecutor:
    _shared_risk_guard: Optional[GasGuard] = None
    _shared_concurrency_mgr: Optional[ConcurrencyManager] = None
    _shared_nonce_mgr: Optional[NonceManager] = None
    _shared_settlement_dedup: Optional[SettlementDeduplicator] = None
    _risk_guard_lock = threading.RLock()
    _concurrency_init_lock = _risk_guard_lock
    _submission_lock = _DISPATCH_LOCK
    _chain_providers = {}
    _stats_sinks = {}
    _stats_publications = {}
    _MAX_RECEIPT_INT = 2**256 - 1
    _GAS_PRICE_ORACLE_ADDR = "0x420000000000000000000000000000000000000F"
    _L1_BLOCK_ADDR = "0x4200000000000000000000000000000000000015"
    _GAS_PRICE_ORACLE_ABI = [
        _function_abi("getL1Fee", "uint256", ("bytes",)),
        _function_abi("getOperatorFee", "uint256", ("uint256",)),
        _function_abi("isIsthmus", "bool"), _function_abi("isJovian", "bool"),
    ]
    _L1_BLOCK_ABI = [
        _function_abi("operatorFeeScalar", "uint32"),
        _function_abi("operatorFeeConstant", "uint64"),
        _function_abi("daFootprintGasScalar", "uint16"),
    ]

    def __init__(self, w3: Web3, chain_key: str, flash_liquidator_addr: str,
                 morpho_contract, account, chain_id: int):
        self.w3, self.chain_key, self.chain_id = w3, chain_key, chain_id
        self.flash_liquidator_addr = flash_liquidator_addr
        self.morpho, self.account, self.address = morpho_contract, account, account.address
        self._reconstruction_failed = True
        # R01: Derive OP fee policy from chain_id, not chain_key.
        # Prevents misconfigured chain_key from silently skipping OP fees.
        _OP_CHAIN_IDS = {8453, 10, 34443, 7777777}  # Base, OP Mainnet, Mode, Zora
        self._is_op_chain = chain_id in _OP_CHAIN_IDS
        # R01: Validate chain_key/chain_id consistency at construction.
        _CHAIN_KEY_TO_IDS = {
            "ethereum": {1}, "base": {8453}, "optimism": {10},
            "mode": {34443}, "zora": {7777777},
        }
        expected_ids = _CHAIN_KEY_TO_IDS.get(chain_key)
        if expected_ids is not None and chain_id not in expected_ids:
            raise RuntimeError(
                f"Chain key '{chain_key}' expects chain_id in {expected_ids}, got {chain_id}"
            )
        self._price_feed = None
        self.flash_liquidator = (w3.eth.contract(
            address=Web3.to_checksum_address(flash_liquidator_addr), abi=FLASH_LIQUIDATOR_ABI)
            if flash_liquidator_addr else None)
        self.simulator = ProfitSimulator(w3, chain_key)
        cls = SafeMorphoExecutor
        # Initialization follows the same outer lock order as execution.
        with _DISPATCH_LOCK, cls._concurrency_init_lock:
            if cls._shared_concurrency_mgr is None:
                risk = cls._shared_risk_guard or _DurableGasGuard()
                if not isinstance(risk, _DurableGasGuard):
                    raise RuntimeError("Durable GasGuard implementation required")
                cm, nm, sd = ConcurrencyManager(), NonceManager(), SettlementDeduplicator()
                status = risk.get_status()
                sd.load_settled({(entry["chain_id"], entry["tx_hash"])
                                 for entry in status["settled_tx_hashes"]})
                for r in status["pending_reservations"]:
                    if r.get("tx_hash") and not r.get("outcome_finalized"):
                        if not r.get("borrower") or not r.get("market_id"):
                            raise RuntimeError("Cannot reconstruct transaction ownership")
                        cm.restore(r["chain"], r["borrower"], r["market_id"], r["id"])
                # Construct and hydrate everything before publishing the sentinel.
                cls._shared_risk_guard = risk
                cls._shared_nonce_mgr = nm
                cls._shared_settlement_dedup = sd
                cls._shared_concurrency_mgr = cm
            self.risk = cls._shared_risk_guard
            self.concurrency = cls._shared_concurrency_mgr
            self.nonce_mgr = cls._shared_nonce_mgr
            self.settlement_dedup = cls._shared_settlement_dedup
            try:
                if type(chain_id) is not int or chain_id <= 0 or w3.eth.chain_id != chain_id:
                    raise RuntimeError("RPC chain identity mismatch")
                cls._chain_providers[chain_id] = w3
                status = self.risk.get_status()
                nonces, finalized_nonces = [], []
                for r in status["pending_reservations"]:
                    if not r.get("tx_hash"):
                        continue
                    # R01: Match by chain_id (canonical), not chain_key (label).
                    # Persisted reservations with a mismatched label but matching
                    # chain_id must still be reconstructed to prevent nonce reuse.
                    r_chain_id = r.get("chain_id")
                    if r_chain_id != chain_id:
                        continue
                    if not r.get("sender"):
                        raise RuntimeError("Incomplete persisted nonce identity")
                    if r["sender"].lower() == self.address.lower():
                        nonces.append(_uint(r["nonce"], 64))
                for r in status["nonce_ownership"]:
                    # R01: Match by chain_id, not chain_key label
                    if r.get("chain_id") != chain_id:
                        continue
                    if not r.get("sender"):
                        raise RuntimeError("Incomplete historical nonce identity")
                    if r["sender"].lower() == self.address.lower():
                        nonce = _uint(r["nonce"], 64)
                        nonces.append(nonce)
                        if r["finalized"]:
                            finalized_nonces.append(nonce)
                self.nonce_mgr.reconstruct(chain_id, self.address, nonces, w3, finalized_nonces)
                self._reconstruction_failed = False
            except Exception:
                logger.exception("[%s] Nonce reconstruction failed; admission blocked", chain_key)
        self.reconcile_pending()

    def _get_native_price(self) -> Optional[float]:
        # Retained for callers; settlement exclusively uses persisted valuation.
        if self._price_feed is None:
            from executor.price_feed import PriceFeed
            self._price_feed = PriceFeed()
        try:
            return self._price_feed.get_native_price_usd(self.chain_key)
        except Exception:
            return None

    @staticmethod
    def _parse_receipt_int(value, default=None):
        try:
            return _uint(value), True
        except (ValueError, TypeError):
            return default, False

    @staticmethod
    def _validate_receipt_status(receipt: dict) -> Optional[int]:
        status = receipt.get("status")
        return status if type(status) is int and status in (0, 1) else None

    @staticmethod
    def _parse_l1_fee_wei(receipt: dict):
        return SafeMorphoExecutor._parse_receipt_int(receipt.get("l1Fee"))

    @staticmethod
    def _parse_operator_fee_wei(receipt: dict, verified_fork=None,
                                scalar=None, constant=None, da_scalar=None,
                                block_gas_limit=None):
        """Return (fee_wei, fee_valid); markers never select a fork.

        Parameter bounds: [OP Isthmus specification](https://specs.optimism.io/protocol/isthmus/system-config.html).
        Arithmetic: [OP Jovian specification](https://specs.optimism.io/protocol/jovian/exec-engine.html).
        """
        try:
            gas = _uint(receipt.get("gasUsed"), 64)
            if verified_fork not in ("pre-isthmus", "isthmus", "jovian"):
                raise ValueError("Verified fork evidence required")
            if "daFootprintGasScalar" in receipt:
                marker = _uint(receipt["daFootprintGasScalar"], 16)
                if verified_fork != "jovian" or marker != _uint(da_scalar, 16):
                    raise ValueError("Inconsistent DA scalar")
            if "blobGasUsed" in receipt:
                marker = _uint(receipt["blobGasUsed"], 64)
                if verified_fork != "jovian" or marker > _uint(block_gas_limit, 64):
                    raise ValueError("Inconsistent DA footprint")
            scalar, constant = _uint(scalar, 32), _uint(constant, 64)
            for name, expected, bits in (("operatorFeeScalar", scalar, 32),
                                         ("operatorFeeConstant", constant, 64)):
                if name in receipt and _uint(receipt[name], bits) != expected:
                    raise ValueError("Inconsistent operator parameters")
            if verified_fork == "pre-isthmus":
                if scalar or constant:
                    raise ValueError("Pre-Isthmus operator parameters must be zero")
                fee = 0
            else:
                fee = constant + (scalar * gas * 100 if verified_fork == "jovian"
                                  else scalar * gas // 10**6)
            if "operatorFee" in receipt and _uint(receipt["operatorFee"]) != fee:
                raise ValueError("Invalid direct operator fee")
            return fee, True
        except (ValueError, TypeError):
            return None, False

    def _oracle(self):
        return self.w3.eth.contract(address=Web3.to_checksum_address(self._GAS_PRICE_ORACLE_ADDR),
                                    abi=self._GAS_PRICE_ORACLE_ABI)

    def _operator_context(self, block):
        block_hash = "0x" + _hash(block["hash"])
        oracle = self._oracle()
        is_isthmus = oracle.functions.isIsthmus().call(block_identifier=block_hash)
        if type(is_isthmus) is not bool:
            raise ValueError("Invalid fork activation evidence")
        if not is_isthmus:
            extra = _bytes(block["extraData"])
            if len(extra) == 17 and extra[0] == 1:
                raise ValueError("Pre-Isthmus oracle conflicts with Jovian header")
            return "pre-isthmus", 0, 0, None
        extra = _bytes(block["extraData"])
        # Authenticate fork selection using canonical header format and state,
        # including older Isthmus oracles that do not expose isJovian().
        if len(extra) == 17 and extra[0] == 1:
            if oracle.functions.isJovian().call(block_identifier=block_hash) is not True:
                raise ValueError("Conflicting Jovian activation evidence")
            fork = "jovian"
        elif len(extra) == 9 and extra[0] == 0:
            fork = "isthmus"
        else:
            raise ValueError("Unsupported OP fork header")
        if not int.from_bytes(extra[1:5], "big") or not int.from_bytes(extra[5:9], "big"):
            raise ValueError("Invalid OP fee header parameters")
        attributes = self.w3.eth.contract(address=Web3.to_checksum_address(self._L1_BLOCK_ADDR),
                                          abi=self._L1_BLOCK_ABI)
        scalar = _uint(attributes.functions.operatorFeeScalar().call(block_identifier=block_hash), 32)
        constant = _uint(attributes.functions.operatorFeeConstant().call(block_identifier=block_hash), 64)
        da = (_uint(attributes.functions.daFootprintGasScalar().call(block_identifier=block_hash), 16)
              if fork == "jovian" else None)
        return fork, scalar, constant, da

    def _estimate_operator_fee(self, gas_limit: int) -> int:
        gas_limit = _uint(gas_limit, 64)
        block = self.w3.eth.get_block("latest")
        fork, scalar, constant, da = self._operator_context(block)
        expected, valid = self._parse_operator_fee_wei(
            {"gasUsed": gas_limit}, fork, scalar, constant, da, block["gasLimit"])
        if not valid:
            raise ValueError("Cannot estimate operator fee")
        try:
            fee = _uint(self._oracle().functions.getOperatorFee(gas_limit).call(
                block_identifier="0x" + _hash(block["hash"])))
        except ContractLogicError:
            if fork == "pre-isthmus":
                return 0
            raise
        if fee != expected:
            raise ValueError("Operator oracle arithmetic mismatch")
        return fee

    def _estimate_l1_data_fee(self, tx_data, gas_limit: int) -> int:
        # Actual signed bytes include the final calldata, nonce and gas prices.
        # GPO adds signature padding; passing signed bytes is advisory only,
        # not a claimed mathematical upper bound for compressed calldata.
        if isinstance(tx_data, (bytes, bytearray)):
            raw = bytes(tx_data)
        else:
            from eth_account import Account
            dummy = tx_data.build_transaction({"nonce": 0, "gas": gas_limit,
                "maxFeePerGas": 1, "maxPriorityFeePerGas": 1,
                "chainId": self.chain_id, "type": 2})
            raw = Account.from_key("0x" + "01" * 32).sign_transaction(dummy).raw_transaction
        return _uint(self._oracle().functions.getL1Fee(raw).call())

    def _get_sender_for_reservation(self, r: dict) -> str:
        if not r.get("sender"):
            raise ValueError("Reservation has no authenticated sender")
        return r["sender"]

    def _is_tx_known_to_node(self, tx_hash: str) -> bool:
        try:
            return self.w3.eth.get_transaction("0x" + _hash(tx_hash)) is not None
        except TransactionNotFound:
            return False
        except Exception:
            return True

    def _decode_profit_from_receipt(self, receipt: dict, r: dict):
        if self._validate_receipt_status(receipt) != 1:
            return None, False
        try:
            address = Web3.to_checksum_address(r["flash_liquidator_addr"])
            contract = self.w3.eth.contract(address=address, abi=FLASH_LIQUIDATOR_ABI)
            matches = []
            for event in contract.events.Liquidated().process_receipt(receipt):
                args = event["args"]
                if event["address"].lower() != address.lower() or args["borrower"].lower() != r["borrower"].lower():
                    continue
                if r.get("collateral_token") and args["collateralToken"].lower() != r["collateral_token"].lower():
                    continue
                if _hash(event["transactionHash"]) != _hash(receipt["transactionHash"]):
                    continue
                if event.get("removed", False) is not False:
                    continue
                matches.append(_uint(args["profit"]))
            if len(matches) != 1:
                return None, False
            decimals = _uint(r["loan_decimals"], 8)
            price = _money(r["loan_price_usd"], positive=True)
            return _money(Decimal(matches[0]) * Decimal(str(price)) / Decimal(10)**decimals), True
        except Exception:
            return None, False

    def _validated_receipt(self, tx_hash):
        """Fresh receipt, canonical inclusion and fresh depth on EVERY fetch.

        Require the RPC finalized tag as well as MIN_CONFIRMATIONS. A provider
        without finalized support leaves the journal unresolved, never guessed.
        """
        receipt = self.w3.eth.get_transaction_receipt("0x" + _hash(tx_hash))
        if receipt is None or self._validate_receipt_status(receipt) is None:
            return None, None
        if _hash(receipt["transactionHash"]) != _hash(tx_hash):
            raise ValueError("Receipt transaction hash mismatch")
        height = _uint(receipt["blockNumber"], 64)
        block = self.w3.eth.get_block(height)
        if _uint(block["number"], 64) != height or _hash(block["hash"]) != _hash(receipt["blockHash"]):
            return None, None
        index = _uint(receipt["transactionIndex"], 64)
        transactions = block["transactions"]
        member = transactions[index]
        if hasattr(member, "get"):
            member = member.get("hash")
        if _hash(member) != _hash(tx_hash):
            raise ValueError("Receipt is not a member of its canonical block")
        latest = _uint(self.w3.eth.block_number, 64)
        finalized = self.w3.eth.get_block("finalized")
        final_height = _uint(finalized["number"], 64)
        canonical_final = self.w3.eth.get_block(final_height)
        if _hash(canonical_final["hash"]) != _hash(finalized["hash"]):
            return None, None
        if latest - height < MIN_CONFIRMATIONS or final_height < height:
            return None, None
        return receipt, block

    def _receipt_fees(self, receipt, r, block):
        try:
            gas = _uint(receipt.get("gasUsed"), 64)
            price = _uint(receipt.get("effectiveGasPrice"))
            if gas == 0 or gas > _uint(block["gasLimit"], 64):
                raise ValueError("Invalid gas usage")
            if r.get("gas_limit") is not None and gas > _uint(r["gas_limit"], 64):
                raise ValueError("Receipt gas exceeds the signed transaction limit")
            if r.get("max_fee_per_gas") is not None and price > _uint(r["max_fee_per_gas"]):
                raise ValueError("Receipt price exceeds the signed transaction limit")
            # R02: Authenticate receipt fee against immutable signed transaction
            # fields. Missing or inconsistent evidence leaves accounting incomplete
            # (raises ValueError → caller returns fee_valid=False).
            base_fee = block.get("baseFeePerGas")
            if base_fee is not None:
                base_fee_int = _uint(base_fee)
                if price < base_fee_int:
                    raise ValueError(
                        f"Receipt effectiveGasPrice {price} < block baseFeePerGas {base_fee_int}"
                    )
            tx_type = r.get("tx_type")
            if tx_type == 2:
                # EIP-1559: effective = min(maxFeePerGas, baseFeePerGas + maxPriorityFeePerGas)
                max_fee = r.get("max_fee_per_gas")
                max_priority = r.get("max_priority_fee_per_gas")
                if max_fee is None or max_priority is None:
                    raise ValueError(
                        "Type-2 transaction missing required signed fee fields "
                        "(max_fee_per_gas, max_priority_fee_per_gas)")
                if base_fee is None:
                    raise ValueError("Type-2 transaction block missing baseFeePerGas")
                expected_price = min(_uint(max_fee), base_fee_int + _uint(max_priority))
                if price != expected_price:
                    raise ValueError(
                        f"Receipt effectiveGasPrice {price} != expected EIP-1559 "
                        f"price {expected_price} (baseFee={base_fee_int}, "
                        f"maxFee={max_fee}, maxPriority={max_priority})")
            elif tx_type in (0, 1):
                # Legacy: effectiveGasPrice must equal signed gasPrice
                signed_gas_price = r.get("max_fee_per_gas")
                if signed_gas_price is None:
                    raise ValueError("Legacy transaction missing signed gasPrice field")
                if price != _uint(signed_gas_price):
                    raise ValueError(
                        f"Legacy receipt effectiveGasPrice {price} != "
                        f"signed gasPrice {_uint(signed_gas_price)}")
            elif tx_type is None:
                # Historical metadata without tx_type — cannot authenticate fee
                raise ValueError(
                    "Transaction type not recorded; fee evidence cannot be authenticated")
            else:
                raise ValueError(f"Unsupported transaction type {tx_type}")
            total = gas * price
            if self._is_op_chain:
                l1_fee, l1_valid = self._parse_l1_fee_wei(receipt)
                fork, scalar, constant, da = self._operator_context(block)
                operator_fee, operator_valid = self._parse_operator_fee_wei(
                    receipt, fork, scalar, constant, da, block["gasLimit"])
                if not l1_valid or not operator_valid:
                    raise ValueError("Incomplete OP fee evidence")
                total += l1_fee + operator_fee
            for blob_field in ("blobGasUsed", "blobGasPrice"):
                if not self._is_op_chain and blob_field in receipt:
                    raise ValueError("Unexpected blob fee for a non-blob liquidation transaction")
            _uint(total)
            native_price = _money(r.get("native_price_usd"), positive=True)
            return _money(Decimal(total) * Decimal(str(native_price)) / Decimal(10**18)), True
        except Exception:
            return None, False

    def _publish_stats(self, settlement):
        outcome = settlement["outcome"]
        tx_key = (outcome["chain_id"], outcome["tx_hash"])
        for rid in settlement["associated_ids"]:
            sink = self._stats_sinks.get(rid)
            if sink is None:
                continue
            stats, cache, borrower = sink
            publication_key = (id(stats), *tx_key)
            previous_net, previous_success, prev_complete = self._stats_publications.get(
                publication_key, (None, False, False))
            # R06: Unknown net must be None, not a numeric value derived from
            # treating unknown fees/profit as zero. Only complete outcomes
            # contribute to aggregate total_profit_usd.
            if outcome["complete"]:
                net = outcome["profit_usd"] - outcome["actual_gas_usd"]
            else:
                net = None
            accounting_complete = outcome["complete"]
            verified = outcome["success"] and outcome["profit_usd"] is not None
            if net is not None:
                delta = net - (previous_net if previous_net is not None else 0.0)
            elif previous_net is not None:
                delta = -previous_net  # retract previously complete net
            else:
                delta = 0.0
            stats["total_profit_usd"] = stats.get("total_profit_usd", 0.0) + delta
            # R06: Track incomplete transactions per stats sink. Clear the flag
            # when all tracked transactions become complete.
            incomplete_set = stats.setdefault("_incomplete_txs", set())
            if not accounting_complete:
                incomplete_set.add(tx_key)
            else:
                incomplete_set.discard(tx_key)
            stats["has_incomplete_accounting"] = len(incomplete_set) > 0
            if verified and not previous_success:
                stats["liquidations_success"] = stats.get("liquidations_success", 0) + 1
                try:
                    cache.evict(borrower)
                except Exception:
                    logger.exception("Cache eviction failed after finalized liquidation")
            self._stats_publications[publication_key] = (net, verified, accounting_complete)
            if settlement["complete"]:
                self._stats_sinks.pop(rid, None)

    def _process_reservation(self, reservation_id):
        # RPC work is outside dispatch_lock; revalidate evidence inside the
        # barrier immediately before recording, including canonical block hash.
        r = self.risk.canonical_reservation(reservation_id)
        receipt, block = self._validated_receipt(r["tx_hash"])
        if receipt is None:
            return None
        status = self._validate_receipt_status(receipt)
        gas, fee_valid = self._receipt_fees(receipt, r, block)
        profit, profit_valid = ((0.0, True) if status == 0
                                else self._decode_profit_from_receipt(receipt, r))
        with _DISPATCH_LOCK:
            fresh, fresh_block = self._validated_receipt(r["tx_hash"])
            if fresh is None or dict(fresh) != dict(receipt):
                return None
            # R09: Pass block number and tx index for execution-order outcome tracking
            block_number = fresh.get("blockNumber")
            tx_index = fresh.get("transactionIndex")
            result = self.settlement_dedup.settle(
                self.risk, self.chain_id, r["tx_hash"], reservation_id,
                gas, profit, status == 1,
                receipt_block_hash=fresh_block["hash"],
                receipt_block_number=block_number if type(block_number) is int else None,
                receipt_tx_index=tx_index if type(tx_index) is int else None,
                fee_incomplete=not fee_valid, fee_valid=fee_valid,
                profit_incomplete=not profit_valid,
            )
            for rid in result["associated_ids"]:
                self.concurrency.resolve(rid)
            self._publish_stats(result)
            return result

    def _reconcile(self, cancel_orphans):
        try:
            pending = self.risk.get_status()["pending_reservations"]
        except Exception:
            logger.exception("[%s] Cannot read reconciliation journal", self.chain_key)
            return
        for r in pending:
            if r["chain"] != self.chain_key:
                continue
            try:
                if not r.get("tx_hash"):
                    if cancel_orphans:
                        with _DISPATCH_LOCK:
                            current = self.risk.get_reservation(r["id"])
                            if (current.get("submission_state") in (None, "pending")
                                    and not current.get("tx_hash")
                                    and current.get("owner_process") != _PROCESS_ID
                                    and not self.concurrency.has_live_claim(r["id"])):
                                self.risk.cancel_reservation(r["id"])
                    continue
                if r.get("chain_id") != self.chain_id:
                    raise ValueError("Reservation chain identity mismatch")
                result = self._process_reservation(r["id"])
                if result is not None or r.get("outcome_finalized"):
                    continue
            except Exception:
                logger.debug("[%s] Receipt reconciliation deferred for %s", self.chain_key, r["id"], exc_info=True)
            # Nonce advancement is only a search hint, never a monetary outcome.
            if r.get("tx_hash") and r.get("nonce") is not None and not r.get("outcome_finalized"):
                try:
                    sender = self._get_sender_for_reservation(r)
                    nonce = _uint(self.w3.eth.get_transaction_count(sender, "latest"), 64)
                    if nonce > _uint(r["nonce"], 64):
                        with _DISPATCH_LOCK:
                            current = self.risk.get_reservation(r["id"])
                            if not current.get("outcome_finalized") and current.get("submission_state") != "nonce_consumed_unresolved":
                                self.risk.update_reservation_metadata(
                                    r["id"], submission_state="nonce_consumed_unresolved")
                except Exception:
                    logger.debug("Nonce evidence unavailable for %s", r["id"], exc_info=True)

    def reconcile_pending(self):
        self._reconcile(cancel_orphans=True)

    def periodic_reconcile(self):
        self._reconcile(cancel_orphans=False)

    @staticmethod
    def _relay_evidence(result):
        """Visit every dict/list child, including error.data and nested arrays.

        This is diagnostic evidence, never permission to release a dispatched
        transaction. Cycles, resource limits and unclassified leaves are unknown.
        """
        evidence = {"accepted": False, "rejected": False, "unknown": False}
        stack, seen, count = [result], set(), 0
        rejection_words = ("insufficient funds", "underpriced", "not allowed",
                           "intrinsic gas too low", "exceeds block gas limit",
                           "tx pool is full", "max fee per gas less than")
        while stack:
            count += 1
            if count > 10000:
                evidence["unknown"] = True
                break
            value = stack.pop()
            if isinstance(value, (dict, list, tuple)):
                if id(value) in seen:
                    evidence["unknown"] = True
                    continue
                seen.add(id(value))
                if not value:
                    evidence["unknown"] = True
                if isinstance(value, dict):
                    if value.get("accepted") is True or value.get("success") is True:
                        evidence["accepted"] = True
                    accepted = value.get("builders_accepted")
                    if type(accepted) is int and accepted > 0:
                        evidence["accepted"] = True
                    for name, child in value.items():
                        if name in ("result", "bundleHash", "txHash", "transactionHash"):
                            try:
                                _hash(child)
                                evidence["accepted"] = True
                            except (ValueError, TypeError):
                                pass
                        stack.append(child)
                else:
                    stack.extend(value)
            elif isinstance(value, str):
                lowered = value.lower()
                if "accepted" in lowered or "already known" in lowered:
                    evidence["accepted"] = True
                if any(word in lowered for word in rejection_words):
                    evidence["rejected"] = True
                else:
                    evidence["unknown"] = True
            else:
                evidence["unknown"] = True
        return evidence

    @staticmethod
    def _result(reason, sim=None, tx_hash=None, executed=False, success=False, **extra):
        return {"executed": executed, "success": success, "profit_usd": 0.0,
                "tx_hash": _hash(tx_hash) if tx_hash else None,
                "reason": reason, "sim": sim, **extra}

    def execute_liquidation(self, market, position, seized_amount: int,
                            flash_amount: int, collateral_decimals: int,
                            loan_decimals: int, loan_price_usd: float,
                            native_price_usd: float, flashbots, liq_cache,
                            stats: dict) -> dict:
        start, mono = time.time(), time.monotonic()
        if self.chain_key == "base":
            from executor.price_feed import APPROVED_TOKENS
            for label, token in (("loan", market.params.loan_token),
                                  ("collateral", market.params.collateral_token)):
                if ("base", token.lower()) not in APPROVED_TOKENS:
                    return self._result(f"unapproved_{label}_token")
        if not self.flash_liquidator_addr:
            stats["liquidations_attempted"] = stats.get("liquidations_attempted", 0) + 1
            return self._result("Monitor mode (no flash liquidator deployed)")
        if self._reconstruction_failed:
            return self._result("nonce_reconstruction_failed")
        try:
            native_price_usd = _money(native_price_usd, positive=True)
            loan_price_usd = _money(loan_price_usd, positive=True)
            _uint(loan_decimals, 8)
            _uint(collateral_decimals, 8)
            if not _uint(seized_amount) or not _uint(flash_amount):
                raise ValueError("Positive liquidation amounts required")
            sim = self.simulator.simulate(
                collateral_token=market.params.collateral_token,
                loan_token=market.params.loan_token,
                collateral_amount_raw=seized_amount, flash_amount_raw=flash_amount,
                collateral_decimals=collateral_decimals, loan_decimals=loan_decimals,
                loan_price_usd=loan_price_usd, native_price_usd=native_price_usd)
        except Exception as exc:
            return self._result(f"Simulation error: {exc}")
        if not sim.profitable:
            return self._result(sim.reason, sim)
        claim = self.concurrency.try_claim(self.chain_key, position.borrower, position.market_id)
        if claim is None:
            return self._result("duplicate_inflight", sim)
        reservation_id = None
        try:
            # A constructor cannot observe the gap between reserve and binding.
            with _DISPATCH_LOCK:
                reservation = self.risk.reserve_and_check(self.chain_key, sim.gas_cost_usd)
                if not reservation.approved:
                    return self._result(f"Risk: {reservation.reason}", sim)
                reservation_id = reservation.reservation_id
                self.concurrency.bind(claim, reservation_id)
                self._stats_sinks[reservation_id] = (stats, liq_cache, position.borrower)
                if not self.risk.update_reservation_metadata(
                        reservation_id, borrower=position.borrower,
                        market_id=position.market_id, owner_process=_PROCESS_ID):
                    raise RuntimeError("Cannot bind reservation metadata")
            return self._execute_claimed(
                market, position, seized_amount, flash_amount, collateral_decimals,
                loan_decimals, loan_price_usd, native_price_usd, flashbots, liq_cache,
                stats, sim, reservation_id, reservation, claim, start, mono)
        except Exception as exc:
            logger.exception("[%s] Claimed execution failed", self.chain_key)
            return self._result(f"Execution error: {exc}", sim)
        finally:
            if reservation_id:
                try:
                    with _DISPATCH_LOCK:
                        r = self.risk.get_reservation(reservation_id)
                        if r["submission_state"] in (None, "pending") and not r.get("tx_hash"):
                            self.risk.cancel_reservation(reservation_id)
                            self._stats_sinks.pop(reservation_id, None)
                except Exception:
                    logger.exception("Reservation cleanup failed; hold retained")
            self.concurrency.release(claim)

    def _verify_deadline_contract(self):
        expected = DEADLINE_CONTRACT_CODE_HASHES.get((self.chain_id, self.flash_liquidator_addr.lower()))
        if expected is None:
            raise RuntimeError("Audited deadline-enforcing contract runtime hash is not configured")
        code = self.w3.eth.get_code(Web3.to_checksum_address(self.flash_liquidator_addr))
        if not code or _hash(Web3.keccak(code)) != _hash(expected):
            raise RuntimeError("Deadline contract runtime verification failed")

    def _execute_claimed(self, market, position, seized_amount, flash_amount,
                         collateral_decimals, loan_decimals, loan_price_usd,
                         native_price_usd, flashbots, liq_cache, stats, sim,
                         reservation_id, reservation, execution_claim,
                         t_start, t_mono_start) -> dict:
        nonce_alloc: Optional[NonceAllocation] = None
        dispatch_intent = False
        dispatched = False
        tx_hash = None
        try:
            from executor.simulator import MIN_PROFIT_USD
            self._verify_deadline_contract()
            head = self.w3.eth.get_block("latest")
            deadline = _uint(head["timestamp"], 64) + TRANSACTION_TTL_SECONDS
            prefix = (market.params.to_tuple(), Web3.to_checksum_address(position.borrower),
                      seized_amount, 0, sim.swap_mode, sim.swap_path, flash_amount)
            call = self.flash_liquidator.functions.liquidate((*prefix, sim.min_amount_out, deadline))
            gas_est = _uint(call.estimate_gas({"from": self.address}), 64)
            gas_limit = (gas_est * 3 + 1) // 2
            if gas_est == 0 or gas_limit > _uint(head["gasLimit"], 64):
                raise ValueError("Invalid liquidation gas estimate")
            nonce_alloc = self.nonce_mgr.allocate(self.chain_id, self.address, self.w3)
            base_fee = head.get("baseFeePerGas")
            fees = {}
            if base_fee is not None:
                priority = _uint(self.w3.eth.max_priority_fee) * 3
                max_fee = _uint(base_fee) * 3 + priority
                fees = {"maxFeePerGas": max_fee, "maxPriorityFeePerGas": priority, "type": 2}
            else:
                max_fee = _uint(self.w3.eth.gas_price) * 2
                fees = {"gasPrice": max_fee}
            if max_fee == 0:
                raise ValueError("Zero maximum gas price")
            execution_wei = gas_limit * _uint(max_fee)
            gas_budget = _budget(Decimal(execution_wei) / Decimal(10**18) * Decimal(str(native_price_usd)))
            # Iterate on FINAL signed calldata because minAmountOut changes L1
            # compression. The last signed bytes must fit the admitted budget.
            for _ in range(8):
                required_profit = Decimal(str(MIN_PROFIT_USD)) + Decimal(str(gas_budget))
                numerator, denominator = required_profit.as_integer_ratio()
                price_num, price_den = Decimal(str(loan_price_usd)).as_integer_ratio()
                numerator *= price_den * 10**loan_decimals
                denominator *= price_num
                profit_raw = (numerator + denominator - 1) // denominator
                minimum = max(_uint(sim.min_amount_out), _uint(flash_amount + profit_raw))
                if _uint(sim.swap_output_raw) < minimum:
                    raise ValueError("Swap output below stressed minimum")
                sim.min_amount_out = minimum
                call = self.flash_liquidator.functions.liquidate((*prefix, minimum, deadline))
                tx = call.build_transaction({"from": self.address, "nonce": nonce_alloc.nonce,
                                             "gas": gas_limit, "chainId": self.chain_id, **fees})
                signed = self.account.sign_transaction(tx)
                raw = signed.raw_transaction
                tx_hash = _hash(Web3.keccak(raw))
                l1_stress = op_stress = Decimal(0)
                if self._is_op_chain:
                    l1 = self._estimate_l1_data_fee(raw, gas_limit)
                    op = self._estimate_operator_fee(gas_limit)
                    conversion = Decimal(str(native_price_usd)) / Decimal(10**18)
                    l1_stress = Decimal(l1) * conversion * OP_FEE_STRESS_MULTIPLIER
                    op_stress = Decimal(op) * conversion * OP_FEE_STRESS_MULTIPLIER
                    if l1_stress > MAX_L1_FEE_STRESS_USD or op_stress > MAX_OPERATOR_FEE_STRESS_USD:
                        raise ValueError("OP fee stress limit exceeded")
                required = _budget(Decimal(execution_wei) / Decimal(10**18)
                                  * Decimal(str(native_price_usd)) + l1_stress + op_stress)
                if required <= gas_budget:
                    break
                gas_budget = required
            else:
                raise ValueError("Final transaction fee estimate did not converge")
            if not self.risk.update_reservation(reservation_id, gas_budget):
                raise ValueError("Stressed gas budget exceeds risk limits")
            with _DISPATCH_LOCK:
                if time.monotonic() - t_mono_start > MAX_PREPARATION_SECONDS:
                    raise ValueError("preparation_timeout")
                self._verify_deadline_contract()
                if _uint(self.w3.eth.get_block("latest")["timestamp"], 64) >= deadline:
                    raise ValueError("Transaction deadline elapsed")
                safe, reason = self.risk.pre_submission_safe(self.chain_key)
                if not safe:
                    raise RuntimeError(reason)
                # Retain durable ownership before journaling any possible send.
                self.concurrency.retain(execution_claim, reservation_id)
                dispatch_intent = True
                self.risk.begin_dispatch(
                    reservation_id, tx_hash=tx_hash, nonce=nonce_alloc.nonce,
                    chain_id=self.chain_id, sender=self.address,
                    borrower=position.borrower, market_id=position.market_id,
                    native_price_usd=native_price_usd, loan_price_usd=loan_price_usd,
                    loan_decimals=loan_decimals, flash_liquidator_addr=self.flash_liquidator_addr,
                    collateral_token=market.params.collateral_token, deadline=deadline,
                    gas_limit=gas_limit, max_fee_per_gas=max_fee,
                    max_priority_fee_per_gas=fees.get("maxPriorityFeePerGas"),
                    tx_type=fees.get("type", 0),
                    fee_stress_multiplier=str(OP_FEE_STRESS_MULTIPLIER),
                    l1_fee_stress_usd=float(l1_stress), operator_fee_stress_usd=float(op_stress))
                # All metadata writes and potential persistence latches are behind
                # this same barrier. No write occurs after this final gate.
                safe, reason = self.risk.pre_submission_safe(self.chain_key)
                if not safe:
                    raise RuntimeError(reason)
                if time.monotonic() - t_mono_start > MAX_PREPARATION_SECONDS:
                    raise ValueError("preparation_timeout_after_journal")
                self.risk.mark_dispatch_attempted(reservation_id)
                dispatched = True
                self.nonce_mgr.confirm(nonce_alloc)
                result = flashbots.submit_bundle(self.w3, self.chain_id, raw)
                evidence = self._relay_evidence(result)
                self.risk.update_reservation_metadata(
                    reservation_id, submission_state="submitted", relay_evidence=evidence)
            return self._wait_and_settle(
                tx_hash, tx, sim, position, market, liq_cache, stats, t_start,
                native_price_usd, loan_decimals, loan_price_usd, reservation_id)
        except Exception as exc:
            logger.error("[%s] Execution deferred/aborted: %s", self.chain_key, exc)
            logger.debug(traceback.format_exc())
            return self._result(
                f"submission_unresolved: {exc}" if dispatched else f"TX preparation aborted: {exc}",
                sim, tx_hash if dispatch_intent else None, executed=dispatched,
                outcome_pending=dispatched)
        finally:
            stats["liquidations_attempted"] = stats.get("liquidations_attempted", 0) + 1
            if nonce_alloc is not None:
                if dispatch_intent and not dispatched:
                    try:
                        with _DISPATCH_LOCK:
                            if self.risk.abort_before_dispatch(reservation_id):
                                dispatch_intent = False
                                self.concurrency.resolve(reservation_id)
                                self._stats_sinks.pop(reservation_id, None)
                    except Exception:
                        logger.exception("Pre-dispatch cleanup uncertain; nonce quarantined")
                if dispatched or dispatch_intent:
                    # If journaling failed, its durable commit may be uncertain.
                    # Quarantine this nonce until restart reconstructs the journal.
                    self.nonce_mgr.confirm(nonce_alloc)
                else:
                    self.nonce_mgr.release(nonce_alloc)

    def _wait_and_settle(self, tx_hash, tx: dict, sim: SimulationResult, position,
                         market, liq_cache, stats: dict, t_start: float,
                         native_price_usd: float, loan_decimals: int,
                         loan_price_usd: float, reservation_id: str = "") -> dict:
        try:
            self.w3.eth.wait_for_transaction_receipt("0x" + _hash(tx_hash), timeout=120)
            until = time.monotonic() + 60
            while True:
                settlement = self._process_reservation(reservation_id)
                if settlement is not None:
                    outcome = settlement["outcome"]
                    gas, profit = outcome["actual_gas_usd"], outcome["profit_usd"]
                    return self._result(
                        "Finalized" if settlement["complete"] else "Finalized; accounting incomplete",
                        sim, tx_hash, executed=True, success=outcome["success"],
                        profit_usd=(profit - gas) if (profit is not None and gas is not None) else None,
                        fee_incomplete=gas is None, fee_valid=gas is not None,
                        profit_incomplete=profit is None, outcome_pending=False,
                        settlement_status=settlement["status"])
                if time.monotonic() >= until:
                    break
                time.sleep(2)
        except Exception:
            logger.debug("[%s] Foreground receipt deferred", self.chain_key, exc_info=True)
        return self._result("Receipt/finality pending; durable ownership retained", sim,
                            tx_hash, executed=True, outcome_pending=True,
                            fee_incomplete=True, profit_incomplete=True)
