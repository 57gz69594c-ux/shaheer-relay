# REAPER ENGINE — COMPLETE POSITION FINDINGS REPORT
**Generated:** 2026-09-14 09:36 UTC  
**Engine:** Reaper v5.4.3-velora-paid-auth  
**Uptime:** 22.3 hours  
**Chains Live:** 11 (Ethereum, Arbitrum, Base, Polygon, Optimism, BNB, Avalanche, Scroll, Mantle, Gnosis, Linea)  
**Total Markets:** 1,583 | **Borrowers:** ~50,000 | **Danger Zone:** 5,975+  
**Liquidations Executed:** 0 | **Profit:** $0.00  

---

## EXECUTIVE SUMMARY

The engine is scanning ~50,000 borrowers across 1,583 markets on 11 chains. It has identified **5,975+ positions in the danger zone** but has executed **zero liquidations** due to a combination of:

1. **Missing swap routes** — Aggregators can't quote exotic tokens (PT tokens, thBILL, CANA, etc.)
2. **1inch API key revoked** — Blocks the secondary aggregator on ALL chains
3. **DEX price vs oracle price mismatch** — Swap output < repayment on RWA tokens
4. **Gas costs exceeding profit** — L1 data costs on L2 chains eat small position margins
5. **Infrastructure gaps** — Missing executor on Scroll, unregistered router on Arbitrum, missing price feeds on Polygon

---

## CATEGORY 1: LIQUIDATABLE NOW — NOT PROFITABLE

### 1A. Arbitrum — thBILL/USDC (235 borrowers, $15,446 total)
- **Health Factor:** ~0.97 (below 1.0 = liquidatable)
- **LIF incentive:** 1.68%
- **Problem:** DEX price for thBILL→USDC is WORSE than oracle price. Velora gives ~2.5% slippage vs 1.68% bonus = net loss.
- **Blockers:**
  - Velora: `OUTPUT_BELOW_REPAYMENT_AND_PROFIT` — swap output insufficient
  - Uniswap V3: `SWAP_TARGET_UNREGISTERED` — router not whitelisted on Arbitrum executor
  - 1inch: `API_KEY_MISSING` — 401 on every request
- **Fix needed:** Better swap route that gets closer to oracle price, or multi-hop route (thBILL→USDT→USDC)
- **Potential profit if fixed:** ~$260

### 1B. Ethereum — Bad Debt Positions (4,911 in danger)
- **Health Factor range:** 0.00 — 0.99
- **Tokens involved:** PT-tUSDe, PT-srUSDe, PT-sUSDE, PT-sNUSD, PT-mAPOLLO, CANA, AUSD, XAUt
- **Problem:** Aggregators return NO_QUOTE for all these tokens (882+ failures). Velora says "srcToken does not match any of the allowed types." These are Pendle PT tokens, RWA tokens, and exotic DeFi tokens that aggregators simply don't index.
- **Additional problem:** Many positions are TRUE bad debt (HF 0.00-0.10) where collateral is worth 0-10% of debt — even perfect routing loses money.
- **Profitable subset:** Positions with HF 0.8-0.99 could be profitable IF routes are found:
  - 0x23dDFe708e... (PT-sUSDE-27FEB2025/USDC, HF 0.9921) — 99.21% collateralized
  - 0xC61d61E35e... (CANA/USDT, HF 0.9993) — 99.93% collateralized  
  - 0x594c5eE5a3... (PT-sNUSD-5MAR2026/USDC, HF 0.8462) — 84.62% collateralized

### 1C. Polygon — Multiple Markets (25 in danger)
- **Markets:** WETH/WPOL, WETH/USDC, WPOL/USDC, vBELEGYYES/USDC
- **Problems:**
  - AGGREGATORS_NO_QUOTE: 285 failures
  - OUTPUT_BELOW_REPAYMENT_AND_PROFIT: 48 failures
  - DEBT_USD_FEED_MISSING: 56 failures (can't price debt tokens)
  - NO_REPAYABLE_COLLATERAL: 23 positions (nothing to seize)
  - 1inch: API_KEY_MISSING (306 failures)
  - Velora: NO_ROUTE (185), RATE_BUDGET_OR_COOLDOWN (93), RATE_LIMIT (5)

### 1D. Scroll — Executor Missing (1 position)
- **Problem:** No Morpho executor contract deployed on Scroll. 504 failed preparation attempts.
- **Fix:** Deploy executor on Scroll

### 1E. Optimism — No Profitable Route (4 in danger)
- **Problems:** AGGREGATORS_NO_QUOTE (152), OUTPUT_BELOW_REPAYMENT (74), 1inch API_KEY_MISSING (79)

### 1F. Arbitrum — wstUSR/USDC (recurring)
- **Borrower:** 0xaa080789B1...
- **Health Factor:** 0.05 (deeply underwater)
- **Status:** Engine detects this every ~6 minutes, fires WARNING, but cannot find a route
- **Problem:** wstUSR is not supported by any configured aggregator

---

## CATEGORY 2: KNIFE-EDGE — ALMOST LIQUIDATABLE

### Base — wstETH/WETH Market (828 borrowers tracked)
**Market specs:** LLTV 94% | Oracle: 1.243946 WETH/wstETH | LIF: 1.0168 (1.68% bonus)  
**L2 gas cost:** $0.025 per liquidation

| Borrower | Borrow (WETH) | Borrow (USD) | HF | Drop Needed | Net Profit |
|----------|--------------|-------------|-----|-------------|------------|
| 0x39bbbaf0... | 0.000000 | $0 | 1.0038 | 0.38% | -$0.03 (dust) |
| 0x9736b13d... | 0.049569 | $139 | 1.0081 | 0.81% | $2.16 |
| 0x0f00463c... | 0.008704 | $24 | 1.0119 | 1.19% | $0.36 |
| **0xc8df8271...** | **281.519** | **$788,252** | **1.0135** | **1.35%** | **$12,436** |
| 0x37b6be55... | 5.814 | $16,281 | 1.0169 | 1.69% | $256.83 |
| 0x69f55a95... | 6.256 | $17,518 | 1.0331 | 3.31% | ~$277 |
| 0x5f569180... | 189.086 | $529,439 | 1.0353 | 3.53% | ~$8,400 |

**Combined value at risk:** $1,351,653 in positions within 3.5% of liquidation  
**Combined potential profit:** $21,370+ if market moves in our direction  

**The $788K whale (0xc8df8271):** Only needs wstETH/WETH oracle price to drop 1.35% to become liquidatable. This is a stable LST pair, but de-peg events DO happen (stETH depegged ~5% in 2022). One small depeg event = **$12,436 profit** on a single transaction costing $0.025 gas.

---

## CATEGORY 3: BEING PROCESSED — NET PROFIT BELOW COSTS

These positions HAVE valid swap routes (Velora or Uniswap V3 return quotes), but the profit after gas + flash loan fees is negative.

| Chain | Borrower | Debt | Provider | Prep Count | Blocker |
|-------|----------|------|----------|------------|---------|
| Arbitrum | 0xBAC70E2D | USDT | Velora | 48 | L1 data cost > profit |
| Arbitrum | 0xAa1492d0 | USDC | Velora | 44 | L1 data cost > profit |
| Base | 0x0f00463c | WETH | Uniswap V3 | 22 | L1 data cost > profit |
| Base | 0x583B6A90 | WETH | - | 25 | L1 data cost > profit |
| Ethereum | Various | DAI/USDC/USDT/WETH | Velora | Multiple | L1 gas $2-15 > profit |

---

## CATEGORY 4: INFRASTRUCTURE BLOCKERS

| Blocker | Impact | Affected | Fix |
|---------|--------|----------|-----|
| **1inch API Key Missing** | Secondary aggregator dead on ALL chains | 401+ ETH, 306 Polygon, 79 Optimism failures | Complete 1inch KYC |
| **Velora Token Registry** | Can't quote PT tokens, thBILL, CANA, XAUt, etc. | Hundreds of Ethereum positions | Request Velora to add tokens, or add new aggregator |
| **Velora Rate Limiting** | Queue overflow — positions expire before getting quoted | 93 Polygon, 61 Optimism cooldowns | Increase rate limit or add parallel aggregators |
| **Scroll Executor Missing** | 1 position permanently blocked | 504 failed preps | Deploy executor |
| **Arbitrum UniV3 Router** | Uniswap V3 fallback dead on Arbitrum | All Arbitrum positions | Register router on executor |
| **Polygon USD Feeds** | 56 positions can't be evaluated | Polygon | Add Chainlink feeds to config |

---

## CATEGORY 5: AAVE SNIPER (PASSIVE MONITORING)
- 101 positions watched across 8 chains
- All HF between 1.0 and 1.15 (not yet liquidatable)
- Auto-triggers when HF drops below 1.0

## CATEGORY 6: COMPOUND-STYLE PROTOCOLS (ALL DUST)
- Venus/BNB: Multiple positions, $0-$58 remaining
- Mendi/Linea: 1 position, $9.40
- Moonwell/Optimism: 2 positions, $31-$50
- Benqi/Avalanche: 2 positions, $1.58-$9.84
- **All unprofitable** — gas costs exceed potential

---

## KEY NUMBERS

- **Total positions found:** 5,975+ in danger zone
- **Total value in knife-edge positions:** $1,351,653
- **Max single-position profit opportunity:** $12,436 (Base wstETH whale)
- **Positions blocked by 1inch API:** 786+
- **Positions blocked by Velora token gaps:** 882+ (Ethereum alone)
- **Positions blocked by infrastructure:** 504+ (Scroll executor) + 56 (Polygon feeds)
- **Routes that work but profit < costs:** ~200+ across chains
