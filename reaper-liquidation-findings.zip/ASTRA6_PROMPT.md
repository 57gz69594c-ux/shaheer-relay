# GPT ASTRA 6 — MISSION BRIEF
## Find Profitable Swap Routes for Blocked Liquidation Positions

**Priority:** CRITICAL  
**Objective:** The Reaper liquidation engine has found 5,975+ positions across 11 chains that are in the danger zone or already liquidatable, but CANNOT execute a single profitable liquidation due to missing/inadequate swap routes and infrastructure gaps. Your job is to find alternative swap routes, multi-hop paths, and workarounds that make these positions profitable.

---

## CONTEXT

We run a Morpho Blue liquidation bot (Reaper v5.4.3) with a V4 flash-loan executor on Ethereum (`0x1efd7FED19B5756F8E44862189D7e3414987a436`). The engine:
1. Flash-borrows the debt token from Morpho
2. Calls `liquidate()` to repay the borrower's debt and seize collateral
3. Swaps seized collateral → debt token via a DEX
4. Repays the flash loan
5. Keeps the profit (LIF bonus minus swap slippage minus gas minus flash fee)

**Currently approved DEX routers on the executor:**
- Uniswap V3 SwapRouter02: `0x68b3465833fb72A70ecDF485E0e4C7bD8665Fc45`
- Velora Augustus V6: `0x6A000F20005980200259B80c5102003040001068`
- 1inch AggregationRouterV6: `0x111111125421cA6dc452d289314280a0f8842A65`

**Morpho Blue LIF formula:** `LIF = min(1.15, 1/(1 - 0.3 * (1 - LLTV)))`
- At 94% LLTV → LIF = 1.0168 (1.68% bonus)
- At 96.5% LLTV → LIF = 1.0106 (1.06% bonus)
- At 86% LLTV → LIF = 1.0438 (4.38% bonus)

---

## PROBLEM 1: thBILL/USDC on Arbitrum (235 positions, $15,446, HF ~0.97)

**Token:** thBILL (`0x528A5bac7E746C9A509A1f4F6dF58A03d44279F9`) on Arbitrum  
**Debt:** USDC (`0xaf88d065e77c8cC2239327C5EDb3A432268e5831`)  
**LIF bonus:** 1.68%  

**What's happening:** Velora returns a swap quote for thBILL→USDC, but the output is ~2.5% below the oracle price. Since the LIF bonus is only 1.68%, the net is negative. The Uniswap V3 router is not registered on the Arbitrum executor so that fallback fails. 1inch API key is dead.

**TASKS FOR YOU:**
1. Find the best DEX/AMM pools for thBILL→USDC on Arbitrum. Is there better liquidity on Curve, Balancer, Camelot, or other Arbitrum DEXes?
2. Would a multi-hop route work? e.g., thBILL → USDT → USDC (if thBILL/USDT has better liquidity)?
3. What is the actual on-chain price of thBILL right now vs the Morpho oracle price? If the oracle is stale/wrong, is there an arbitrage?
4. Is there a Chainlink or API3 price feed for thBILL we can compare against?
5. Can we use Odos or 0x API as alternative aggregators? Do they support thBILL?

---

## PROBLEM 2: PT Tokens (Pendle) on Ethereum (882+ quote failures)

**Tokens involved:**
- PT-tUSDe-18DEC2025 (expired Pendle token)
- PT-srUSDe-15JAN2026 (expired)
- PT-srUSDe-2APR2026 (expired)
- PT-sUSDE-27FEB2025 (expired)
- PT-sNUSD-5MAR2026 (expired)
- PT-mAPOLLO-29JAN2026 (expired)

**Debt tokens:** USDe, AUSD, USDC, USDT

**What's happening:** Neither Velora nor 1inch recognizes these PT tokens. They return 400/401 errors. These are all EXPIRED Pendle Principal Tokens — they should be redeemable 1:1 for their underlying yield-bearing token.

**TASKS FOR YOU:**
1. For each expired PT token, what is its underlying asset? (e.g., PT-tUSDe → tUSDe → USDe)
2. Can expired PT tokens be redeemed directly via the Pendle Router contract without going through a DEX? If so, provide the Pendle Router address and the function signature for redemption.
3. What would the swap path look like? PT-srUSDe → redeem via Pendle → srUSDe → unwrap → USDe → swap to USDC?
4. Are there any Pendle AMM pools still active for these tokens?
5. Check if the Pendle SDK or API (`api-v2.pendle.finance`) can provide redemption quotes.
6. Specific positions to focus on (profitable IF route found):
   - `0x23dDFe708e...` borrowing USDC with PT-sUSDE-27FEB2025 collateral (HF 0.9921 — 99.21% collateralized, just barely underwater)
   - `0xC61d61E35e...` borrowing USDT with CANA collateral (HF 0.9993 — 0.07% underwater)
   - `0x594c5eE5a3...` borrowing USDC with PT-sNUSD-5MAR2026 collateral (HF 0.8462)

---

## PROBLEM 3: Exotic Tokens Not in Aggregator Registries

**Tokens that NO aggregator can quote:**
- **CANA** (Ethereum) — What DEX has CANA/USDT or CANA/ETH liquidity?
- **AUSD** (Ethereum) — Agora USD? What DEXes support it?
- **vBELEGYYES** (Polygon) — What is this token? Where can it be swapped?
- **wstUSR** (Arbitrum) — Wrapped staked USR. Where is liquidity? Can it be unwrapped to USR first?
- **XAUt** (Ethereum) — Tether Gold. Only trades on CEXes? Any DEX liquidity?

**TASKS:**
1. For each token, find: (a) which DEXes have liquidity, (b) approximate daily volume, (c) best swap path to USDC/USDT/WETH
2. Can we use direct pool calls (bypassing aggregators) to swap these tokens?
3. Would adding Odos (`https://api.odos.xyz`) as a fourth aggregator solve most of these? Does Odos index PT tokens and RWA tokens?

---

## PROBLEM 4: L2 Gas Cost Optimization

**Current cost on Base/Arbitrum:** ~$0.025 per liquidation (L1 data posting dominates)  
**Problem:** Many small positions ($24-$200 borrow) have LIF bonuses of $0.40-$3.36, but gas is $0.025 + flash loan fee. After fees, net profit is negative for positions under ~$50.

**TASKS:**
1. Can we batch multiple small liquidations into a single transaction to amortize L1 data cost?
2. What is the minimum position size that's profitable on Base at current gas? On Arbitrum?
3. Is there a way to reduce L1 data cost (e.g., calldata compression, blob posting)?
4. Can EIP-4844 blob transactions reduce the L1 data overhead for our liquidation calldata?

---

## PROBLEM 5: wstETH/WETH Knife-Edge Positions on Base

**This is the highest-value opportunity.**

The biggest position: Borrower `0xc8df827157ad...` has **281.52 WETH ($788,252)** borrowed against wstETH collateral at **HF 1.0135**. Only needs a **1.35% drop** in wstETH/WETH oracle price to become liquidatable.

**If triggered: $12,436 net profit** (4.44 WETH) on a single liquidation costing $0.025 gas.

Second biggest: `0x5f5691805947...` has **189.09 WETH ($529,439)** at HF 1.035 — needs 3.53% drop for ~$8,400 profit.

**TASKS:**
1. What has the wstETH/WETH exchange rate volatility been over the past 30/90/365 days? How often does it move 1.35%+?
2. Is the Morpho oracle using a TWAP, spot price, or Chainlink feed? How quickly does it update?
3. Are there any known upcoming events that could cause wstETH/WETH to move (Lido withdrawals, Ethereum upgrades, staking yield changes)?
4. Should we set up an alert system that triggers the liquidation the INSTANT the oracle updates to a favorable price?
5. Could we hedge by shorting wstETH/WETH on a perp DEX to benefit from the same move that triggers the liquidation?

---

## PROBLEM 6: Arbitrum Uniswap V3 Router Registration

**The Uniswap V3 router (0x68b346...) is not registered on the Arbitrum executor.**

**TASKS:**
1. Is the Uniswap V3 SwapRouter02 address the same on Arbitrum as Ethereum? If not, what's the correct address?
2. What is the process to register a new router on the Morpho V4 executor? Is it an owner-only call?
3. Are there other DEX routers on Arbitrum worth registering? (Camelot, SushiSwap, etc.)

---

## PROBLEM 7: Missing Polygon USD Price Feeds

56 positions blocked by DEBT_USD_FEED_MISSING on Polygon.

**TASKS:**
1. What Polygon debt tokens are missing Chainlink USD feeds?
2. Provide the Chainlink feed addresses for common Polygon tokens: WPOL, WMATIC, WETH, USDC, USDT, DAI, WBTC
3. Are there API3 or Pyth alternatives if Chainlink doesn't cover a token?

---

## DELIVERABLES REQUESTED

For each problem above, provide:
1. **Specific contract addresses** for recommended DEX routers/pools
2. **Exact swap paths** (token A → pool → token B → pool → token C)
3. **Expected slippage** at the position sizes involved
4. **Code snippets or API calls** to test the routes
5. **Priority ranking** — which fixes unlock the most profit for the least effort?

**Estimated profit unlock if all problems solved:**
- thBILL/USDC routes: ~$260
- PT token redemption routes: $1,000+ (if HF 0.8-0.99 positions are reachable)
- wstETH/WETH monitoring: $12,436-$21,370 (when market moves)
- Small position batching: $100-500/day across hundreds of small positions
- Total potential: **$15,000-$35,000** in recoverable liquidation profit

---

## IMPORTANT CONSTRAINTS

- DO NOT try to use the OpenAI API key — it was revoked Sep 11. Use Codex CLI + ChatGPT Pro only.
- DO NOT modify reaper engine source files — hash verification will block startup.
- All swap routes must go through the approved routers listed above, OR propose new routers to be registered on the executor.
- Flash loan source is Morpho itself (zero fee), NOT Aave/dYdX.
- The executor contract version is V4 — it supports `morphoFlashLoan()` → `liquidate()` → `swap()` in a single atomic transaction.
