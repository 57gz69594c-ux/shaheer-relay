RH Chain Rotation Engine v6.2-repaired-v6
==========================================
Export date: 2026-09-08
Tests: 160 regression tests, ALL PASSING

CONTENTS:
  repair/rh_rotation_engine.py    — Repaired engine (amendments 1-5)
  repair/tests/__init__.py        — Test package init
  repair/tests/test_accounting.py — 160 regression tests
  v6.2_to_v6.2_repaired_v6.diff  — Complete diff from original v6.2
  requirements.txt                — Python dependencies
  README_EXPORT.txt               — This file

DEPENDENCIES (Python 3.12+):
  web3>=6.0
  requests
  pytest (for tests only)

CONFIGURATION:
  Set RH_KEY_FILE env var to your wallet key JSON path before running.
  The key file path was redacted from the exported source.

  Engine expects:
    - RPC: https://rpc.mainnet.chain.robinhood.com (chain ID 4663)
    - State dir: /tmp/rh_state/{chain_id}-{wallet_addr}/
    - Blacklist: /tmp/rh_state/pons_blacklist.json

RUNNING TESTS:
  cd <extracted_dir>
  python3 -m pytest repair/tests/test_accounting.py -v

SAFETY:
  - Production engine is STOPPED, systemd service DISABLED
  - This is the repair copy only — production source is untouched
  - No wallet operations, no signing, no broadcasting
  - Private keys, seed phrases, and API secrets have been removed

AMENDMENTS INCLUDED:
  1-3: 22 fixes (sell floor, TradeOutcome, managed_raw, state dir, etc.)
  4:   TxCoordinator/PositionLedger/ReadOnlyProvider classes,
       quote freshness, Pons rejection, shadow isolation
  5:   TxCoordinator wired into all 20 broadcast nonce sites,
       PositionLedger wired into enter()/exit/state persistence,
       PARTIAL fixed through all callers, mock provider harness,
       9 end-to-end behavioral tests
